import tkinter as tk
import math
import random


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

NORTH = "#e53935"       # северный полюс
SOUTH = "#1e88e5"       # южный полюс
FIELD = "#444444"       # линии поля
COIL = "#ff9f0a"        # катушка
ACCENT = "#0a84ff"

ACCENT_HOVER = "#0066cc"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
RED = "#e53935"
RED_HOVER = "#c62828"
PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class MagnetsApp:
    def __init__(self, root):
        self.root = root
        root.title("Магниты и электромагниты")
        root.geometry("1280x820")
        root.minsize(1180, 780)
        root.configure(bg=BG)
        root.resizable(False, False)

        # ─── Состояние ──────────────────────────────────────────
        # Постоянный магнит
        self.magnet_x = 190
        self.magnet_y = 160
        self.magnet_w = 100
        self.magnet_h = 40
        self.magnet_dragging = False
        self.drag_offset = (0, 0)

        # Электромагнит
        self.current = 5.0        # сила тока
        self.turns = 10           # витков
        self.polarity = 1         # +1 / -1

        # Взаимодействие
        self.magnet_a = {"x": 100, "y": 100, "sign": 1}  # N справа
        self.magnet_b = {"x": 280, "y": 100, "sign": 1}
        self.dragging_a = False
        self.dragging_b = False
        self.drag_a_off = (0, 0)
        self.drag_b_off = (0, 0)

        self._build_ui()
        self._animate()

    # ════════════════════════════════════════════════════════════
    # UI
    # ════════════════════════════════════════════════════════════
    def _build_ui(self):
        tk.Label(self.root, text="Магниты и электромагниты",
                 font=("Segoe UI", 15, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(10, 2))

        tk.Label(self.root,
                 text="Постоянный магнит · Электромагнит · Взаимодействие",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 8))

        main = tk.Frame(self.root, bg=BG)
        main.pack(fill="both", expand=True, padx=16, pady=(0, 8))

        # ─── Три Canvas ────────────────────────────────────────
        canvases = tk.Frame(main, bg=BG)
        canvases.pack(fill="x", pady=(0, 8))

        # Блок 1 — магнит
        self.c_magnet = self._make_card(
            canvases, "ПОСТОЯННЫЙ МАГНИТ",
            "Перетащите магни́т · компас показывает поле",
            "#f0f4ff", 380, 320)

        # Блок 2 — электромагнит
        self.c_electro = self._make_card(
            canvases, "ЭЛЕКТРОМАГНИТ",
            "Меняйте ток и число витков — поле меняется",
            "#fff4e6", 380, 320)

        # Блок 3 — взаимодействие
        self.c_interact = self._make_card(
            canvases, "ВЗАИМОДЕЙСТВИЕ МАГНИТОВ",
            "Перетащите ма́гниты · N/N — отталкиваются",
            "#f4f0ff", 380, 320)

        # ─── Панель управления ─────────────────────────────────
        ctrl = tk.Frame(main, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        ctrl.pack(fill="x")

        inner = tk.Frame(ctrl, bg=CARD)
        inner.pack(fill="x", padx=16, pady=12)

        # ─── Электромагнит ─────────────────────────────────────
        tk.Label(inner, text="Ток катушки:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 6))

        self.current_lbl = tk.Label(inner, text="5.0 А",
                                    font=("Consolas", 11, "bold"),
                                    bg=CARD, fg=ORANGE, width=6)
        self.current_lbl.pack(side="left", padx=(0, 8))

        self.curr_scale = tk.Scale(inner, from_=0, to=10, resolution=0.5,
                                   orient="horizontal",
                                   length=200, showvalue=False,
                                   bg=CARD, fg=TEXT, troughcolor="#ececf0",
                                   activebackground=ORANGE,
                                   highlightthickness=0, bd=0,
                                   sliderlength=16, width=8,
                                   command=self._on_current)
        self.curr_scale.set(5)
        self.curr_scale.pack(side="left", padx=(0, 16))

        # ─── Витки ─────────────────────────────────────────────
        tk.Label(inner, text="Витки:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 6))

        self.turns_lbl = tk.Label(inner, text="10",
                                  font=("Consolas", 11, "bold"),
                                  bg=CARD, fg=ORANGE, width=3)
        self.turns_lbl.pack(side="left", padx=(0, 8))

        self.turns_scale = tk.Scale(inner, from_=1, to=20, resolution=1,
                                    orient="horizontal",
                                    length=150, showvalue=False,
                                    bg=CARD, fg=TEXT, troughcolor="#ececf0",
                                    activebackground=ORANGE,
                                    highlightthickness=0, bd=0,
                                    sliderlength=16, width=8,
                                    command=self._on_turns)
        self.turns_scale.set(10)
        self.turns_scale.pack(side="left", padx=(0, 16))

        # ─── Кнопки ────────────────────────────────────────────
        self._btn(inner, "⇄ Инвертировать ток",
                  ACCENT, ACCENT_HOVER,
                  self.invert_current).pack(side="left", padx=4)

        self._btn(inner, "🔄 Перевернуть B",
                  PURPLE, PURPLE_HOVER,
                  self.flip_b).pack(side="left", padx=4)

    def _make_card(self, parent, title, subtitle, bg_color, w, h):
        card = tk.Frame(parent, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(side="left", fill="both", expand=True, padx=4)

        tk.Label(card, text=title,
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(pady=(8, 2))

        tk.Label(card, text=subtitle,
                 font=("Segoe UI", 8),
                 bg=CARD, fg=MUTED,
                 wraplength=360).pack(pady=(0, 6))

        canvas = tk.Canvas(card, width=w, height=h,
                           bg=bg_color, highlightthickness=0)
        canvas.pack(padx=8, pady=(0, 8))

        return canvas

    def _btn(self, parent, text, bg, hover, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 9, "bold"),
                        bg=bg, fg="white",
                        activebackground=hover,
                        activeforeground="white",
                        bd=0, padx=10, pady=6, cursor="hand2",
                        command=command)

        def on_enter(e): btn.config(bg=hover)

        def on_leave(e): btn.config(bg=bg)

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        return btn

    # ════════════════════════════════════════════════════════════
    # ОБРАБОТЧИКИ
    # ════════════════════════════════════════════════════════════
    def _on_current(self, v):
        self.current = float(v)
        self.current_lbl.config(text=f"{self.current:.1f} А")

    def _on_turns(self, v):
        self.turns = int(float(v))
        self.turns_lbl.config(text=str(self.turns))

    def invert_current(self):
        self.polarity *= -1

    def flip_b(self):
        self.magnet_b["sign"] *= -1

    # ════════════════════════════════════════════════════════════
    # МЫШЬ (магнит)
    # ════════════════════════════════════════════════════════════
    def _bind_magnet_drag(self, canvas):
        canvas.bind("<Button-1>", self._start_drag)
        canvas.bind("<B1-Motion>", self._on_drag)
        canvas.bind("<ButtonRelease-1>", self._end_drag)

    def _start_drag(self, e):
        # Магнит в первом блоке
        if (self.magnet_x - self.magnet_w / 2 < e.x <
                self.magnet_x + self.magnet_w / 2 and
                self.magnet_y - self.magnet_h / 2 < e.y <
                self.magnet_y + self.magnet_h / 2):
            self.magnet_dragging = True
            self.drag_offset = (e.x - self.magnet_x, e.y - self.magnet_y)

    def _on_drag(self, e):
        if self.magnet_dragging:
            self.magnet_x = max(60, min(320, e.x - self.drag_offset[0]))
            self.magnet_y = max(60, min(260, e.y - self.drag_offset[1]))

    def _end_drag(self, e):
        self.magnet_dragging = False

    # ─── Взаимодействие ────────────────────────────────────────
    def _bind_interact_drag(self, canvas):
        canvas.bind("<Button-1>", self._start_interact_drag)
        canvas.bind("<B1-Motion>", self._on_interact_drag)
        canvas.bind("<ButtonRelease-1>", self._end_interact_drag)

    def _start_interact_drag(self, e):
        for m, dragging_key, offset_key in [
            (self.magnet_a, "dragging_a", "drag_a_off"),
            (self.magnet_b, "dragging_b", "drag_b_off"),
        ]:
            if (m["x"] - 50 < e.x < m["x"] + 50 and
                    m["y"] - 30 < e.y < m["y"] + 30):
                setattr(self, dragging_key, True)
                setattr(self, offset_key, (e.x - m["x"], e.y - m["y"]))
                return

    def _on_interact_drag(self, e):
        if self.dragging_a:
            self.magnet_a["x"] = max(40, min(200, e.x - self.drag_a_off[0]))
            self.magnet_a["y"] = max(50, min(200, e.y - self.drag_a_off[1]))
        if self.dragging_b:
            self.magnet_b["x"] = max(200, min(340, e.x - self.drag_b_off[0]))
            self.magnet_b["y"] = max(50, min(200, e.y - self.drag_b_off[1]))

    def _end_interact_drag(self, e):
        self.dragging_a = False
        self.dragging_b = False

    # ════════════════════════════════════════════════════════════
    # АНИМАЦИЯ
    # ════════════════════════════════════════════════════════════
    def _animate(self):
        self._draw_magnet()
        self._draw_electromagnet()
        self._draw_interaction()
        self.root.after(100, self._animate)

    # ════════════════════════════════════════════════════════════
    # БЛОК 1 — ПОСТОЯННЫЙ МАГНИТ
    # ════════════════════════════════════════════════════════════
    def _draw_magnet(self):
        c = self.c_magnet
        c.delete("all")
        w, h = 380, 320

        # Привязываем перетаскивание один раз
        if not hasattr(self, "_magnet_bound"):
            self._bind_magnet_drag(c)
            self._magnet_bound = True

        # Сетка
        for i in range(0, w, 40):
            c.create_line(i, 0, i, h, fill="#e8e8ee")
        for i in range(0, h, 40):
            c.create_line(0, i, w, i, fill="#e8e8ee")

        mx, my = self.magnet_x, self.magnet_y
        mw, mh = self.magnet_w, self.magnet_h

        # Поле вокруг магнита (стрелки)
        self._draw_field_lines(c, mx, my, mw, mh)

        # Сам магнит — N (красный) слева, S (синий) справа
        c.create_rectangle(mx - mw / 2, my - mh / 2,
                           mx, my + mh / 2,
                           fill=NORTH, outline="white", width=2)
        c.create_rectangle(mx, my - mh / 2,
                           mx + mw / 2, my + mh / 2,
                           fill=SOUTH, outline="white", width=2)

        c.create_text(mx - mw / 4, my, text="N",
                      font=("Segoe UI", 16, "bold"), fill="white")
        c.create_text(mx + mw / 4, my, text="S",
                      font=("Segoe UI", 16, "bold"), fill="white")

        # Компас справа
        cx, cy = 320, 80
        c.create_oval(cx - 20, cy - 20, cx + 20, cy + 20,
                      fill="white", outline="#999", width=2)
        # Стрелка компаса: N тянется к S магнита, значит вправо
        angle = 0  # стрелка смотрит вправо
        tip_x = cx + 15 * math.cos(math.radians(angle))
        tip_y = cy + 15 * math.sin(math.radians(angle))
        tail_x = cx - 10 * math.cos(math.radians(angle))
        tail_y = cy - 10 * math.sin(math.radians(angle))
        c.create_line(tail_x, tail_y, tip_x, tip_y,
                      fill=RED, width=3, arrow="last",
                      arrowshape=(6, 8, 3))
        c.create_text(cx, cy + 28, text="компас",
                      font=("Segoe UI", 7), fill=MUTED)

    def _draw_field_lines(self, c, mx, my, mw, mh):
        """Стрелки магнитного поля вокруг магнита."""
        # Вокруг магнита — стрелки от N к S
        points = [
            (mx - 70, my - 50), (mx - 70, my + 50),
            (mx + 70, my - 50), (mx + 70, my + 50),
            (mx, my - 80), (mx, my + 80),
            (mx - 80, my), (mx + 80, my),
        ]

        for (px, py) in points:
            # Отталкиваем от магнита
            dx = px - mx
            dy = py - my
            dist = math.sqrt(dx * dx + dy * dy) or 1
            nx = dx / dist
            ny = dy / dist

            # Для точек сверху/снизу — рисуем стрелки по направлению поля
            # (упрощённо: от N к S)
            if px < mx:
                # Слева — от N
                vx, vy = -1, 0
            elif px > mx:
                vx, vy = 1, 0
            else:
                vx, vy = 0, 1 if py > my else -1

            # Длина стрелки
            length = 12
            end_x = px + vx * length
            end_y = py + vy * length

            c.create_line(px, py, end_x, end_y,
                          fill=FIELD, width=2,
                          arrow="last", arrowshape=(6, 8, 3))

    # ════════════════════════════════════════════════════════════
    # БЛОК 2 — ЭЛЕКТРОМАГНИТ
    # ════════════════════════════════════════════════════════════
    def _draw_electromagnet(self):
        c = self.c_electro
        c.delete("all")
        w, h = 380, 320

        # Сетка
        for i in range(0, w, 40):
            c.create_line(i, 0, i, h, fill="#f0e0d0")
        for i in range(0, h, 40):
            c.create_line(0, i, w, i, fill="#f0e0d0")

        # Катушка (витки) в центре
        cx, cy = w // 2, h // 2 + 10
        coil_w = 100
        coil_h = 100

        # Рисуем витки
        turns = min(self.turns, 20)
        for i in range(turns):
            t = i / max(1, turns - 1) if turns > 1 else 0
            y = cy - coil_h / 2 + t * coil_h

            # Цвет витков зависит от тока
            intensity = min(1.0, self.current / 10)
            r = int(255 * (1 - intensity * 0.3))
            g = int(160 * (1 - intensity * 0.2))
            b = int(30)
            color = f"#{r:02x}{g:02x}{b:02x}"

            c.create_line(cx - coil_w / 2, y, cx + coil_w / 2, y,
                          fill=color, width=3)

        # Выводы катушки
        c.create_line(cx - coil_w / 2, cy - coil_h / 2,
                      cx - coil_w / 2 - 30, cy - coil_h / 2,
                      fill=ORANGE, width=3)
        c.create_line(cx - coil_w / 2, cy + coil_h / 2,
                      cx - coil_w / 2 - 30, cy + coil_h / 2,
                      fill=ORANGE, width=3)

        # Полюса
        north_y = cy - coil_h / 2 - 10
        south_y = cy + coil_h / 2 + 10
        if self.polarity < 0:
            north_y, south_y = south_y, north_y

        # N
        c.create_rectangle(cx - 25, north_y - 15,
                           cx + 25, north_y + 15,
                           fill=NORTH, outline="white", width=2)
        c.create_text(cx, north_y, text="N",
                      font=("Segoe UI", 12, "bold"), fill="white")

        # S
        c.create_rectangle(cx - 25, south_y - 15,
                           cx + 25, south_y + 15,
                           fill=SOUTH, outline="white", width=2)
        c.create_text(cx, south_y, text="S",
                      font=("Segoe UI", 12, "bold"), fill="white")

        # Поле — стрелки вокруг
        if self.current > 0:
            intensity = min(1.0, (self.current * self.turns) / 200)
            for dx, dy in [(-60, -50), (60, -50), (-60, 50), (60, 50),
                           (-80, 0), (80, 0), (0, -80), (0, 80)]:
                px = cx + dx
                py = cy + dy
                # Направление поля
                if dy < 0:
                    # Сверху — от N к S (вниз)
                    vx, vy = 0, 1
                elif dy > 0:
                    vx, vy = 0, -1
                elif dx < 0:
                    vx, vy = 1, 0
                else:
                    vx, vy = -1, 0

                if self.polarity < 0:
                    vx, vy = -vx, -vy

                length = 8 + 10 * intensity
                end_x = px + vx * length
                end_y = py + vy * length

                c.create_line(px, py, end_x, end_y,
                              fill=FIELD, width=2,
                              arrow="last", arrowshape=(5, 7, 2))

        # Подпись
        c.create_text(cx, 20,
                      text=f"I = {self.current:.1f} А  ·  "
                           f"N = {self.turns} витков",
                      font=("Segoe UI", 9, "bold"),
                      fill=ORANGE)

    # ════════════════════════════════════════════════════════════
    # БЛОК 3 — ВЗАИМОДЕЙСТВИЕ
    # ════════════════════════════════════════════════════════════
    def _draw_interaction(self):
        c = self.c_interact
        c.delete("all")
        w, h = 380, 320

        if not hasattr(self, "_interact_bound"):
            self._bind_interact_drag(c)
            self._interact_bound = True

        # Сетка
        for i in range(0, w, 40):
            c.create_line(i, 0, i, h, fill="#e8e0f0")
        for i in range(0, h, 40):
            c.create_line(0, i, w, i, fill="#e8e0f0")

        # Магнит A
        self._draw_bar_magnet(c, self.magnet_a, "A")

        # Магнит B
        self._draw_bar_magnet(c, self.magnet_b, "B")

        # Сила взаимодействия
        dx = self.magnet_b["x"] - self.magnet_a["x"]
        dy = self.magnet_b["y"] - self.magnet_a["y"]
        dist = math.sqrt(dx * dx + dy * dy)

        # Определяем знаки обращённых друг к другу полюсов
        # Если A.sign == B.sign, обращённые стороны одинаковые → отталкивание
        # Если разные → притяжение
        a_right = self.magnet_a["sign"]    # +1 → N справа
        b_left = self.magnet_b["sign"]     # +1 → N слева

        if a_right == b_left:
            # N-N или S-S → отталкивание
            force_text = "Отталкиваются"
            force_color = RED
            arrow_dir = -1  # стрелки в стороны
        else:
            force_text = "Притягиваются"
            force_color = GREEN
            arrow_dir = 1   # стрелки навстречу

        # Стрелки силы
        if dist > 20:
            # Между магнитами
            mid_x = (self.magnet_a["x"] + self.magnet_b["x"]) / 2
            mid_y = (self.magnet_a["y"] + self.magnet_b["y"]) / 2

            if force_color == RED:
                # Отталкивание — стрелки наружу
                c.create_line(mid_x - 20, mid_y, mid_x - 40, mid_y,
                              fill=RED, width=3,
                              arrow="last", arrowshape=(6, 8, 3))
                c.create_line(mid_x + 20, mid_y, mid_x + 40, mid_y,
                              fill=RED, width=3,
                              arrow="last", arrowshape=(6, 8, 3))
            else:
                # Притяжение — стрелки внутрь
                c.create_line(mid_x - 40, mid_y, mid_x - 20, mid_y,
                              fill=GREEN, width=3,
                              arrow="last", arrowshape=(6, 8, 3))
                c.create_line(mid_x + 40, mid_y, mid_x + 20, mid_y,
                              fill=GREEN, width=3,
                              arrow="last", arrowshape=(6, 8, 3))

        # Подпись
        c.create_text(w // 2, h - 15,
                      text=force_text,
                      font=("Segoe UI", 10, "bold"),
                      fill=force_color)

    def _draw_bar_magnet(self, c, magnet, label):
        mx, my = magnet["x"], magnet["y"]
        mw = 100
        mh = 40

        if magnet["sign"] > 0:
            # N справа
            left_color = SOUTH
            right_color = NORTH
            left_text = "S"
            right_text = "N"
        else:
            left_color = NORTH
            right_color = SOUTH
            left_text = "N"
            right_text = "S"

        c.create_rectangle(mx - mw / 2, my - mh / 2,
                           mx, my + mh / 2,
                           fill=left_color, outline="white", width=2)
        c.create_rectangle(mx, my - mh / 2,
                           mx + mw / 2, my + mh / 2,
                           fill=right_color, outline="white", width=2)

        c.create_text(mx - mw / 4, my, text=left_text,
                      font=("Segoe UI", 12, "bold"), fill="white")
        c.create_text(mx + mw / 4, my, text=right_text,
                      font=("Segoe UI", 12, "bold"), fill="white")

        # Метка
        c.create_text(mx, my - mh / 2 - 12, text=label,
                      font=("Segoe UI", 9, "bold"), fill=MUTED)


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = MagnetsApp(root)
    root.mainloop()
    
