import tkinter as tk
import math
import random


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

WIRE = "#333333"
ELECTRON = "#0a84ff"
RESISTOR = "#8e44ad"
INDUCTOR = "#ff9f0a"
CAPACITOR = "#30d158"
LAMP_ON = "#ffd60a"
LAMP_OFF = "#d0d0d5"
MULTIMETER = "#1c1c1e"

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
RED = "#e53935"
RED_HOVER = "#c62828"
PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class ACCircuitApp:
    def __init__(self, root):
        self.root = root
        root.title("Конструктор цепи переменного тока")
        root.geometry("1280x880")
        root.minsize(1180, 840)
        root.configure(bg=BG)
        root.resizable(False, False)

        # Параметры
        self.voltage_amp = 10.0     # амплитуда, В
        self.frequency = 1.0        # Гц
        self.resistance = 10.0      # Ом
        self.inductance = 0.5       # Гн
        self.capacitance = 100.0    # мкФ

        # Время
        self.t = 0.0
        self.tick = 0

        # История для осциллографа
        self.history_v = []
        self.history_i = []

        # Электроны
        self.electrons = []
        self._init_electrons()

        self._build_ui()
        self._animate()

    def _init_electrons(self):
        # Электроны на проводах (по контуру)
        self.electrons = []
        for i in range(30):
            # Распределены по периметру прямоугольника
            t = i / 30
            if t < 0.25:
                x = 100 + (400 - 100) * t / 0.25
                y = 100
            elif t < 0.5:
                x = 400
                y = 100 + (400 - 100) * (t - 0.25) / 0.25
            elif t < 0.75:
                x = 400 - (400 - 100) * (t - 0.5) / 0.25
                y = 400
            else:
                x = 100
                y = 400 - (400 - 100) * (t - 0.75) / 0.25
            self.electrons.append({"pos": t, "x": x, "y": y})

    # ════════════════════════════════════════════════════════════
    # UI
    # ════════════════════════════════════════════════════════════
    def _build_ui(self):
        tk.Label(self.root, text="Конструктор цепи переменного тока",
                 font=("Segoe UI", 15, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(10, 2))

        tk.Label(self.root,
                 text="Генератор · Резистор · Катушка · Конденсатор · Лампы · Осциллограф",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 8))

        main = tk.Frame(self.root, bg=BG)
        main.pack(fill="both", expand=True, padx=16, pady=(0, 8))

        # ─── Левая часть: схема ────────────────────────────────
        left = tk.Frame(main, bg=BG)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))

        card_scheme = tk.Frame(left, bg=CARD,
                               highlightthickness=1,
                               highlightbackground=BORDER)
        card_scheme.pack(fill="both", expand=True)

        tk.Label(card_scheme, text="СХЕМА ЦЕПИ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=16, pady=(10, 4))

        self.canvas = tk.Canvas(card_scheme, width=500, height=500,
                                bg="white", highlightthickness=0)
        self.canvas.pack(padx=8, pady=(0, 8))

        # ─── Правая часть: осциллограф + управление ────────────
        right = tk.Frame(main, bg=BG)
        right.pack(side="left", fill="both", padx=(8, 0))

        # Осциллограф
        osc_card = tk.Frame(right, bg=CARD,
                            highlightthickness=1,
                            highlightbackground=BORDER)
        osc_card.pack(fill="x", pady=(0, 8))

        tk.Label(osc_card, text="ОСЦИЛЛОГРАФ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=16, pady=(10, 4))

        self.osc_canvas = tk.Canvas(osc_card, width=440, height=200,
                                    bg="#0a0a0a", highlightthickness=0)
        self.osc_canvas.pack(padx=8, pady=(0, 8))

        # Мультиметр
        mm_card = tk.Frame(right, bg=CARD,
                           highlightthickness=1,
                           highlightbackground=BORDER)
        mm_card.pack(fill="x", pady=(0, 8))

        tk.Label(mm_card, text="МУЛЬТИМЕТР (RMS)",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=16, pady=(10, 4))

        mm_inner = tk.Frame(mm_card, bg=CARD)
        mm_inner.pack(fill="x", padx=16, pady=(0, 12))

        self.mm_voltage = self._metric(mm_inner, "U (RMS)", "0.00 В", ACCENT)
        self.mm_current = self._metric(mm_inner, "I (RMS)", "0.00 А", ORANGE)

        # Управление
        ctrl = tk.Frame(right, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        ctrl.pack(fill="both", expand=True)

        tk.Label(ctrl, text="ПАРАМЕТРЫ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=16, pady=(10, 4))

        ctrl_inner = tk.Frame(ctrl, bg=CARD)
        ctrl_inner.pack(fill="x", padx=16, pady=(0, 12))

        self.v_scale = self._slider(ctrl_inner, "Амплитуда U", "В",
                                    1, 30, self.voltage_amp, 1,
                                    self._set_voltage, ACCENT)
        self.f_scale = self._slider(ctrl_inner, "Частота f", "Гц",
                                    0.2, 5.0, self.frequency, 0.2,
                                    self._set_freq, GREEN)
        self.r_scale = self._slider(ctrl_inner, "Резистор R", "Ом",
                                    1, 100, self.resistance, 1,
                                    self._set_R, PURPLE)
        self.l_scale = self._slider(ctrl_inner, "Катушка L", "Гн",
                                    0.1, 5.0, self.inductance, 0.1,
                                    self._set_L, INDUCTOR)
        self.c_scale = self._slider(ctrl_inner, "Конденсатор C", "мкФ",
                                    1, 500, self.capacitance, 5,
                                    self._set_C, CAPACITOR)

        # Кнопки
        btn_row = tk.Frame(ctrl_inner, bg=CARD)
        btn_row.pack(fill="x", pady=(8, 0))

        self._btn(btn_row, "↻ Сброс", ORANGE, ORANGE_HOVER,
                  self.reset).pack(side="left", padx=4)

    def _metric(self, parent, label, value, color):
        f = tk.Frame(parent, bg=CARD)
        f.pack(side="left", padx=(0, 30))

        tk.Label(f, text=label,
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED).pack(anchor="w")

        lbl = tk.Label(f, text=value,
                       font=("Consolas", 14, "bold"),
                       bg=CARD, fg=color)
        lbl.pack(anchor="w")
        return lbl

    def _slider(self, parent, label, unit, vmin, vmax, initial, step,
                callback, color):
        f = tk.Frame(parent, bg=CARD)
        f.pack(fill="x", pady=(0, 6))

        header = tk.Frame(f, bg=CARD)
        header.pack(fill="x")

        tk.Label(header, text=label,
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED).pack(side="left")

        lbl = tk.Label(header, text=f"{initial:g} {unit}".strip(),
                       font=("Consolas", 10, "bold"),
                       bg=CARD, fg=color)
        lbl.pack(side="right")

        def on_move(v):
            val = float(v)
            callback(val)
            if unit == "мкФ":
                lbl.config(text=f"{int(val)} {unit}")
            elif unit == "Ом":
                lbl.config(text=f"{int(val)} {unit}")
            else:
                lbl.config(text=f"{val:.1f} {unit}")

        scale = tk.Scale(f, from_=vmin, to=vmax, resolution=step,
                         orient="horizontal", showvalue=False,
                         bg=CARD, fg=TEXT, troughcolor="#ececf0",
                         activebackground=color,
                         highlightthickness=0, bd=0,
                         sliderlength=14, width=8,
                         command=on_move)
        scale.set(initial)
        scale.pack(fill="x")
        return scale

    def _btn(self, parent, text, bg, hover, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 9, "bold"),
                        bg=bg, fg="white",
                        activebackground=hover,
                        activeforeground="white",
                        bd=0, padx=10, pady=6, cursor="hand2",
                        command=command)

        def on_enter(e): btn.config(bg=hover)

        def on_leave(e): btn.config(bg=bg)

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        return btn

    # ─── Обработчики параметров ────────────────────────────────
    def _set_voltage(self, v): self.voltage_amp = v

    def _set_freq(self, v): self.frequency = v

    def _set_R(self, v): self.resistance = v

    def _set_L(self, v): self.inductance = v

    def _set_C(self, v): self.capacitance = v

    def reset(self):
        self.voltage_amp = 10.0
        self.frequency = 1.0
        self.resistance = 10.0
        self.inductance = 0.5
        self.capacitance = 100.0
        self.v_scale.set(10)
        self.f_scale.set(1.0)
        self.r_scale.set(10)
        self.l_scale.set(0.5)
        self.c_scale.set(100)
        self.t = 0.0
        self.history_v = []
        self.history_i = []

    # ════════════════════════════════════════════════════════════
    # АНИМАЦИЯ
    # ════════════════════════════════════════════════════════════
    def _animate(self):
        self.tick += 1
        self.t += 0.03   # шаг времени

        # Вычисляем мгновенное напряжение и ток
        omega = 2 * math.pi * self.frequency

        # Напряжение
        u = self.voltage_amp * math.sin(omega * self.t)

        # Импеданс
        R = self.resistance
        XL = omega * self.inductance
        XC = 1 / (omega * self.capacitance * 1e-6) if self.capacitance > 0 else 0
        Z = math.sqrt(R ** 2 + (XL - XC) ** 2)

        if Z < 0.1:
            Z = 0.1

        # Ток
        i = self.voltage_amp / Z * math.sin(omega * self.t - math.atan2(XL - XC, R))

        # Сохраняем в историю
        self.history_v.append(u)
        self.history_i.append(i)
        if len(self.history_v) > 200:
            self.history_v.pop(0)
            self.history_i.pop(0)

        # Обновляем электроны
        self._update_electrons(i)

        # Отрисовка
        self._draw_scheme(u, i, Z)
        self._draw_oscilloscope()

        # Метрики RMS
        u_rms = self.voltage_amp / math.sqrt(2)
        i_rms = (self.voltage_amp / Z) / math.sqrt(2)
        self.mm_voltage.config(text=f"{u_rms:.2f} В")
        self.mm_current.config(text=f"{i_rms*1000:.1f} мА")

        self.root.after(30, self._animate)

    def _update_electrons(self, current):
        """Двигаем электроны вдоль контура в зависимости от тока."""
        # Скорость = ток * коэффициент
        speed = current * 0.002 * self.frequency * 10

        for e in self.electrons:
            e["pos"] = (e["pos"] + speed * 0.1) % 1.0
            t = e["pos"]
            # Позиция по контуру
            if t < 0.25:
                x = 100 + 300 * t / 0.25
                y = 100
            elif t < 0.5:
                x = 400
                y = 100 + 300 * (t - 0.25) / 0.25
            elif t < 0.75:
                x = 400 - 300 * (t - 0.5) / 0.25
                y = 400
            else:
                x = 100
                y = 400 - 300 * (t - 0.75) / 0.25
            e["x"] = x
            e["y"] = y

    # ════════════════════════════════════════════════════════════
    # ОТРИСОВКА СХЕМЫ
    # ════════════════════════════════════════════════════════════
    def _draw_scheme(self, u, i, Z):
        c = self.canvas
        c.delete("all")

        # ─── Контур ─────────────────────────────────────────────
        # Верх
        c.create_line(100, 100, 400, 100, fill=WIRE, width=3)
        # Право
        c.create_line(400, 100, 400, 400, fill=WIRE, width=3)
        # Низ
        c.create_line(400, 400, 100, 400, fill=WIRE, width=3)
        # Лево (генератор)
        c.create_line(100, 400, 100, 250, fill=WIRE, width=3)
        c.create_line(100, 150, 100, 100, fill=WIRE, width=3)

        # ─── Генератор ──────────────────────────────────────────
        c.create_oval(60, 150, 140, 250,
                      fill="white", outline=ACCENT, width=3)
        c.create_text(100, 190, text="~", font=("Segoe UI", 24, "bold"),
                      fill=ACCENT)
        c.create_text(100, 220, text=f"{self.voltage_amp:.0f} В",
                      font=("Segoe UI", 9, "bold"), fill=ACCENT)
        c.create_text(100, 235, text=f"{self.frequency:.1f} Гц",
                      font=("Segoe UI", 8), fill=MUTED)

        # ─── Резистор (сверху) ─────────────────────────────────
        c.create_rectangle(220, 85, 300, 115,
                           fill=RESISTOR, outline="white", width=2)
        c.create_text(260, 100, text="R", fill="white",
                      font=("Segoe UI", 10, "bold"))
        c.create_text(260, 65, text=f"{int(self.resistance)} Ом",
                      font=("Segoe UI", 8), fill=MUTED)

        # ─── Катушка (справа) ──────────────────────────────────
        for k in range(5):
            y = 180 + k * 25
            c.create_arc(380, y, 420, y + 25,
                         start=0, extent=180,
                         style="arc", outline=INDUCTOR, width=3)
        c.create_text(430, 240, text="L", fill=INDUCTOR,
                      font=("Segoe UI", 10, "bold"))
        c.create_text(450, 240, text=f"{self.inductance:.1f} Гн",
                      font=("Segoe UI", 8), fill=MUTED, anchor="w")

        # ─── Конденсатор (снизу) ───────────────────────────────
        c.create_line(220, 385, 220, 415, fill=CAPACITOR, width=3)
        c.create_line(240, 385, 240, 415, fill=CAPACITOR, width=3)
        # Убираем часть контура
        c.create_line(220, 400, 240, 400, fill="white", width=5)
        c.create_text(230, 440, text="C", fill=CAPACITOR,
                      font=("Segoe UI", 10, "bold"))
        c.create_text(260, 440, text=f"{int(self.capacitance)} мкФ",
                      font=("Segoe UI", 8), fill=MUTED, anchor="w")

        # ─── Лампа (слева) ─────────────────────────────────────
        # Яркость зависит от тока
        brightness = min(1.0, abs(i) / (self.voltage_amp / self.resistance + 0.1))
        lamp_color = self._blend(LAMP_OFF, LAMP_ON, brightness)

        c.create_oval(60, 290, 110, 340,
                      fill=lamp_color, outline="#666", width=2)
        # Свечение
        if brightness > 0.3:
            c.create_oval(50, 280, 120, 350,
                          fill="", outline=LAMP_ON,
                          width=2, dash=(2, 4))
        c.create_text(85, 315, text="💡",
                      font=("Segoe UI", 14))

        # ─── Электроны ─────────────────────────────────────────
        for e in self.electrons:
            c.create_oval(e["x"] - 3, e["y"] - 3,
                          e["x"] + 3, e["y"] + 3,
                          fill=ELECTRON, outline="")

        # ─── Подпись ───────────────────────────────────────────
        c.create_text(250, 20,
                      text=f"Z = {Z:.1f} Ом  ·  "
                           f"u = {u:.2f} В  ·  i = {i*1000:.1f} мА",
                      font=("Consolas", 9),
                      fill=MUTED)

    def _blend(self, c1, c2, t):
        c1 = c1.lstrip("#")
        c2 = c2.lstrip("#")
        r1, g1, b1 = (int(c1[i:i+2], 16) for i in (0, 2, 4))
        r2, g2, b2 = (int(c2[i:i+2], 16) for i in (0, 2, 4))
        r = int(r1 + (r2 - r1) * t)
        g = int(g1 + (g2 - g1) * t)
        b = int(b1 + (b2 - b1) * t)
        return f"#{r:02x}{g:02x}{b:02x}"

    # ════════════════════════════════════════════════════════════
    # ОСЦИЛЛОГРАФ
    # ════════════════════════════════════════════════════════════
    def _draw_oscilloscope(self):
        c = self.osc_canvas
        c.delete("all")

        W = 440
        H = 200
        cx = W // 2
        cy = H // 2

        # Сетка
        for x in range(0, W, 40):
            c.create_line(x, 0, x, H, fill="#1a2a1a")
        for y in range(0, H, 40):
            c.create_line(0, y, W, y, fill="#1a2a1a")

        # Оси
        c.create_line(0, cy, W, cy, fill="#2a4a2a")
        c.create_line(cx, 0, cx, H, fill="#2a4a2a")

        # Масштаб
        max_v = self.voltage_amp * 1.2
        max_i = (self.voltage_amp / self.resistance) * 1.2 if self.resistance > 0 else 1

        # Напряжение (синий)
        if len(self.history_v) > 1:
            points = []
            for i, u in enumerate(self.history_v):
                x = i * W / len(self.history_v)
                y = cy - u / max_v * (cy - 10)
                points.extend([x, y])
            c.create_line(*points, fill=ACCENT, width=1.5)

        # Ток (зелёный)
        if len(self.history_i) > 1:
            points = []
            for i, val in enumerate(self.history_i):
                x = i * W / len(self.history_i)
                y = cy - val / max_i * (cy - 10)
                points.extend([x, y])
            c.create_line(*points, fill=GREEN, width=1.5)

        # Легенда
        c.create_text(10, 10, text="U", fill=ACCENT, anchor="w",
                      font=("Segoe UI", 9, "bold"))
        c.create_text(30, 10, text="I", fill=GREEN, anchor="w",
                      font=("Segoe UI", 9, "bold"))


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = ACCircuitApp(root)
    root.mainloop()
