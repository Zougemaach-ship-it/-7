import tkinter as tk
import math
import random


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

POS = "#e53935"          # положительный заряд
NEG = "#1e88e5"          # отрицательный заряд
ELECTRON = "#0a84ff"     # электрон
ION_POS = "#e53935"      # катион
ION_NEG = "#30d158"      # анион
ATOM = "#9e9e9e"         # нейтральный атом
ELECTRODE_POS = "#e53935"
ELECTRODE_NEG = "#1e88e5"

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
RED = "#e53935"
RED_HOVER = "#c62828"
PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class CurrentInMediaApp:
    def __init__(self, root):
        self.root = root
        root.title("Электрический ток в разных средах")
        root.geometry("1280x820")
        root.minsize(1180, 780)
        root.configure(bg=BG)
        root.resizable(False, False)

        # Параметры
        self.voltage = 10.0        # напряжение, В
        self.running = True
        self.tick = 0
        self.animation_speed = 1.0

        # Металл: электроны
        self.metal_electrons = []
        self.metal_ions = []

        # Электролит: ионы
        self.electrolyte_ions = []

        # Газ: электроны + ионы + атомы
        self.gas_electrons = []
        self.gas_ions = []
        self.gas_atoms = []

        self._init_particles()
        self._build_ui()
        self._animate()

    # ════════════════════════════════════════════════════════════
    # ИНИЦИАЛИЗАЦИЯ ЧАСТИЦ
    # ════════════════════════════════════════════════════════════
    def _init_particles(self):
        # Металл — решётка ионов и свободные электроны
        self.metal_ions = []
        for i in range(50):
            x = random.uniform(30, 370)
            y = random.uniform(30, 290)
            self.metal_ions.append({"x": x, "y": y, "phase": random.uniform(0, 2 * math.pi)})

        self.metal_electrons = []
        for i in range(20):
            self.metal_electrons.append({
                "x": random.uniform(30, 370),
                "y": random.uniform(30, 290),
                "vx": random.uniform(-0.5, 0.5),
                "vy": random.uniform(-0.5, 0.5),
            })

        # Электролит — ионы двух знаков
        self.electrolyte_ions = []
        for i in range(15):
            sign = 1 if i % 2 == 0 else -1
            self.electrolyte_ions.append({
                "x": random.uniform(30, 370),
                "y": random.uniform(30, 290),
                "sign": sign,
                "radius": 8 if sign > 0 else 6,
                "speed": random.uniform(0.5, 1.5),
            })

        # Газ — атомы, электроны, ионы
        self.gas_atoms = []
        for i in range(40):
            self.gas_atoms.append({
                "x": random.uniform(30, 370),
                "y": random.uniform(30, 290),
                "vx": random.uniform(-0.3, 0.3),
                "vy": random.uniform(-0.3, 0.3),
            })

        self.gas_electrons = []
        self.gas_ions = []
        for i in range(6):
            self.gas_electrons.append({
                "x": random.uniform(30, 370),
                "y": random.uniform(30, 290),
                "vx": random.uniform(-1, 1),
                "vy": random.uniform(-1, 1),
            })
            self.gas_ions.append({
                "x": random.uniform(30, 370),
                "y": random.uniform(30, 290),
                "vx": random.uniform(-0.5, 0.5),
                "vy": random.uniform(-0.5, 0.5),
                "sign": 1 if i % 2 == 0 else -1,
            })

    # ════════════════════════════════════════════════════════════
    # UI
    # ════════════════════════════════════════════════════════════
    def _build_ui(self):
        tk.Label(self.root,
                 text="Электрический ток в разных средах",
                 font=("Segoe UI", 15, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(10, 2))

        tk.Label(self.root,
                 text="Металлы · Электролиты · Газы",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 8))

        # ─── Основная область ──────────────────────────────────
        main = tk.Frame(self.root, bg=BG)
        main.pack(fill="both", expand=True, padx=16, pady=(0, 8))

        # ═══ Три Canvas ══════════════════════════════════════════
        canvases_frame = tk.Frame(main, bg=BG)
        canvases_frame.pack(fill="x", pady=(0, 8))

        self.canvas_metal = self._make_media_card(
            canvases_frame, "МЕТАЛЛ",
            "Электроны дрейфуют между ионами решётки",
            "#e8f4ff")
        self.canvas_electrolyte = self._make_media_card(
            canvases_frame, "ЭЛЕКТРОЛИТ",
            "Ионы движутся к противоположным электродам",
            "#f0fff0")
        self.canvas_gas = self._make_media_card(
            canvases_frame, "ГАЗ",
            "Ионизация молекул и движение ионов + электронов",
            "#fdf4ff")

        # ═══ Управление ═════════════════════════════════════════
        ctrl = tk.Frame(main, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        ctrl.pack(fill="x", pady=(0, 8))

        inner = tk.Frame(ctrl, bg=CARD)
        inner.pack(fill="x", padx=16, pady=12)

        # Напряжение
        tk.Label(inner, text="Напряжение:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 8))

        self.volt_lbl = tk.Label(inner, text="10 В",
                                 font=("Consolas", 12, "bold"),
                                 bg=CARD, fg=RED, width=6)
        self.volt_lbl.pack(side="left", padx=(0, 10))

        self.volt_scale = tk.Scale(inner, from_=0, to=50, resolution=1,
                                   orient="horizontal",
                                   length=300, showvalue=False,
                                   bg=CARD, fg=TEXT, troughcolor="#ececf0",
                                   activebackground=RED,
                                   highlightthickness=0, bd=0,
                                   sliderlength=18, width=10,
                                   command=self._on_voltage_change)
        self.volt_scale.set(10)
        self.volt_scale.pack(side="left", padx=(0, 16))

        # Скорость анимации
        tk.Label(inner, text="Скорость:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 8))

        self.speed_scale = tk.Scale(inner, from_=0.1, to=3.0, resolution=0.1,
                                    orient="horizontal",
                                    length=150, showvalue=False,
                                    bg=CARD, fg=TEXT, troughcolor="#ececf0",
                                    activebackground=ACCENT,
                                    highlightthickness=0, bd=0,
                                    sliderlength=16, width=8,
                                    command=lambda v: setattr(self, "animation_speed",
                                                              float(v)))
        self.speed_scale.set(1.0)
        self.speed_scale.pack(side="left", padx=(0, 16))

        # Кнопки
        self.btn_pause = self._btn(inner, "⏸ Пауза",
                                   ACCENT, ACCENT_HOVER,
                                   self.toggle_running)
        self.btn_pause.pack(side="right", padx=4)

        self._btn(inner, "↻ Сброс",
                  ORANGE, ORANGE_HOVER,
                  self.reset).pack(side="right", padx=4)

        # ═══ Метрики ════════════════════════════════════════════
        metrics = tk.Frame(main, bg=CARD,
                           highlightthickness=1,
                           highlightbackground=BORDER)
        metrics.pack(fill="x")

        m_inner = tk.Frame(metrics, bg=CARD)
        m_inner.pack(fill="x", padx=16, pady=10)

        self.m_metal = self._metric(m_inner, "Металлы",
                                    "I = 0 A", ACCENT)
        self.m_electro = self._metric(m_inner, "Электролиты",
                                      "I = 0 A", GREEN)
        self.m_gas = self._metric(m_inner, "Газы",
                                  "I = 0 A", PURPLE)

    def _make_media_card(self, parent, title, subtitle, bg_color):
        card = tk.Frame(parent, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(side="left", fill="both", expand=True, padx=4)

        tk.Label(card, text=title,
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(pady=(8, 2))

        tk.Label(card, text=subtitle,
                 font=("Segoe UI", 8),
                 bg=CARD, fg=MUTED,
                 wraplength=360).pack(pady=(0, 6))

        canvas = tk.Canvas(card, width=380, height=320,
                           bg=bg_color, highlightthickness=0)
        canvas.pack(padx=8, pady=(0, 8))
        return canvas

    def _metric(self, parent, label, value, color):
        f = tk.Frame(parent, bg=CARD)
        f.pack(side="left", padx=(0, 40))

        tk.Label(f, text=label,
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED).pack(anchor="w")

        lbl = tk.Label(f, text=value,
                       font=("Consolas", 14, "bold"),
                       bg=CARD, fg=color)
        lbl.pack(anchor="w")
        return lbl

    def _btn(self, parent, text, bg, hover, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 10, "bold"),
                        bg=bg, fg="white",
                        activebackground=hover,
                        activeforeground="white",
                        bd=0, padx=12, pady=8, cursor="hand2",
                        command=command)

        def on_enter(e): btn.config(bg=hover)

        def on_leave(e): btn.config(bg=bg)

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        return btn

    # ════════════════════════════════════════════════════════════
    # УПРАВЛЕНИЕ
    # ════════════════════════════════════════════════════════════
    def _on_voltage_change(self, v):
        self.voltage = float(v)
        self.volt_lbl.config(text=f"{int(self.voltage)} В")

    def toggle_running(self):
        self.running = not self.running
        self.btn_pause.config(
            text="▶ Продолжить" if not self.running else "⏸ Пауза")

    def reset(self):
        self._init_particles()
        self.tick = 0

    # ════════════════════════════════════════════════════════════
    # АНИМАЦИЯ
    # ════════════════════════════════════════════════════════════
    def _animate(self):
        if self.running:
            self.tick += 1
            self._update_metal()
            self._update_electrolyte()
            self._update_gas()
            self._draw_all()
            self._update_metrics()

        self.root.after(30, self._animate)

    # ─── Металлы ────────────────────────────────────────────────
    def _update_metal(self):
        w, h = 380, 320
        # Напряжение влияет на дрейф
        drift = self.voltage * 0.05

        for e in self.metal_electrons:
            # Дрейф вправо (к + электроду)
            e["vx"] += drift * 0.02
            # Случайные столкновения
            if random.random() < 0.05:
                e["vx"] = random.uniform(-1, 1)
                e["vy"] = random.uniform(-1, 1)

            e["x"] += e["vx"] * self.animation_speed
            e["y"] += e["vy"] * self.animation_speed

            # Границы
            if e["x"] < 20: e["x"] = 20; e["vx"] = abs(e["vx"])
            if e["x"] > w - 20: e["x"] = w - 20; e["vx"] = -abs(e["vx"])
            if e["y"] < 20: e["y"] = 20; e["vy"] = abs(e["vy"])
            if e["y"] > h - 20: e["y"] = h - 20; e["vy"] = -abs(e["vy"])

    # ─── Электролиты ───────────────────────────────────────────
    def _update_electrolyte(self):
        w, h = 380, 320
        speed = self.voltage * 0.04

        for ion in self.electrolyte_ions:
            if ion["sign"] > 0:
                # Катион → катод (слева, -)
                ion["x"] -= speed
            else:
                # Анион → анод (справа, +)
                ion["x"] += speed

            # Плавное случайное движение
            ion["y"] += random.uniform(-0.5, 0.5)

            # Границы
            if ion["x"] < 20:
                ion["x"] = 20
                if ion["sign"] > 0:
                    ion["sign"] = -ion["sign"]
            if ion["x"] > w - 20:
                ion["x"] = w - 20
                if ion["sign"] < 0:
                    ion["sign"] = -ion["sign"]
            if ion["y"] < 20: ion["y"] = 20
            if ion["y"] > h - 20: ion["y"] = h - 20

    # ─── Газы ───────────────────────────────────────────────────
    def _update_gas(self):
        w, h = 380, 320
        speed = self.voltage * 0.03

        # Атомы — хаотично
        for a in self.gas_atoms:
            a["x"] += a["vx"] * self.animation_speed
            a["y"] += a["vy"] * self.animation_speed
            if a["x"] < 20 or a["x"] > w - 20: a["vx"] *= -1
            if a["y"] < 20 or a["y"] > h - 20: a["vy"] *= -1

        # Электроны — дрейф к +
        for e in self.gas_electrons:
            e["vx"] += speed * 0.05
            e["x"] += e["vx"] * self.animation_speed
            e["y"] += e["vy"] * self.animation_speed

            # Случайные отклонения
            if random.random() < 0.1:
                e["vy"] = random.uniform(-2, 2)

            # Границы
            if e["x"] < 20: e["x"] = 20; e["vx"] = abs(e["vx"])
            if e["x"] > w - 20: e["x"] = w - 20; e["vx"] = -abs(e["vx"])
            if e["y"] < 20: e["y"] = 20; e["vy"] = abs(e["vy"])
            if e["y"] > h - 20: e["y"] = h - 20; e["vy"] = -abs(e["vy"])

        # Ионы — дрейф
        for ion in self.gas_ions:
            if ion["sign"] > 0:
                ion["x"] += speed
            else:
                ion["x"] -= speed

            ion["x"] += ion["vx"] * self.animation_speed
            ion["y"] += ion["vy"] * self.animation_speed

            if ion["x"] < 20: ion["x"] = 20
            if ion["x"] > w - 20: ion["x"] = w - 20
            if ion["y"] < 20 or ion["y"] > h - 20: ion["vy"] *= -1

    # ════════════════════════════════════════════════════════════
    # ОТРИСОВКА
    # ════════════════════════════════════════════════════════════
    def _draw_all(self):
        self._draw_metal()
        self._draw_electrolyte()
        self._draw_gas()

    def _draw_electrodes(self, canvas, w, h):
        """Рисует электроды по краям."""
        # Левый — минус (катод)
        canvas.create_rectangle(5, 30, 20, h - 30,
                                fill=ELECTRODE_NEG, outline="")
        canvas.create_text(12, h // 2, text="−",
                           fill="white", font=("Segoe UI", 12, "bold"))

        # Правый — плюс (анод)
        canvas.create_rectangle(w - 20, 30, w - 5, h - 30,
                                fill=ELECTRODE_POS, outline="")
        canvas.create_text(w - 12, h // 2, text="+",
                           fill="white", font=("Segoe UI", 12, "bold"))

    def _draw_metal(self):
        c = self.canvas_metal
        c.delete("all")
        w, h = 380, 320

        # Электроды
        self._draw_electrodes(c, w, h)

        # Ионы решётки (неподвижные точки)
        for ion in self.metal_ions:
            c.create_oval(ion["x"] - 3, ion["y"] - 3,
                          ion["x"] + 3, ion["y"] + 3,
                          fill=ATOM, outline="")

        # Электроны (синие с «−»)
        for e in self.metal_electrons:
            c.create_oval(e["x"] - 5, e["y"] - 5,
                          e["x"] + 5, e["y"] + 5,
                          fill=ELECTRON, outline="")
            c.create_text(e["x"], e["y"],
                          text="−", fill="white",
                          font=("Segoe UI", 7, "bold"))

        # Подпись
        c.create_text(w // 2, 10,
                      text=f"U = {int(self.voltage)} В · свободные электроны",
                      font=("Segoe UI", 8),
                      fill=MUTED)

    def _draw_electrolyte(self):
        c = self.canvas_electrolyte
        c.delete("all")
        w, h = 380, 320

        # Электроды
        self._draw_electrodes(c, w, h)

        # Ионы
        for ion in self.electrolyte_ions:
            if ion["sign"] > 0:
                color = ION_POS
                text = "+"
                r = 8
            else:
                color = ION_NEG
                text = "−"
                r = 6

            c.create_oval(ion["x"] - r, ion["y"] - r,
                          ion["x"] + r, ion["y"] + r,
                          fill=color, outline="white", width=1)
            c.create_text(ion["x"], ion["y"],
                          text=text, fill="white",
                          font=("Segoe UI", 8, "bold"))

        c.create_text(w // 2, 10,
                      text=f"U = {int(self.voltage)} В · катионы и анионы",
                      font=("Segoe UI", 8),
                      fill=MUTED)

    def _draw_gas(self):
        c = self.canvas_gas
        c.delete("all")
        w, h = 380, 320

        # Электроды
        self._draw_electrodes(c, w, h)

        # Атомы (серые)
        for a in self.gas_atoms:
            c.create_oval(a["x"] - 3, a["y"] - 3,
                          a["x"] + 3, a["y"] + 3,
                          fill=ATOM, outline="")

        # Ионы (цветные)
        for ion in self.gas_ions:
            if ion["sign"] > 0:
                color = ION_POS
                text = "+"
            else:
                color = ION_NEG
                text = "−"

            c.create_oval(ion["x"] - 6, ion["y"] - 6,
                          ion["x"] + 6, ion["y"] + 6,
                          fill=color, outline="white", width=1)
            c.create_text(ion["x"], ion["y"],
                          text=text, fill="white",
                          font=("Segoe UI", 7, "bold"))

        # Электроны (синие)
        for e in self.gas_electrons:
            c.create_oval(e["x"] - 4, e["y"] - 4,
                          e["x"] + 4, e["y"] + 4,
                          fill=ELECTRON, outline="")
            c.create_text(e["x"], e["y"],
                          text="−", fill="white",
                          font=("Segoe UI", 6, "bold"))

        # Плазма (ионизация при высоком U)
        if self.voltage > 30:
            c.create_text(w // 2, h - 8,
                          text="⚡ Ионизация газа",
                          font=("Segoe UI", 9, "bold"),
                          fill=ORANGE)

        c.create_text(w // 2, 10,
                      text=f"U = {int(self.voltage)} В · "
                           f"{'ионизация' if self.voltage > 30 else 'слабый ток'}",
                      font=("Segoe UI", 8),
                      fill=MUTED)

    # ════════════════════════════════════════════════════════════
    # МЕТРИКИ
    # ════════════════════════════════════════════════════════════
    def _update_metrics(self):
        # Условные значения силы тока
        # Металлы — линейная зависимость
        i_metal = self.voltage * 0.4
        # Электролиты — квадратичная (закон Ома для электролитов сложнее)
        i_electro = (self.voltage ** 1.2) * 0.1
        # Газы — нелинейная (ионизация при высоком U)
        if self.voltage < 10:
            i_gas = self.voltage * 0.01
        elif self.voltage < 30:
            i_gas = self.voltage * 0.05
        else:
            i_gas = 1.5 + (self.voltage - 30) * 0.3

        self.m_metal.config(text=f"I ≈ {i_metal:.1f} мА")
        self.m_electro.config(text=f"I ≈ {i_electro:.1f} мА")
        self.m_gas.config(text=f"I ≈ {i_gas:.1f} мА")


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = CurrentInMediaApp(root)
    root.mainloop()
