import tkinter as tk
import math
import random
from datetime import datetime


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

OK = "#30d158"
WARN = "#ff9f0a"
ALARM = "#ff3b30"
ACCENT = "#0a84ff"
PURPLE = "#8e44ad"

ACCENT_HOVER = "#0066cc"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
RED = "#e53935"
RED_HOVER = "#c62828"
PURPLE_HOVER = "#7d3c98"


# ═══════════════════════════════════════════════════════════════════
# МЕТРИКИ
# ═══════════════════════════════════════════════════════════════════
def mse(original, corrupted):
    """Среднеквадратичная ошибка (Mean Squared Error)."""
    total = 0
    count = 0
    for y in range(len(original)):
        for x in range(len(original[0])):
            r1, g1, b1 = original[y][x]
            r2, g2, b2 = corrupted[y][x]
            total += (r1 - r2) ** 2 + (g1 - g2) ** 2 + (b1 - b2) ** 2
            count += 3
    return total / count if count else 0


def psnr(original, corrupted, max_val=255):
    """Пиковое отношение сигнал/шум (Peak Signal-to-Noise Ratio)."""
    m = mse(original, corrupted)
    if m == 0:
        return float("inf")
    return 10 * math.log10((max_val ** 2) / m)


def ssim(original, corrupted, window=8):
    """
    Структурное сходство (Structural Similarity Index).
    Упрощённая реализация: среднее по блокам window×window.
    """
    h = len(original)
    w = len(original[0])

    # Константы для стабильности
    C1 = (0.01 * 255) ** 2
    C2 = (0.03 * 255) ** 2

    total_ssim = 0
    blocks = 0

    for by in range(0, h - window + 1, window):
        for bx in range(0, w - window + 1, window):
            # Считаем статистику блока
            sum_x = 0
            sum_y = 0
            sum_x2 = 0
            sum_y2 = 0
            sum_xy = 0
            n = 0

            for dy in range(window):
                for dx in range(window):
                    px1 = original[by + dy][bx + dx]
                    px2 = corrupted[by + dy][bx + dx]

                    # В оттенках серого (усреднение каналов)
                    v1 = (px1[0] + px1[1] + px1[2]) / 3
                    v2 = (px2[0] + px2[1] + px2[2]) / 3

                    sum_x += v1
                    sum_y += v2
                    sum_x2 += v1 * v1
                    sum_y2 += v2 * v2
                    sum_xy += v1 * v2
                    n += 1

            mean_x = sum_x / n
            mean_y = sum_y / n
            var_x = (sum_x2 / n) - mean_x ** 2
            var_y = (sum_y2 / n) - mean_y ** 2
            cov = (sum_xy / n) - mean_x * mean_y

            # Формула SSIM
            numerator = (2 * mean_x * mean_y + C1) * (2 * cov + C2)
            denominator = (mean_x ** 2 + mean_y ** 2 + C1) * \
                          (var_x + var_y + C2)

            if denominator != 0:
                total_ssim += numerator / denominator
                blocks += 1

    return total_ssim / blocks if blocks else 0


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class ImageQualityApp:
    def __init__(self, root):
        self.root = root
        root.title("Анализ искажений: PSNR и SSIM")
        root.geometry("1180x900")
        root.minsize(1100, 860)
        root.configure(bg=BG)
        root.resizable(False, False)

        # Изображения
        self.image_w = 260
        self.image_h = 260
        self.original = []
        self.corrupted = []

        self._generate_image()
        self._build_ui()
        self._draw_all()
        self._update_metrics()

    # ─── Генерация исходного изображения ────────────────────────
    def _generate_image(self):
        w, h = self.image_w, self.image_h
        for y in range(h):
            row = []
            for x in range(w):
                r = int(255 * x / w)
                g = int(255 * y / h)
                b = int(255 * (1 - (x + y) / (2 * w)))

                cx, cy = w // 2, h // 2
                if (x - cx) ** 2 + (y - cy) ** 2 < 60 ** 2:
                    r, g, b = 255, 200, 50

                if 30 < x < 90 and 30 < y < 90:
                    r, g, b = 50, 150, 255

                if 170 < x < 230 and 170 < y < 230:
                    r, g, b = 255, 80, 120

                row.append((r, g, b))
            self.original.append(row)

        self.corrupted = [[px for px in row] for row in self.original]

    # ─── UI ─────────────────────────────────────────────────────
    def _build_ui(self):
        # Заголовок
        tk.Label(self.root, text="Анализ искажений: PSNR и SSIM",
                 font=("Segoe UI", 15, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(12, 2))

        tk.Label(self.root,
                 text="Сравнение оригинала с искажённым изображением",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 8))

        # ─── Основная область ──────────────────────────────────
        main = tk.Frame(self.root, bg=BG)
        main.pack(fill="both", expand=True, padx=20, pady=(0, 10))

        # ═══ Изображения (3 в ряд) ══════════════════════════════
        imgs_row = tk.Frame(main, bg=BG)
        imgs_row.pack(fill="x", pady=(0, 10))

        self.orig_canvas = self._image_card(imgs_row, "ОРИГИНАЛ", MUTED)
        self.cor_canvas = self._image_card(imgs_row, "ИСКАЖЁННОЕ", ALARM)
        self.diff_canvas = self._image_card(imgs_row, "КАРТА РАЗНИЦЫ", PURPLE)

        # ═══ Метрики ════════════════════════════════════════════
        metrics_card = tk.Frame(main, bg=CARD,
                                highlightthickness=1,
                                highlightbackground=BORDER)
        metrics_card.pack(fill="x", pady=(0, 10))

        tk.Label(metrics_card, text="МЕТРИКИ КАЧЕСТВА",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=16, pady=(10, 4))

        metrics_inner = tk.Frame(metrics_card, bg=CARD)
        metrics_inner.pack(fill="x", padx=16, pady=(0, 12))

        self.m_mse = self._metric(metrics_inner, "MSE", "—", ACCENT)
        self.m_psnr = self._metric(metrics_inner, "PSNR", "—", GREEN)
        self.m_ssim = self._metric(metrics_inner, "SSIM", "—", PURPLE)
        self.m_quality = self._metric(metrics_inner, "Оценка", "—", MUTED)

        # ═══ Управление ═════════════════════════════════════════
        ctrl = tk.Frame(main, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        ctrl.pack(fill="x", pady=(0, 10))

        inner = tk.Frame(ctrl, bg=CARD)
        inner.pack(fill="x", padx=16, pady=10)

        tk.Label(inner, text="% ошибочных битов:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 8))

        self.bit_lbl = tk.Label(inner, text="0%",
                                font=("Consolas", 12, "bold"),
                                bg=CARD, fg=ALARM, width=5)
        self.bit_lbl.pack(side="left", padx=(0, 8))

        self.bit_scale = tk.Scale(inner, from_=0, to=30, resolution=1,
                                  orient="horizontal",
                                  length=350, showvalue=False,
                                  bg=CARD, fg=TEXT, troughcolor="#ececf0",
                                  activebackground=ALARM,
                                  highlightthickness=0, bd=0,
                                  sliderlength=16, width=8,
                                  command=self._on_bit_change)
        self.bit_scale.set(0)
        self.bit_scale.pack(side="left", padx=(0, 12))

        self._btn(inner, "🎯 Исказить", ORANGE, ORANGE_HOVER,
                  self.corrupt).pack(side="left", padx=2)
        self._btn(inner, "↻ Сброс", RED, RED_HOVER,
                  self.reset).pack(side="left", padx=2)
        self._btn(inner, "💾 Сохранить", PURPLE, PURPLE_HOVER,
                  self.save).pack(side="left", padx=2)

        # ═══ График ═════════════════════════════════════════════
        graph_card = tk.Frame(main, bg=CARD,
                              highlightthickness=1,
                              highlightbackground=BORDER)
        graph_card.pack(fill="both", expand=True)

        tk.Label(graph_card, text="ЗАВИСИМОСТЬ PSNR И SSIM ОТ % ШУМА",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=16, pady=(10, 4))

        self.graph_canvas = tk.Canvas(graph_card, height=180,
                                      bg="white", highlightthickness=0)
        self.graph_canvas.pack(fill="x", padx=16, pady=(0, 12))

        # Первичная отрисовка графика
        self._draw_graph()

    def _image_card(self, parent, title, color):
        frame = tk.Frame(parent, bg=CARD,
                         highlightthickness=1,
                         highlightbackground=BORDER)
        frame.pack(side="left", fill="both", expand=True, padx=4)

        tk.Label(frame, text=title,
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=color).pack(pady=(8, 4))

        canvas = tk.Canvas(frame,
                           width=self.image_w,
                           height=self.image_h,
                           bg="#fafafa", highlightthickness=0)
        canvas.pack(padx=8, pady=(0, 8))

        return canvas

    def _metric(self, parent, label, value, color):
        f = tk.Frame(parent, bg=CARD)
        f.pack(side="left", padx=(0, 30))

        tk.Label(f, text=label,
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED).pack(anchor="w")

        lbl = tk.Label(f, text=value,
                       font=("Consolas", 16, "bold"),
                       bg=CARD, fg=color, anchor="w")
        lbl.pack(anchor="w")
        return lbl

    def _btn(self, parent, text, bg, hover, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 10, "bold"),
                        bg=bg, fg="#ffffff",
                        activebackground=hover,
                        activeforeground="#ffffff",
                        bd=0, padx=12, pady=8, cursor="hand2",
                        command=command)

        def on_enter(e):
            btn.config(bg=hover)

        def on_leave(e):
            btn.config(bg=bg)

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        return btn

    # ════════════════════════════════════════════════════════════
    # ОТРИСОВКА ИЗОБРАЖЕНИЙ
    # ════════════════════════════════════════════════════════════
    def _draw_image(self, canvas, pixels):
        canvas.delete("all")
        for y in range(0, self.image_h, 2):
            for x in range(0, self.image_w, 2):
                r, g, b = pixels[y][x]
                color = f"#{r:02x}{g:02x}{b:02x}"
                canvas.create_rectangle(x, y, x + 2, y + 2,
                                        fill=color, outline="")

    def _draw_diff(self):
        """Карта разницы: чем больше отличие, тем краснее пиксель."""
        self.diff_canvas.delete("all")
        for y in range(0, self.image_h, 2):
            for x in range(0, self.image_w, 2):
                r1, g1, b1 = self.original[y][x]
                r2, g2, b2 = self.corrupted[y][x]
                diff = abs(r1 - r2) + abs(g1 - g2) + abs(b1 - b2)
                # 0 → белый, 765 (макс) → красный
                intensity = min(255, int(diff / 3))
                color = f"#{255:02x}{255 - intensity:02x}{255 - intensity:02x}"
                self.diff_canvas.create_rectangle(x, y, x + 2, y + 2,
                                                  fill=color, outline="")

    def _draw_all(self):
        self._draw_image(self.orig_canvas, self.original)
        self._draw_image(self.cor_canvas, self.corrupted)
        self._draw_diff()

    # ════════════════════════════════════════════════════════════
    # ИСКАЖЕНИЕ
    # ════════════════════════════════════════════════════════════
    def _on_bit_change(self, v):
        self.bit_lbl.config(text=f"{float(v):.0f}%")

    def corrupt(self):
        pct = float(self.bit_scale.get()) / 100.0
        if pct == 0:
            self.corrupted = [[px for px in row] for row in self.original]
        else:
            corrupted = []
            for y in range(self.image_h):
                row = []
                for x in range(self.image_w):
                    r, g, b = self.original[y][x]
                    r = self._corrupt_byte(r, pct)
                    g = self._corrupt_byte(g, pct)
                    b = self._corrupt_byte(b, pct)
                    row.append((r, g, b))
                corrupted.append(row)
            self.corrupted = corrupted

        self._draw_all()
        self._update_metrics()

    def _corrupt_byte(self, byte, pct):
        for bit in range(8):
            if random.random() < pct:
                byte ^= (1 << bit)
        return byte

    def reset(self):
        self.corrupted = [[px for px in row] for row in self.original]
        self.bit_scale.set(0)
        self._draw_all()
        self._update_metrics()

    # ════════════════════════════════════════════════════════════
    # МЕТРИКИ
    # ════════════════════════════════════════════════════════════
    def _update_metrics(self):
        # MSE
        m = mse(self.original, self.corrupted)
        self.m_mse.config(text=f"{m:.2f}")

        # PSNR
        p = psnr(self.original, self.corrupted)
        if p == float("inf"):
            self.m_psnr.config(text="∞ (идеал)", fg=OK)
            quality_text = "Идеально"
            quality_color = OK
        else:
            self.m_psnr.config(text=f"{p:.2f} дБ")
            if p >= 40:
                quality_text = "Отлично"
                quality_color = OK
            elif p >= 30:
                quality_text = "Хорошо"
                quality_color = OK
            elif p >= 20:
                quality_text = "Плохо"
                quality_color = WARN
            else:
                quality_text = "Нечитаемо"
                quality_color = ALARM

        # SSIM
        s = ssim(self.original, self.corrupted)
        self.m_ssim.config(text=f"{s:.4f}")
        if s >= 0.9:
            self.m_ssim.config(fg=OK)
        elif s >= 0.7:
            self.m_ssim.config(fg=OK)
        elif s >= 0.5:
            self.m_ssim.config(fg=WARN)
        else:
            self.m_ssim.config(fg=ALARM)

        self.m_quality.config(text=quality_text, fg=quality_color)

    # ════════════════════════════════════════════════════════════
    # ГРАФИК
    # ════════════════════════════════════════════════════════════
    def _draw_graph(self):
        c = self.graph_canvas
        c.delete("all")

        W = 1100
        H = 180
        x0, x1 = 50, W - 50
        y0, y1 = 20, H - 30

        # Собираем данные: PSNR и SSIM при разном % шума
        psnr_values = []
        ssim_values = []
        noise_levels = [0, 1, 2, 3, 5, 8, 10, 15, 20, 25, 30]

        # Временно сохраняем текущее
        saved_corrupted = self.corrupted

        for pct in noise_levels:
            # Генерируем искажение
            corrupted = []
            for y in range(self.image_h):
                row = []
                for x in range(self.image_w):
                    r, g, b = self.original[y][x]
                    r = self._corrupt_byte(r, pct / 100.0)
                    g = self._corrupt_byte(g, pct / 100.0)
                    b = self._corrupt_byte(b, pct / 100.0)
                    row.append((r, g, b))
                corrupted.append(row)

            p = psnr(self.original, corrupted)
            if p == float("inf"):
                p = 60  # для графика
            psnr_values.append(min(60, p))

            s = ssim(self.original, corrupted)
            ssim_values.append(s)

        # Восстанавливаем
        self.corrupted = saved_corrupted

        # Оси
        c.create_line(x0, y1, x1, y1, fill="#000", width=1)
        c.create_line(x0, y0, x0, y1, fill="#000", width=1)

        # Подписи
        c.create_text(x0 - 30, y0 + 10,
                      text="PSNR", fill=GREEN, anchor="w",
                      font=("Segoe UI", 9, "bold"))
        c.create_text(x0 - 30, y0 + 30,
                      text="SSIM", fill=PURPLE, anchor="w",
                      font=("Segoe UI", 9, "bold"))

        # PSNR — линия (макс 60 дБ)
        psnr_points = []
        for i, val in enumerate(psnr_values):
            px = x0 + (x1 - x0) * i / (len(noise_levels) - 1)
            py = y1 - (val / 60) * (y1 - y0)
            psnr_points.extend([px, py])
        c.create_line(*psnr_points, fill=GREEN, width=2, smooth=True)

        # SSIM — линия (0…1)
        ssim_points = []
        for i, val in enumerate(ssim_values):
            px = x0 + (x1 - x0) * i / (len(noise_levels) - 1)
            py = y1 - val * (y1 - y0) * 0.9
            ssim_points.extend([px, py])
        c.create_line(*ssim_points, fill=PURPLE, width=2, smooth=True)

        # Точки
        for i, val in enumerate(psnr_values):
            px = x0 + (x1 - x0) * i / (len(noise_levels) - 1)
            py = y1 - (val / 60) * (y1 - y0)
            c.create_oval(px - 3, py - 3, px + 3, py + 3,
                          fill=GREEN, outline="")

        for i, val in enumerate(ssim_values):
            px = x0 + (x1 - x0) * i / (len(noise_levels) - 1)
            py = y1 - val * (y1 - y0) * 0.9
            c.create_oval(px - 3, py - 3, px + 3, py + 3,
                          fill=PURPLE, outline="")

        # Подписи X
        for i, pct in enumerate(noise_levels):
            px = x0 + (x1 - x0) * i / (len(noise_levels) - 1)
            c.create_text(px, y1 + 12,
                          text=f"{pct}%",
                          font=("Segoe UI", 8),
                          fill=MUTED)

        # Подписи Y
        for i in range(7):
            val = 60 * i / 6
            py = y1 - (val / 60) * (y1 - y0)
            c.create_text(x0 - 8, py,
                          text=f"{int(val)}",
                          font=("Segoe UI", 8),
                          fill=MUTED, anchor="e")

        # Заголовок оси X
        c.create_text((x0 + x1) / 2, H - 5,
                      text="% ошибочных битов",
                      font=("Segoe UI", 9), fill=TEXT)

    # ════════════════════════════════════════════════════════════
    # СОХРАНЕНИЕ
    # ════════════════════════════════════════════════════════════
    def save(self):
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text", "*.txt")],
            initialfile=f"metrics_{datetime.now().strftime('%H%M%S')}.txt")
        if not path:
            return

        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write("ОТЧЁТ ПО КАЧЕСТВУ ИЗОБРАЖЕНИЯ\n")
                f.write(f"Дата: {datetime.now().strftime('%d.%m.%Y %H:%M')}\n")
                f.write("=" * 50 + "\n\n")
                f.write(f"% ошибочных битов: {self.bit_scale.get()}%\n\n")
                f.write(f"MSE:  {mse(self.original, self.corrupted):.2f}\n")
                f.write(f"PSNR: {psnr(self.original, self.corrupted):.2f} дБ\n")
                f.write(f"SSIM: {ssim(self.original, self.corrupted):.4f}\n\n")

                f.write("Зависимость от % шума:\n")
                f.write("-" * 30 + "\n")
                for pct in [0, 1, 2, 3, 5, 8, 10, 15, 20, 25, 30]:
                    corrupted = []
                    for y in range(self.image_h):
                        row = []
                        for x in range(self.image_w):
                            r, g, b = self.original[y][x]
                            r = self._corrupt_byte(r, pct / 100.0)
                            g = self._corrupt_byte(g, pct / 100.0)
                            b = self._corrupt_byte(b, pct / 100.0)
                            row.append((r, g, b))
                        corrupted.append(row)

                    p = psnr(self.original, corrupted)
                    s = ssim(self.original, corrupted)
                    p_str = "∞" if p == float("inf") else f"{p:.2f}"
                    f.write(f"  {pct:>2}%  PSNR = {p_str:>8} дБ  "
                            f"SSIM = {s:.4f}\n")

            self.m_quality.config(text="Сохранено", fg=OK)
        except Exception as e:
            self.m_quality.config(text=f"Ошибка: {e}", fg=ALARM)


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = ImageQualityApp(root)
    root.mainloop()
