import tkinter as tk
import math
import random
from datetime import datetime


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

CHART_COLORS = [
    "#0a84ff", "#30d158", "#ff9f0a", "#e53935",
    "#8e44ad", "#00bcd4", "#fdd835", "#ff7043",
    "#26a69a", "#ec407a",
]

AXIS = "#000000"
GRID = "#ececf0"

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
RED = "#e53935"
RED_HOVER = "#c62828"
PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"


# ═══════════════════════════════════════════════════════════════════
# КОМПОНЕНТ CHART
# ═══════════════════════════════════════════════════════════════════
class ChartComponent:
    """
    Компонент для построения диаграмм: столбчатых и круговых.
    Полностью на Canvas — без внешних библиотек.
    """
    def __init__(self, canvas):
        self.canvas = canvas
        self.data = []          # [(label, value)]
        self.chart_type = "bar" # bar / hbar / pie / donut
        self.colors = CHART_COLORS
        self.show_grid = True
        self.show_legend = True
        self.show_values = True
        self.animation_progress = 1.0

    def set_data(self, data):
        self.data = data

    def set_type(self, chart_type):
        self.chart_type = chart_type

    def animate(self):
        """Плавная анимация от 0 до 1."""
        self.animation_progress = 0.0
        self._animate_step()

    def _animate_step(self):
        if self.animation_progress < 1.0:
            self.animation_progress += 0.05
            self.draw()
            self.canvas.after(20, self._animate_step)

    def draw(self):
        c = self.canvas
        c.delete("all")

        W = c.winfo_width()
        H = c.winfo_height()
        if W < 50 or H < 50:
            return

        if not self.data:
            c.create_text(W // 2, H // 2,
                          text="Нет данных",
                          font=("Segoe UI", 12), fill=MUTED)
            return

        if self.chart_type == "bar":
            self._draw_bar(W, H, horizontal=False)
        elif self.chart_type == "hbar":
            self._draw_bar(W, H, horizontal=True)
        elif self.chart_type == "pie":
            self._draw_pie(W, H, donut=False)
        elif self.chart_type == "donut":
            self._draw_pie(W, H, donut=True)

    # ─── Столбчатая ────────────────────────────────────────────
    def _draw_bar(self, W, H, horizontal=False):
        c = self.canvas

        # Отступы
        pad_left = 60
        pad_right = 40
        pad_top = 30
        pad_bottom = 60
        if horizontal:
            pad_left = 100
            pad_bottom = 40

        x0 = pad_left
        x1 = W - pad_right
        y0 = pad_top
        y1 = H - pad_bottom

        max_val = max(v for _, v in self.data) or 1
        n = len(self.data)

        if not horizontal:
            # ─── Вертикальная ─────────────────────────────────
            # Сетка
            if self.show_grid:
                for i in range(6):
                    y = y0 + (y1 - y0) * i / 5
                    c.create_line(x0, y, x1, y, fill=GRID)
                    val = max_val * (5 - i) / 5
                    c.create_text(x0 - 8, y, text=f"{val:.0f}",
                                  anchor="e", font=("Segoe UI", 8),
                                  fill=MUTED)

            # Оси
            c.create_line(x0, y0 - 10, x0, y1, fill=AXIS, width=1,
                          arrow="last", arrowshape=(8, 10, 3))
            c.create_line(x0, y1, x1 + 10, y1, fill=AXIS, width=1,
                          arrow="last", arrowshape=(8, 10, 3))

            # Столбцы
            bar_w = (x1 - x0) / n * 0.7
            gap = (x1 - x0) / n

            for i, (label, value) in enumerate(self.data):
                h = (y1 - y0) * value / max_val * self.animation_progress
                x = x0 + gap * i + (gap - bar_w) / 2
                y = y1 - h

                color = self.colors[i % len(self.colors)]
                c.create_rectangle(x, y, x + bar_w, y1,
                                   fill=color, outline="")

                # Значение
                if self.show_values and self.animation_progress > 0.9:
                    c.create_text(x + bar_w / 2, y - 10,
                                  text=f"{value:.0f}",
                                  font=("Segoe UI", 9, "bold"),
                                  fill=color)

                # Подпись
                c.create_text(x + bar_w / 2, y1 + 15,
                              text=label,
                              font=("Segoe UI", 9), fill=TEXT)
        else:
            # ─── Горизонтальная ───────────────────────────────
            if self.show_grid:
                for i in range(6):
                    x = x0 + (x1 - x0) * i / 5
                    c.create_line(x, y0, x, y1, fill=GRID)
                    val = max_val * i / 5
                    c.create_text(x, y1 + 15, text=f"{val:.0f}",
                                  anchor="n", font=("Segoe UI", 8),
                                  fill=MUTED)

            c.create_line(x0, y1, x1 + 10, y1, fill=AXIS, width=1,
                          arrow="last", arrowshape=(8, 10, 3))
            c.create_line(x0, y0 - 10, x0, y1, fill=AXIS, width=1,
                          arrow="last", arrowshape=(8, 10, 3))

            bar_h = (y1 - y0) / n * 0.7
            gap = (y1 - y0) / n

            for i, (label, value) in enumerate(self.data):
                w = (x1 - x0) * value / max_val * self.animation_progress
                y = y0 + gap * i + (gap - bar_h) / 2

                color = self.colors[i % len(self.colors)]
                c.create_rectangle(x0, y, x0 + w, y + bar_h,
                                   fill=color, outline="")

                if self.show_values and self.animation_progress > 0.9:
                    c.create_text(x0 + w + 10, y + bar_h / 2,
                                  text=f"{value:.0f}",
                                  font=("Segoe UI", 9, "bold"),
                                  fill=color, anchor="w")

                c.create_text(x0 - 8, y + bar_h / 2,
                              text=label, anchor="e",
                              font=("Segoe UI", 9), fill=TEXT)

    # ─── Круговая / Кольцевая ─────────────────────────────────
    def _draw_pie(self, W, H, donut=False):
        c = self.canvas

        # Размеры
        if self.show_legend:
            pie_w = W - 200
        else:
            pie_w = W

        cx = pie_w // 2
        cy = H // 2
        r = min(pie_w, H) // 2 - 40

        if r < 20:
            return

        total = sum(v for _, v in self.data) or 1
        start_angle = 90  # начинаем сверху

        for i, (label, value) in enumerate(self.data):
            angle = 360 * value / total * self.animation_progress
            color = self.colors[i % len(self.colors)]

            # Сектор
            c.create_arc(cx - r, cy - r, cx + r, cy + r,
                         start=start_angle, extent=-angle,
                         fill=color, outline="white", width=2)

            # Процент на секторе
            if angle > 20 and self.animation_progress > 0.9:
                mid_angle = start_angle - angle / 2
                mid_rad = math.radians(mid_angle)
                tx = cx + r * 0.65 * math.cos(mid_rad)
                ty = cy - r * 0.65 * math.sin(mid_rad)
                pct = 100 * value / total
                c.create_text(tx, ty, text=f"{pct:.0f}%",
                              font=("Segoe UI", 10, "bold"),
                              fill="white")

            start_angle -= angle

        # Кольцо — белый круг в центре
        if donut:
            inner_r = r * 0.5
            c.create_oval(cx - inner_r, cy - inner_r,
                          cx + inner_r, cy + inner_r,
                          fill="white", outline="")

            # Подпись в центре
            c.create_text(cx, cy - 10, text="Всего",
                          font=("Segoe UI", 9), fill=MUTED)
            c.create_text(cx, cy + 10, text=f"{total:.0f}",
                          font=("Segoe UI", 16, "bold"),
                          fill=TEXT)

        # Легенда
        if self.show_legend:
            lx = pie_w + 20
            ly = 40
            for i, (label, value) in enumerate(self.data):
                color = self.colors[i % len(self.colors)]
                c.create_rectangle(lx, ly, lx + 16, ly + 16,
                                   fill=color, outline="")
                c.create_text(lx + 24, ly + 8,
                              text=f"{label}: {value:.0f}",
                              anchor="w",
                              font=("Segoe UI", 9), fill=TEXT)
                ly += 28


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class ChartExplorerApp:
    def __init__(self, root):
        self.root = root
        root.title("Исследование компонента Chart")
        root.geometry("1180x840")
        root.minsize(1080, 800)
        root.configure(bg=BG)
        root.resizable(False, False)

        # Начальные данные
        self.data = [
            ("Январь", 45),
            ("Февраль", 78),
            ("Март", 62),
            ("Апрель", 90),
            ("Май", 54),
        ]

        self._build_ui()
        self.root.after(100, self._initial_draw)

    def _initial_draw(self):
        self.chart.animate()

    # ════════════════════════════════════════════════════════════
    # UI
    # ════════════════════════════════════════════════════════════
    def _build_ui(self):
        tk.Label(self.root, text="Исследование компонента Chart",
                 font=("Segoe UI", 15, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(10, 2))

        tk.Label(self.root,
                 text="Столбчатые · Горизонтальные · Круговые · Кольцевые",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 8))

        main = tk.Frame(self.root, bg=BG)
        main.pack(fill="both", expand=True, padx=20, pady=(0, 8))

        # ─── Canvas диаграммы ──────────────────────────────────
        canvas_card = tk.Frame(main, bg=CARD,
                               highlightthickness=1,
                               highlightbackground=BORDER)
        canvas_card.pack(side="left", fill="both", expand=True, padx=(0, 8))

        tk.Label(canvas_card, text="ДИАГРАММА",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=14, pady=(10, 4))

        self.canvas = tk.Canvas(canvas_card,
                                bg="white",
                                highlightthickness=0)
        self.canvas.pack(padx=10, pady=(0, 10), fill="both", expand=True)

        self.chart = ChartComponent(self.canvas)
        self.chart.set_data(self.data)

        self.canvas.bind("<Configure>", lambda e: self.chart.draw())

        # ─── Панель управления ────────────────────────────────
        right = tk.Frame(main, bg=BG)
        right.pack(side="left", fill="y")

        # Тип диаграммы
        type_card = tk.Frame(right, bg=CARD,
                             highlightthickness=1,
                             highlightbackground=BORDER)
        type_card.pack(fill="x", pady=(0, 8))

        tk.Label(type_card, text="ТИП ДИАГРАММЫ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=14, pady=(10, 4))

        self.chart_type = tk.StringVar(value="bar")
        types = [
            ("📊 Столбчатая", "bar"),
            ("📋 Горизонтальная", "hbar"),
            ("🥧 Круговая", "pie"),
            ("🍩 Кольцевая", "donut"),
        ]

        for text, val in types:
            rb = tk.Radiobutton(type_card, text=text,
                                variable=self.chart_type, value=val,
                                font=("Segoe UI", 10),
                                bg=CARD, fg=TEXT,
                                activebackground=CARD,
                                activeforeground=ACCENT,
                                selectcolor=CARD,
                                anchor="w",
                                bd=0, highlightthickness=0,
                                cursor="hand2",
                                command=self._on_type_change)
            rb.pack(fill="x", padx=14, pady=2)

        tk.Frame(type_card, bg=CARD, height=6).pack()

        # Опции
        opts_card = tk.Frame(right, bg=CARD,
                             highlightthickness=1,
                             highlightbackground=BORDER)
        opts_card.pack(fill="x", pady=(0, 8))

        tk.Label(opts_card, text="ОПЦИИ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=14, pady=(10, 4))

        self.show_grid = tk.BooleanVar(value=True)
        self.show_legend = tk.BooleanVar(value=True)
        self.show_values = tk.BooleanVar(value=True)

        self._cb(opts_card, "Сетка", self.show_grid)
        self._cb(opts_card, "Легенда", self.show_legend)
        self._cb(opts_card, "Значения", self.show_values)

        tk.Frame(opts_card, bg=CARD, height=6).pack()

        # Данные
        data_card = tk.Frame(right, bg=CARD,
                             highlightthickness=1,
                             highlightbackground=BORDER)
        data_card.pack(fill="x", pady=(0, 8))

        tk.Label(data_card, text="ДАННЫЕ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=14, pady=(10, 4))

        self.data_frame = tk.Frame(data_card, bg=CARD)
        self.data_frame.pack(fill="x", padx=14, pady=(0, 8))

        self._render_data()

        # Кнопки данных
        btn_row = tk.Frame(data_card, bg=CARD)
        btn_row.pack(fill="x", padx=14, pady=(0, 12))

        self._btn(btn_row, "+ Добавить", GREEN, GREEN_HOVER,
                  self.add_data).pack(side="left", padx=(0, 4))
        self._btn(btn_row, "🎲 Случайно", ORANGE, ORANGE_HOVER,
                  self.randomize).pack(side="left", padx=4)
        self._btn(btn_row, "↻ Сброс", RED, RED_HOVER,
                  self.reset_data).pack(side="left", padx=4)

        # Экспорт
        self._btn(right, "💾 Экспорт диаграммы",
                  PURPLE, PURPLE_HOVER,
                  self.export).pack(fill="x", pady=(0, 8))

    def _cb(self, parent, text, var):
        cb = tk.Checkbutton(parent, text=text,
                            variable=var,
                            font=("Segoe UI", 10),
                            bg=CARD, fg=TEXT,
                            activebackground=CARD,
                            activeforeground=ACCENT,
                            selectcolor=CARD,
                            anchor="w",
                            bd=0, highlightthickness=0,
                            cursor="hand2",
                            command=self._update_options)
        cb.pack(fill="x", padx=14, pady=2)

    def _btn(self, parent, text, bg, hover, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 10, "bold"),
                        bg=bg, fg="white",
                        activebackground=hover,
                        activeforeground="white",
                        bd=0, padx=12, pady=8, cursor="hand2",
                        command=command)

        def on_enter(e): btn.config(bg=hover)

        def on_leave(e): btn.config(bg=bg)

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        return btn

    # ════════════════════════════════════════════════════════════
    # ДАННЫЕ
    # ════════════════════════════════════════════════════════════
    def _render_data(self):
        for w in self.data_frame.winfo_children():
            w.destroy()

        for i, (label, value) in enumerate(self.data):
            row = tk.Frame(self.data_frame, bg=CARD)
            row.pack(fill="x", pady=2)

            color = self.chart.colors[i % len(self.chart.colors)]
            tk.Label(row, text="●",
                     font=("Segoe UI", 12),
                     bg=CARD, fg=color).pack(side="left", padx=(0, 4))

            tk.Label(row, text=label,
                     font=("Segoe UI", 9),
                     bg=CARD, fg=TEXT, width=8, anchor="w"
                     ).pack(side="left")

            scale = tk.Scale(row, from_=0, to=100,
                             orient="horizontal",
                             length=80, showvalue=True,
                             bg=CARD, fg=TEXT,
                             troughcolor="#ececf0",
                             activebackground=color,
                             highlightthickness=0, bd=0,
                             sliderlength=12, width=6,
                             font=("Consolas", 8),
                             command=lambda v, idx=i: self._on_value_change(idx, float(v)))
            scale.set(value)
            scale.pack(side="left", padx=(0, 4))

            # Удалить
            tk.Button(row, text="×",
                      font=("Segoe UI", 10, "bold"),
                      bg=CARD, fg=RED,
                      activebackground=CARD,
                      activeforeground=RED,
                      bd=0, padx=4, cursor="hand2",
                      command=lambda idx=i: self.remove_data(idx),
                      ).pack(side="left")

    def _on_value_change(self, idx, value):
        label, _ = self.data[idx]
        self.data[idx] = (label, value)
        self.chart.set_data(self.data)
        self.chart.draw()

    def add_data(self):
        months = ["Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь"]
        used = [label for label, _ in self.data]
        available = [m for m in months if m not in used]
        label = available[0] if available else f"Серия {len(self.data) + 1}"
        self.data.append((label, random.randint(20, 90)))
        self.chart.set_data(self.data)
        self._render_data()
        self.chart.draw()

    def remove_data(self, idx):
        if len(self.data) > 1:
            self.data.pop(idx)
            self.chart.set_data(self.data)
            self._render_data()
            self.chart.draw()

    def randomize(self):
        self.data = [(label, random.randint(10, 100)) for label, _ in self.data]
        self.chart.set_data(self.data)
        self._render_data()
        self.chart.animate()

    def reset_data(self):
        self.data = [
            ("Январь", 45),
            ("Февраль", 78),
            ("Март", 62),
            ("Апрель", 90),
            ("Май", 54),
        ]
        self.chart.set_data(self.data)
        self._render_data()
        self.chart.animate()

    # ════════════════════════════════════════════════════════════
    # ОБРАБОТЧИКИ
    # ════════════════════════════════════════════════════════════
    def _on_type_change(self):
        self.chart.set_type(self.chart_type.get())
        self.chart.animate()

    def _update_options(self):
        self.chart.show_grid = self.show_grid.get()
        self.chart.show_legend = self.show_legend.get()
        self.chart.show_values = self.show_values.get()
        self.chart.draw()

    def export(self):
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(
            defaultextension=".ps",
            filetypes=[("PostScript", "*.ps"), ("PNG", "*.png")],
            initialfile=f"chart_{datetime.now().strftime('%H%M%S')}.ps")
        if not path:
            return

        if path.endswith(".png"):
            try:
                from PIL import Image
                ps_path = path.replace(".png", ".ps")
                self.canvas.postscript(file=ps_path, colormode="color")
                img = Image.open(ps_path)
                img.save(path, "PNG")
            except ImportError:
                self.canvas.postscript(file=path.replace(".png", ".ps"),
                                       colormode="color")
        else:
            self.canvas.postscript(file=path, colormode="color")


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = ChartExplorerApp(root)
    root.mainloop()
