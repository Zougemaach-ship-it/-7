import tkinter as tk
import random


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

CANVAS_BG = "#0a0a1a"
SAND_COLORS = ["#f4d03f", "#f5b041", "#eb984e",
               "#e59866", "#f8c471", "#d4ac0d"]
WALL_COLOR = "#4a4a5a"

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
RED = "#e53935"
RED_HOVER = "#c62828"
PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class SandApp:
    def __init__(self, root):
        self.root = root
        root.title("Электронный песок")
        root.geometry("1100x820")
        root.minsize(1000, 780)
        root.configure(bg=BG)
        root.resizable(False, False)

        # Сетка
        self.cell_size = 4
        self.cols = 200
        self.rows = 150

        self.grid = [[0] * self.cols for _ in range(self.rows)]
        self.colors = [[SAND_COLORS[0]] * self.cols for _ in range(self.rows)]

        self.gravity_speed = 1
        self.running = True

        self._build_ui()
        self._start_demo()
        self._animate()

    # ════════════════════════════════════════════════════════════
    # UI
    # ════════════════════════════════════════════════════════════
    def _build_ui(self):
        tk.Label(self.root, text="Физический движок: электронный песок",
                 font=("Segoe UI", 15, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(10, 2))

        tk.Label(self.root,
                 text="Клик — сыпать песок · Песчинки падают под гравитацией",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 8))

        # Canvas
        canvas_card = tk.Frame(self.root, bg=CARD,
                               highlightthickness=1,
                               highlightbackground=BORDER)
        canvas_card.pack(padx=20, pady=(0, 8))

        self.canvas = tk.Canvas(canvas_card,
                                width=self.cols * self.cell_size,
                                height=self.rows * self.cell_size,
                                bg=CANVAS_BG, highlightthickness=0,
                                cursor="hand2")
        self.canvas.pack(padx=10, pady=10)

        # Привязки — на весь Canvas
        self.canvas.bind("<Button-1>", self.on_click)
        self.canvas.bind("<B1-Motion>", self.on_drag)

        # Управление
        ctrl = tk.Frame(self.root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        ctrl.pack(padx=20, pady=(0, 16), fill="x")

        inner = tk.Frame(ctrl, bg=CARD)
        inner.pack(fill="x", padx=16, pady=12)

        tk.Label(inner, text="Скорость:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 8))

        self.speed_lbl = tk.Label(inner, text="1",
                                  font=("Consolas", 12, "bold"),
                                  bg=CARD, fg=ACCENT, width=3)
        self.speed_lbl.pack(side="left", padx=(0, 8))

        self.speed_scale = tk.Scale(inner, from_=1, to=5, resolution=1,
                                    orient="horizontal",
                                    length=150, showvalue=False,
                                    bg=CARD, fg=TEXT, troughcolor="#ececf0",
                                    activebackground=ACCENT,
                                    highlightthickness=0, bd=0,
                                    sliderlength=16, width=8,
                                    command=self._on_speed)
        self.speed_scale.set(1)
        self.speed_scale.pack(side="left", padx=(0, 20))

        self._btn(inner, "⏸ Пауза", ACCENT, ACCENT_HOVER,
                  self.toggle_running).pack(side="left", padx=4)
        self._btn(inner, "🗑 Очистить", RED, RED_HOVER,
                  self.clear).pack(side="left", padx=4)
        self._btn(inner, "⏳ Песочные часы", ORANGE, ORANGE_HOVER,
                  self.set_hourglass).pack(side="left", padx=4)
        self._btn(inner, "🧱 Стена", PURPLE, PURPLE_HOVER,
                  self.set_wall).pack(side="left", padx=4)
        self._btn(inner, "🌧 Дождь", GREEN, GREEN_HOVER,
                  self.sand_rain).pack(side="left", padx=4)

    def _btn(self, parent, text, bg, hover, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 10, "bold"),
                        bg=bg, fg="white",
                        activebackground=hover,
                        activeforeground="white",
                        bd=0, padx=12, pady=8, cursor="hand2",
                        command=command)

        def on_enter(e): btn.config(bg=hover)

        def on_leave(e): btn.config(bg=bg)

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        return btn

    # ════════════════════════════════════════════════════════════
    # СТАРТОВЫЙ ПЕСОК
    # ════════════════════════════════════════════════════════════
    def _start_demo(self):
        """Добавляет начальный песок, чтобы было видно движение."""
        mid_c = self.cols // 2
        for r in range(0, 30):
            for c in range(mid_c - 25, mid_c + 25):
                if random.random() < 0.7:
                    self.grid[r][c] = 1
                    self.colors[r][c] = random.choice(SAND_COLORS)

    # ════════════════════════════════════════════════════════════
    # ОБРАБОТЧИКИ
    # ════════════════════════════════════════════════════════════
    def _on_speed(self, v):
        self.gravity_speed = int(float(v))
        self.speed_lbl.config(text=str(self.gravity_speed))

    def toggle_running(self):
        self.running = not self.running

    def on_click(self, e):
        self._add_sand_at_pixel(e.x, e.y)

    def on_drag(self, e):
        self._add_sand_at_pixel(e.x, e.y)

    def _add_sand_at_pixel(self, px, py):
        """Добавляет песок в радиусе вокруг клика."""
        col = px // self.cell_size
        row = py // self.cell_size

        radius = 4
        for dr in range(-radius, radius + 1):
            for dc in range(-radius, radius + 1):
                if dr * dr + dc * dc > radius * radius:
                    continue
                r = row + dr
                c = col + dc
                if 0 <= r < self.rows and 0 <= c < self.cols:
                    if self.grid[r][c] == 0:
                        self.grid[r][c] = 1
                        self.colors[r][c] = random.choice(SAND_COLORS)

    # ════════════════════════════════════════════════════════════
    # ПРЕСЕТЫ
    # ════════════════════════════════════════════════════════════
    def clear(self):
        for r in range(self.rows):
            for c in range(self.cols):
                self.grid[r][c] = 0
        self._draw()

    def set_hourglass(self):
        """Песочные часы."""
        self.clear()
        mid_r = self.rows // 2
        mid_c = self.cols // 2

        # Воронка сверху
        for r in range(5, mid_r):
            width = int((mid_r - r) * 0.5)
            width = min(width, mid_c - 5)
            for c in range(mid_c - width, mid_c + width + 1):
                if 0 <= c < self.cols:
                    self.grid[r][c] = 2

        # Воронка снизу
        for r in range(mid_r, self.rows - 5):
            width = int((r - mid_r) * 0.5)
            width = min(width, mid_c - 5)
            for c in range(mid_c - width, mid_c + width + 1):
                if 0 <= c < self.cols:
                    self.grid[r][c] = 2

        # Песок сверху
        for r in range(8, mid_r - 5):
            for c in range(mid_c - 30, mid_c + 30):
                if 0 <= c < self.cols and self.grid[r][c] == 0:
                    if random.random() < 0.9:
                        self.grid[r][c] = 1
                        self.colors[r][c] = random.choice(SAND_COLORS)

        self._draw()

    def set_wall(self):
        """Стена."""
        mid_c = self.cols // 2
        for r in range(20, self.rows - 20):
            self.grid[r][mid_c] = 2
            self.grid[r][mid_c + 1] = 2
        self._draw()

    def sand_rain(self):
        """Дождь сверху."""
        for c in range(0, self.cols):
            if random.random() < 0.3:
                if self.grid[0][c] == 0:
                    self.grid[0][c] = 1
                    self.colors[0][c] = random.choice(SAND_COLORS)
        self._draw()

    # ════════════════════════════════════════════════════════════
    # ФИЗИКА
    # ════════════════════════════════════════════════════════════
    def _update_physics(self):
        for _ in range(self.gravity_speed):
            for r in range(self.rows - 2, -1, -1):
                for c in range(self.cols):
                    if self.grid[r][c] != 1:
                        continue

                    # Вниз
                    if self.grid[r + 1][c] == 0:
                        self._move(r, c, r + 1, c)
                        continue

                    # Вниз-влево / вниз-вправо
                    left_free = c > 0 and self.grid[r + 1][c - 1] == 0
                    right_free = c < self.cols - 1 and self.grid[r + 1][c + 1] == 0

                    if left_free and right_free:
                        if random.random() < 0.5:
                            self._move(r, c, r + 1, c - 1)
                        else:
                            self._move(r, c, r + 1, c + 1)
                    elif left_free and random.random() < 0.7:
                        self._move(r, c, r + 1, c - 1)
                    elif right_free and random.random() < 0.7:
                        self._move(r, c, r + 1, c + 1)

    def _move(self, r1, c1, r2, c2):
        self.grid[r2][c2] = self.grid[r1][c1]
        self.colors[r2][c2] = self.colors[r1][c1]
        self.grid[r1][c1] = 0

    # ════════════════════════════════════════════════════════════
    # АНИМАЦИЯ
    # ════════════════════════════════════════════════════════════
    def _animate(self):
        if self.running:
            self._update_physics()
            self._draw()
        self.root.after(30, self._animate)

    def _draw(self):
        c = self.canvas
        c.delete("all")

        cell = self.cell_size
        for r in range(self.rows):
            for col in range(self.cols):
                val = self.grid[r][col]
                if val == 0:
                    continue
                color = self.colors[r][col] if val == 1 else WALL_COLOR

                x1 = col * cell
                y1 = r * cell
                x2 = x1 + cell
                y2 = y1 + cell

                c.create_rectangle(x1, y1, x2, y2,
                                   fill=color, outline="")


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = SandApp(root)
    root.mainloop()
