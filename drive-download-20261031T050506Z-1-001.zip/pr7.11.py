import tkinter as tk
import math
import random
from datetime import datetime


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

GRID = "#ececf0"
AXIS = "#000000"

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
RED = "#e53935"
RED_HOVER = "#c62828"
PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"


# ═══════════════════════════════════════════════════════════════════
# ДАННЫЕ
# ═══════════════════════════════════════════════════════════════════
class WeatherData:
    def __init__(self):
        self.mode = "summer"
        self.temperatures = []
        self.matrix = []
        self._generate()

    def _generate(self):
        # Час суток — ось X (24 часа)
        self.hours = list(range(24))

        # Средняя температура по сезонам
        base = {"winter": -5, "spring": 12, "summer": 25, "autumn": 10}[self.mode]
        amplitude = {"winter": 3, "spring": 8, "summer": 10, "autumn": 7}[self.mode]

        # Дневная температура — синусоида
        self.temperatures = []
        for h in self.hours:
            # Минимум в 4:00, максимум в 14:00
            phase = (h - 4) / 24 * 2 * math.pi
            val = base + amplitude * math.sin(phase - math.pi / 2) + random.uniform(-1, 1)
            self.temperatures.append(round(val, 1))

        # Матрица — 7 дней × 24 часа
        self.days = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]
        self.matrix = []
        for d in range(7):
            row = []
            for h in self.hours:
                phase = (h - 4) / 24 * 2 * math.pi
                day_offset = random.uniform(-3, 3)
                val = base + amplitude * math.sin(phase - math.pi / 2) + day_offset + random.uniform(-1.5, 1.5)
                row.append(round(val, 1))
            self.matrix.append(row)

    def set_mode(self, mode):
        self.mode = mode
        self._generate()


weather = WeatherData()


# ═══════════════════════════════════════════════════════════════════
# ЦВЕТОВЫЕ ФУНКЦИИ
# ═══════════════════════════════════════════════════════════════════
def temp_to_color(t, tmin, tmax):
    """Температура → цвет (синий → голубой → зелёный → жёлтый → красный)."""
    if tmax - tmin < 0.1:
        v = 0.5
    else:
        v = (t - tmin) / (tmax - tmin)
    v = max(0.0, min(1.0, v))

    # Интерполяция по точкам
    stops = [
        (0.0, (0.10, 0.20, 0.70)),   # синий
        (0.25, (0.20, 0.60, 0.90)),  # голубой
        (0.5, (0.30, 0.80, 0.40)),   # зелёный
        (0.75, (0.95, 0.85, 0.20)),  # жёлтый
        (1.0, (0.90, 0.15, 0.15)),   # красный
    ]

    # Находим между какими стопами
    for i in range(len(stops) - 1):
        if stops[i][0] <= v <= stops[i + 1][0]:
            t_local = (v - stops[i][0]) / (stops[i + 1][0] - stops[i][0])
            c1 = stops[i][1]
            c2 = stops[i + 1][1]
            r = int(255 * (c1[0] + (c2[0] - c1[0]) * t_local))
            g = int(255 * (c1[1] + (c2[1] - c1[1]) * t_local))
            b = int(255 * (c1[2] + (c2[2] - c1[2]) * t_local))
            return f"#{r:02x}{g:02x}{b:02x}"

    return "#888888"


def area_to_color(t, tmin, tmax):
    """Цвет для заливки области графика."""
    v = (t - tmin) / (tmax - tmin) if tmax > tmin else 0.5

    # От голубого к оранжевому
    if v < 0.5:
        t_local = v * 2
        r = int(100 + 155 * t_local)
        g = int(180 - 80 * t_local)
        b = int(255 - 155 * t_local)
    else:
        t_local = (v - 0.5) * 2
        r = int(255 - 20 * t_local)
        g = int(100 + 70 * t_local)
        b = int(100 - 70 * t_local)

    return f"#{r:02x}{g:02x}{b:02x}"


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class WeatherVizApp:
    def __init__(self, root):
        self.root = root
        root.title("Метеоданные: график с областями и тепловая карта")
        root.geometry("1280x880")
        root.minsize(1180, 840)
        root.configure(bg=BG)
        root.resizable(False, False)

        self.show_grid = tk.BooleanVar(value=True)
        self._build_ui()
        self.root.after(100, self.redraw)

    # ════════════════════════════════════════════════════════════
    # UI
    # ════════════════════════════════════════════════════════════
    def _build_ui(self):
        tk.Label(self.root, text="Визуализация метеоданных",
                 font=("Segoe UI", 15, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(10, 2))

        tk.Label(self.root,
                 text="График с областями (температура) · Тепловая карта (неделя)",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 8))

        # ─── Панель управления ─────────────────────────────────
        ctrl = tk.Frame(self.root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        ctrl.pack(padx=20, pady=(0, 8), fill="x")

        inner = tk.Frame(ctrl, bg=CARD)
        inner.pack(fill="x", padx=14, pady=10)

        # Сезон
        tk.Label(inner, text="Сезон:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 6))

        self.season = tk.StringVar(value="summer")
        for name, val in [("❄️ Зима", "winter"),
                          ("🌱 Весна", "spring"),
                          ("☀️ Лето", "summer"),
                          ("🍂 Осень", "autumn")]:
            tk.Radiobutton(inner, text=name,
                           variable=self.season, value=val,
                           font=("Segoe UI", 10),
                           bg=CARD, fg=TEXT,
                           activebackground=CARD,
                           activeforeground=ACCENT,
                           selectcolor=CARD,
                           bd=0, highlightthickness=0,
                           cursor="hand2",
                           command=self._on_season_change,
                           ).pack(side="left", padx=(0, 10))

        # Кнопки
        self._btn(inner, "🎲 Обновить данные", ACCENT, ACCENT_HOVER,
                  self._update_data).pack(side="left", padx=(20, 6))
        self._btn(inner, "💾 Экспорт", PURPLE, PURPLE_HOVER,
                  self.export).pack(side="left", padx=6)

        # Сетка
        cb = tk.Checkbutton(inner, text="Сетка",
                            variable=self.show_grid,
                            font=("Segoe UI", 10),
                            bg=CARD, fg=TEXT,
                            activebackground=CARD,
                            activeforeground=ACCENT,
                            selectcolor=CARD,
                            bd=0, highlightthickness=0,
                            cursor="hand2",
                            command=self.redraw)
        cb.pack(side="left", padx=(16, 0))

        # ─── Основная область ─────────────────────────────────
        main = tk.Frame(self.root, bg=BG)
        main.pack(fill="both", expand=True, padx=20, pady=(0, 16))

        # Блок 1 — график с областями
        left = tk.Frame(main, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))

        tk.Label(left, text="ГРАФИК С ОБЛАСТЯМИ · Температура за сутки",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=14, pady=(10, 4))

        self.area_canvas = tk.Canvas(left, bg="white",
                                     highlightthickness=0)
        self.area_canvas.pack(padx=10, pady=(0, 10), fill="both", expand=True)
        self.area_canvas.bind("<Configure>", lambda e: self.redraw())
        self.area_canvas.bind("<Motion>", self.on_area_motion)
        self.area_canvas.bind("<Leave>", self.on_area_leave)

        # Блок 2 — тепловая карта
        right = tk.Frame(main, bg=CARD,
                         highlightthickness=1,
                         highlightbackground=BORDER)
        right.pack(side="left", fill="both", padx=(8, 0))

        tk.Label(right, text="ТЕПЛОВАЯ КАРТА · Неделя × Часы",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=14, pady=(10, 4))

        self.heat_canvas = tk.Canvas(right, bg="white",
                                     width=560, height=440,
                                     highlightthickness=0)
        self.heat_canvas.pack(padx=10, pady=(0, 10))
        self.heat_canvas.bind("<Motion>", self.on_heat_motion)
        self.heat_canvas.bind("<Leave>", self.on_heat_leave)

        # Легенда тепловой карты
        self.legend_frame = tk.Frame(right, bg=CARD)
        self.legend_frame.pack(fill="x", padx=14, pady=(0, 12))

        self.legend_canvas = tk.Canvas(self.legend_frame, bg=CARD,
                                       height=30, width=540,
                                       highlightthickness=0)
        self.legend_canvas.pack()

        # Информация под курсором
        self.info_label = tk.Label(self.root, text="",
                                   font=("Consolas", 10),
                                   bg=BG, fg=MUTED)
        self.info_label.pack(pady=(0, 8))

    def _btn(self, parent, text, bg, hover, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 10, "bold"),
                        bg=bg, fg="white",
                        activebackground=hover,
                        activeforeground="white",
                        bd=0, padx=12, pady=8, cursor="hand2",
                        command=command)

        def on_enter(e): btn.config(bg=hover)

        def on_leave(e): btn.config(bg=bg)

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        return btn

    # ════════════════════════════════════════════════════════════
    # ДЕЙСТВИЯ
    # ════════════════════════════════════════════════════════════
    def _on_season_change(self):
        weather.set_mode(self.season.get())
        self.redraw()

    def _update_data(self):
        weather._generate()
        self.redraw()

    def on_area_motion(self, e):
        self.area_mouse_x = e.x
        self.redraw()

    def on_area_leave(self, e):
        self.area_mouse_x = None
        self.redraw()

    def on_heat_motion(self, e):
        self.heat_mouse = (e.x, e.y)
        self.redraw_heat()
        self._update_heat_info(e.x, e.y)

    def on_heat_leave(self, e):
        self.heat_mouse = None
        self.info_label.config(text="")
        self.redraw_heat()

    def _update_heat_info(self, mx, my):
        # Определяем клетку
        W = 560
        H = 440
        pad_l, pad_r = 50, 20
        pad_t, pad_b = 30, 40

        x0, x1 = pad_l, W - pad_r
        y0, y1 = pad_t, H - pad_b

        cols = 24
        rows = 7
        cell_w = (x1 - x0) / cols
        cell_h = (y1 - y0) / rows

        col = int((mx - x0) / cell_w)
        row = int((my - y0) / cell_h)

        if 0 <= col < cols and 0 <= row < rows:
            temp = weather.matrix[row][col]
            self.info_label.config(
                text=f"День: {weather.days[row]}  ·  "
                     f"Час: {col:02d}:00  ·  "
                     f"Температура: {temp:+.1f} °C",
                fg=TEXT)

    # ════════════════════════════════════════════════════════════
    # ОТРИСОВКА
    # ════════════════════════════════════════════════════════════
    def redraw(self):
        self.redraw_area()
        self.redraw_heat()
        self.redraw_legend()

    # ─── График с областями ───────────────────────────────────
    def redraw_area(self):
        c = self.area_canvas
        c.delete("all")

        W = c.winfo_width()
        H = c.winfo_height()
        if W < 50 or H < 50:
            return

        pad_l, pad_r = 60, 30
        pad_t, pad_b = 30, 50

        x0, x1 = pad_l, W - pad_r
        y0, y1 = pad_t, H - pad_b

        temps = weather.temperatures
        n = len(temps)
        if n == 0:
            return

        tmin = min(temps) - 2
        tmax = max(temps) + 2
        if tmax - tmin < 5:
            tmin -= 2
            tmax += 2

        def to_px(i):
            return x0 + (x1 - x0) * i / (n - 1)

        def to_py(t):
            return y1 - (y1 - y0) * (t - tmin) / (tmax - tmin)

        # ─── Заливка области ───────────────────────────────────
        # Полигон: кривая + возврат по низу
        # Используем градиент через вертикальные полоски
        steps = 60
        for s in range(steps):
            i1 = s * (n - 1) / steps
            i2 = (s + 1) * (n - 1) / steps

            idx1 = int(i1)
            idx2 = min(int(i2) + 1, n - 1)

            # Средняя температура на участке
            t_mid = (temps[idx1] + temps[idx2]) / 2
            color = area_to_color(t_mid, tmin, tmax)

            # Полигон — от кривой к y1
            px1 = to_px(i1)
            px2 = to_px(i2)
            py1 = to_py(temps[idx1])
            py2 = to_py(temps[idx2])

            # Рисуем прямоугольник от py1 до y1
            c.create_rectangle(px1, min(py1, py2),
                               px2, y1,
                               fill=color, outline="")

        # ─── Кривая ────────────────────────────────────────────
        points = []
        for i, t in enumerate(temps):
            points.extend([to_px(i), to_py(t)])
        c.create_line(*points, fill="#1c1c1e", width=2, smooth=True)

        # ─── Точки ─────────────────────────────────────────────
        for i, t in enumerate(temps):
            if i % 3 == 0:
                x = to_px(i)
                y = to_py(t)
                c.create_oval(x - 3, y - 3, x + 3, y + 3,
                              fill="#1c1c1e", outline="")

        # ─── Сетка ─────────────────────────────────────────────
        if self.show_grid.get():
            for i in range(6):
                y = y0 + (y1 - y0) * i / 5
                c.create_line(x0, y, x1, y, fill=GRID)
                val = tmax - (tmax - tmin) * i / 5
                c.create_text(x0 - 8, y, text=f"{val:.0f}°",
                              anchor="e", font=("Segoe UI", 8),
                              fill=MUTED)

        # ─── Оси ───────────────────────────────────────────────
        c.create_line(x0, y0 - 10, x0, y1, fill=AXIS, width=1,
                      arrow="last", arrowshape=(8, 10, 3))
        c.create_line(x0, y1, x1 + 10, y1, fill=AXIS, width=1,
                      arrow="last", arrowshape=(8, 10, 3))

        # Подписи часов
        for h in [0, 4, 8, 12, 16, 20, 23]:
            if h < n:
                x = to_px(h)
                c.create_text(x, y1 + 15, text=f"{h:02d}:00",
                              font=("Segoe UI", 8), fill=TEXT)

        # ─── Курсор ────────────────────────────────────────────
        if hasattr(self, "area_mouse_x") and self.area_mouse_x:
            if x0 <= self.area_mouse_x <= x1:
                # Определяем час
                idx_float = (self.area_mouse_x - x0) / (x1 - x0) * (n - 1)
                idx = int(round(idx_float))
                idx = max(0, min(n - 1, idx))
                temp = temps[idx]

                px = to_px(idx)
                py = to_py(temp)

                # Вертикальная линия
                c.create_line(px, y0, px, y1,
                              fill="#999", dash=(2, 4))
                # Точка
                c.create_oval(px - 6, py - 6, px + 6, py + 6,
                              fill=ACCENT, outline="white", width=2)
                # Подпись
                label = f"{idx:02d}:00 · {temp:+.1f} °C"
                c.create_text(px + 10, py - 10, text=label,
                              anchor="w", font=("Segoe UI", 9, "bold"),
                              fill=ACCENT)

    # ─── Тепловая карта ────────────────────────────────────────
    def redraw_heat(self):
        c = self.heat_canvas
        c.delete("all")

        W = 560
        H = 440

        pad_l, pad_r = 50, 20
        pad_t, pad_b = 30, 40

        x0, x1 = pad_l, W - pad_r
        y0, y1 = pad_t, H - pad_b

        matrix = weather.matrix
        if not matrix:
            return

        rows = len(matrix)
        cols = len(matrix[0])

        cell_w = (x1 - x0) / cols
        cell_h = (y1 - y0) / rows

        # Глобальный минимум/максимум
        all_vals = [v for row in matrix for v in row]
        tmin = min(all_vals)
        tmax = max(all_vals)

        # ─── Клетки ────────────────────────────────────────────
        for r in range(rows):
            for col in range(cols):
                temp = matrix[r][col]
                color = temp_to_color(temp, tmin, tmax)

                cx1 = x0 + col * cell_w
                cy1 = y0 + r * cell_h
                cx2 = cx1 + cell_w
                cy2 = cy1 + cell_h

                c.create_rectangle(cx1, cy1, cx2, cy2,
                                   fill=color, outline="")

        # ─── Подсветка под курсором ────────────────────────────
        if hasattr(self, "heat_mouse") and self.heat_mouse:
            mx, my = self.heat_mouse
            if x0 <= mx <= x1 and y0 <= my <= y1:
                col = int((mx - x0) / cell_w)
                row = int((my - y0) / cell_h)
                if 0 <= col < cols and 0 <= row < rows:
                    cx1 = x0 + col * cell_w
                    cy1 = y0 + row * cell_h
                    c.create_rectangle(cx1, cy1,
                                       cx1 + cell_w, cy1 + cell_h,
                                       fill="", outline="white", width=3)

        # ─── Подписи дней ──────────────────────────────────────
        for r, day in enumerate(weather.days):
            y = y0 + r * cell_h + cell_h / 2
            c.create_text(x0 - 8, y, text=day, anchor="e",
                          font=("Segoe UI", 9, "bold"), fill=TEXT)

        # ─── Подписи часов ─────────────────────────────────────
        for h in [0, 4, 8, 12, 16, 20, 23]:
            x = x0 + h * cell_w + cell_w / 2
            c.create_text(x, y1 + 12, text=f"{h:02d}:00",
                          font=("Segoe UI", 8), fill=TEXT)

        # ─── Рамка ─────────────────────────────────────────────
        c.create_rectangle(x0, y0, x1, y1,
                           fill="", outline=AXIS, width=1)

    # ─── Легенда ───────────────────────────────────────────────
    def redraw_legend(self):
        c = self.legend_canvas
        c.delete("all")

        W = 540
        H = 30

        # Минимум/максимум
        all_vals = [v for row in weather.matrix for v in row]
        if not all_vals:
            return
        tmin = min(all_vals)
        tmax = max(all_vals)

        # Плавный градиент
        steps = 100
        for i in range(steps):
            t = tmin + (tmax - tmin) * i / steps
            color = temp_to_color(t, tmin, tmax)
            x1 = i * W / steps
            x2 = (i + 1) * W / steps
            c.create_rectangle(x1, 5, x2, 25, fill=color, outline="")

        # Подписи
        c.create_text(5, 15, text=f"{tmin:.0f}°", anchor="w",
                      font=("Segoe UI", 9, "bold"), fill="#ffffff")
        c.create_text(W - 5, 15, text=f"{tmax:.0f}°", anchor="e",
                      font=("Segoe UI", 9, "bold"), fill="#ffffff")
        c.create_text(W // 2, 15, text="Температура (°C)",
                      font=("Segoe UI", 9, "bold"), fill="#ffffff")

    # ════════════════════════════════════════════════════════════
    # ЭКСПОРТ
    # ════════════════════════════════════════════════════════════
    def export(self):
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(
            defaultextension=".ps",
            filetypes=[("PostScript", "*.ps"), ("PNG", "*.png")],
            initialfile=f"weather_{datetime.now().strftime('%H%M%S')}.ps")
        if not path:
            return

        try:
            if path.endswith(".png"):
                try:
                    from PIL import Image
                    # Компонуем два canvas в одно изображение
                    self.area_canvas.update()
                    self.heat_canvas.update()

                    ps_area = path.replace(".png", "_area.ps")
                    ps_heat = path.replace(".png", "_heat.ps")

                    self.area_canvas.postscript(file=ps_area, colormode="color")
                    self.heat_canvas.postscript(file=ps_heat, colormode="color")

                    img1 = Image.open(ps_area)
                    img2 = Image.open(ps_heat)

                    combined = Image.new("RGB",
                                         (img1.width + img2.width + 20,
                                          max(img1.height, img2.height)),
                                         "white")
                    combined.paste(img1, (0, 0))
                    combined.paste(img2, (img1.width + 20, 0))
                    combined.save(path, "PNG")
                except ImportError:
                    self.area_canvas.postscript(
                        file=path.replace(".png", "_area.ps"),
                        colormode="color")
            else:
                self.area_canvas.postscript(file=path, colormode="color")
        except Exception as e:
            from tkinter import messagebox
            messagebox.showerror("Ошибка", f"Не удалось сохранить: {e}")


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = WeatherVizApp(root)
    root.mainloop()
