import tkinter as tk
from tkinter import filedialog, messagebox
import csv
import math
from datetime import datetime


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

CHART_COLORS = [
    "#0a84ff", "#30d158", "#ff9f0a", "#e53935",
    "#8e44ad", "#00bcd4", "#fdd835", "#ff7043",
    "#26a69a", "#ec407a",
]

AXIS = "#000000"
GRID = "#ececf0"

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
RED = "#e53935"
RED_HOVER = "#c62828"
PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"


class DataVizApp:
    def __init__(self, root):
        self.root = root
        root.title("Визуализатор данных")
        root.geometry("1280x880")
        root.minsize(1180, 840)
        root.configure(bg=BG)
        root.resizable(False, False)

        self.headers = []
        self.rows = []
        self.x_var = tk.StringVar()
        self.y_var = tk.StringVar()

        self.chart_type = tk.StringVar(value="bar")
        self.sort_mode = tk.StringVar(value="none")
        self.color_idx = 0
        self.show_grid = tk.BooleanVar(value=True)
        self.show_values = tk.BooleanVar(value=True)
        self.show_legend = tk.BooleanVar(value=True)
        self.top_n = tk.IntVar(value=0)

        self._build_ui()
        self._load_demo()

    def _build_ui(self):
        tk.Label(self.root, text="Визуализатор данных",
                 font=("Segoe UI", 15, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(10, 2))

        tk.Label(self.root,
                 text="Загрузите CSV · выберите оси · постройте диаграмму",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 8))

        top = tk.Frame(self.root, bg=CARD,
                       highlightthickness=1,
                       highlightbackground=BORDER)
        top.pack(padx=20, pady=(0, 8), fill="x")

        row1 = tk.Frame(top, bg=CARD)
        row1.pack(fill="x", padx=14, pady=(10, 4))

        self._btn(row1, "📂 Открыть CSV", ACCENT, ACCENT_HOVER,
                  self.open_csv).pack(side="left", padx=(0, 6))
        self._btn(row1, "📋 Вставить", GREEN, GREEN_HOVER,
                  self.paste_data).pack(side="left", padx=6)
        self._btn(row1, "🎲 Пример", ORANGE, ORANGE_HOVER,
                  self._load_demo).pack(side="left", padx=6)
        self._btn(row1, "🗑 Очистить", RED, RED_HOVER,
                  self.clear_all).pack(side="left", padx=6)

        self.file_info = tk.Label(row1, text="—",
                                  font=("Segoe UI", 9),
                                  bg=CARD, fg=MUTED)
        self.file_info.pack(side="left", padx=(20, 0))

        row2 = tk.Frame(top, bg=CARD)
        row2.pack(fill="x", padx=14, pady=(4, 6))

        tk.Label(row2, text="Ось X:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 4))

        self.x_combo = tk.OptionMenu(row2, self.x_var, "")
        self.x_combo.config(font=("Segoe UI", 9), bg="#fafafa", fg=TEXT,
                            bd=1, relief="solid", highlightthickness=0,
                            width=15, anchor="w")
        self.x_combo.pack(side="left", padx=(0, 16))

        tk.Label(row2, text="Ось Y:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 4))

        self.y_combo = tk.OptionMenu(row2, self.y_var, "")
        self.y_combo.config(font=("Segoe UI", 9), bg="#fafafa", fg=TEXT,
                            bd=1, relief="solid", highlightthickness=0,
                            width=15, anchor="w")
        self.y_combo.pack(side="left", padx=(0, 16))

        tk.Label(row2, text="Топ-N:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 4))

        self.topn_lbl = tk.Label(row2, text="0 (все)",
                                 font=("Consolas", 10, "bold"),
                                 bg=CARD, fg=ACCENT, width=8)
        self.topn_lbl.pack(side="left", padx=(0, 6))

        topn_scale = tk.Scale(row2, from_=0, to=30, resolution=1,
                              orient="horizontal",
                              length=150, showvalue=False,
                              bg=CARD, fg=TEXT, troughcolor="#ececf0",
                              activebackground=ACCENT,
                              highlightthickness=0, bd=0,
                              sliderlength=14, width=8,
                              command=self._on_topn)
        topn_scale.set(0)
        topn_scale.pack(side="left", padx=(0, 16))

        tk.Label(row2, text="Сортировка:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 4))

        for text, val in [("Без", "none"), ("↑", "asc"), ("↓", "desc")]:
            tk.Radiobutton(row2, text=text,
                           variable=self.sort_mode, value=val,
                           font=("Segoe UI", 9),
                           bg=CARD, fg=TEXT,
                           activebackground=CARD,
                           activeforeground=ACCENT,
                           selectcolor=CARD,
                           bd=0, highlightthickness=0,
                           cursor="hand2",
                           command=self.redraw,
                           ).pack(side="left", padx=4)

        row3 = tk.Frame(top, bg=CARD)
        row3.pack(fill="x", padx=14, pady=(0, 10))

        types = [
            ("📊", "bar", "Столбчатая"),
            ("📋", "hbar", "Горизонт."),
            ("📈", "line", "Линейная"),
            ("🥧", "pie", "Круговая"),
            ("🍩", "donut", "Кольцевая"),
            ("⚫", "scatter", "Точечная"),
            ("🌊", "area", "С областями"),
        ]

        for icon, val, name in types:
            tk.Radiobutton(row3, text=f"{icon} {name}",
                           variable=self.chart_type, value=val,
                           font=("Segoe UI", 9),
                           bg=CARD, fg=TEXT,
                           activebackground=CARD,
                           activeforeground=ACCENT,
                           selectcolor=CARD,
                           bd=0, highlightthickness=0,
                           cursor="hand2",
                           command=self.redraw,
                           ).pack(side="left", padx=(0, 10))

        row4 = tk.Frame(top, bg=CARD)
        row4.pack(fill="x", padx=14, pady=(0, 10))

        for text, var in [("Сетка", self.show_grid),
                          ("Значения", self.show_values),
                          ("Легенда", self.show_legend)]:
            tk.Checkbutton(row4, text=text,
                           variable=var,
                           font=("Segoe UI", 10),
                           bg=CARD, fg=TEXT,
                           activebackground=CARD,
                           activeforeground=ACCENT,
                           selectcolor=CARD,
                           bd=0, highlightthickness=0,
                           cursor="hand2",
                           command=self.redraw,
                           ).pack(side="left", padx=(0, 16))

        tk.Label(row4, text="Цвет:",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED).pack(side="left", padx=(10, 4))

        for i, color in enumerate(CHART_COLORS):
            tk.Button(row4, bg=color, width=2, bd=0,
                      cursor="hand2",
                      command=lambda idx=i: self._set_color(idx),
                      ).pack(side="left", padx=2)

        main = tk.Frame(self.root, bg=BG)
        main.pack(fill="both", expand=True, padx=20, pady=(0, 8))

        canvas_card = tk.Frame(main, bg=CARD,
                               highlightthickness=1,
                               highlightbackground=BORDER)
        canvas_card.pack(side="left", fill="both", expand=True, padx=(0, 8))

        self.canvas = tk.Canvas(canvas_card, bg="white", highlightthickness=0)
        self.canvas.pack(padx=10, pady=10, fill="both", expand=True)
        self.canvas.bind("<Configure>", lambda e: self.redraw())

        table_card = tk.Frame(main, bg=CARD,
                              highlightthickness=1,
                              highlightbackground=BORDER)
        table_card.pack(side="left", fill="y", padx=(8, 0))

        tk.Label(table_card, text="ПРЕДПРОСМОТР",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=12, pady=(10, 4))

        self.table = tk.Text(table_card, width=42, height=24,
                             font=("Consolas", 9),
                             bg="#fafafa", fg=TEXT,
                             bd=0, relief="flat",
                             highlightthickness=0,
                             state="disabled",
                             wrap="none")
        self.table.pack(padx=12, pady=(0, 12))

        bottom = tk.Frame(self.root, bg=CARD,
                          highlightthickness=1,
                          highlightbackground=BORDER)
        bottom.pack(padx=20, pady=(0, 16), fill="x")

        row = tk.Frame(bottom, bg=CARD)
        row.pack(fill="x", padx=14, pady=10)

        self._btn(row, "💾 Сохранить диаграмму", PURPLE, PURPLE_HOVER,
                  self.export).pack(side="left", padx=(0, 8))

        self.status = tk.Label(row, text="Готово",
                               font=("Segoe UI", 9),
                               bg=CARD, fg=MUTED)
        self.status.pack(side="right")

    def _btn(self, parent, text, bg, hover, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 10, "bold"),
                        bg=bg, fg="white",
                        activebackground=hover,
                        activeforeground="white",
                        bd=0, padx=12, pady=8, cursor="hand2",
                        command=command)

        def on_enter(e): btn.config(bg=hover)
        def on_leave(e): btn.config(bg=bg)

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        return btn

    def open_csv(self):
        path = filedialog.askopenfilename(
            filetypes=[("CSV", "*.csv"), ("Text", "*.txt"),
                       ("All", "*.*")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
            self._parse_csv(content)
            self.file_info.config(text=f"📄 {path.split('/')[-1]}")
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось прочитать файл:\n{e}")

    def paste_data(self):
        dlg = tk.Toplevel(self.root)
        dlg.title("Вставить данные")
        dlg.geometry("600x500")
        dlg.configure(bg=BG)
        dlg.transient(self.root)
        dlg.grab_set()

        tk.Label(dlg, text="CSV-данные (первая строка — заголовки):",
                 font=("Segoe UI", 10, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(14, 6), padx=14, anchor="w")

        text = tk.Text(dlg, font=("Consolas", 10),
                       bg="white", fg=TEXT,
                       bd=1, relief="solid",
                       highlightthickness=0)
        text.pack(fill="both", expand=True, padx=14, pady=(0, 8))
        text.insert("1.0", "Месяц,Продажи,Затраты\n"
                           "Январь,100,60\nФевраль,120,75\nМарт,90,50\n"
                           "Апрель,150,80\nМай,110,70")

        def ok():
            content = text.get("1.0", "end-1c")
            dlg.destroy()
            self._parse_csv(content)

        self._btn(dlg, "✓ Применить", GREEN, GREEN_HOVER,
                  ok).pack(pady=(0, 14))

    def _parse_csv(self, content):
        lines = [l for l in content.strip().splitlines() if l.strip()]
        if len(lines) < 2:
            messagebox.showerror("Ошибка", "Нужно минимум 2 строки")
            return

        first = lines[0]
        if ";" in first:
            delim = ";"
        elif "\t" in first:
            delim = "\t"
        else:
            delim = ","

        try:
            reader = csv.reader(lines, delimiter=delim)
            rows = list(reader)
        except Exception as e:
            messagebox.showerror("Ошибка", f"Парсинг не удался:\n{e}")
            return

        self.headers = [h.strip() for h in rows[0]]
        self.rows = []
        for r in rows[1:]:
            if len(r) == len(self.headers):
                row_dict = {}
                for i, h in enumerate(self.headers):
                    row_dict[h] = r[i].strip()
                self.rows.append(row_dict)

        self._update_combos()
        self._update_table()
        self._suggest_columns()
        self.redraw()

    def _update_combos(self):
        for combo, var in [(self.x_combo, self.x_var),
                           (self.y_combo, self.y_var)]:
            menu = combo["menu"]
            menu.delete(0, "end")
            for h in self.headers:
                menu.add_command(label=h,
                                 command=lambda v=h, vr=var: (
                                     vr.set(v),
                                     self.redraw()
                                 ))
        if self.headers:
            self.x_var.set(self.headers[0])
            if len(self.headers) > 1:
                self.y_var.set(self.headers[1])

    def _suggest_columns(self):
        for h in self.headers[1:]:
            if self._is_numeric(h):
                self.y_var.set(h)
                break

    def _is_numeric(self, column):
        for r in self.rows[:5]:
            try:
                float(r[column].replace(",", "."))
            except (ValueError, AttributeError):
                return False
        return True

    def _get_value(self, row, column):
        try:
            return float(row[column].replace(",", "."))
        except (ValueError, AttributeError, KeyError):
            return 0.0

    def _update_table(self):
        self.table.config(state="normal")
        self.table.delete("1.0", "end")
        self.table.insert("end", "  ".join(self.headers) + "\n")
        self.table.insert("end", "─" * 40 + "\n")
        for row in self.rows[:20]:
            line = "  ".join(str(row.get(h, "")) for h in self.headers)
            self.table.insert("end", line + "\n")
        if len(self.rows) > 20:
            self.table.insert("end", f"\n... ещё {len(self.rows) - 20} строк")
        self.table.config(state="disabled")

    def clear_all(self):
        self.headers = []
        self.rows = []
        self.x_var.set("")
        self.y_var.set("")
        self.table.config(state="normal")
        self.table.delete("1.0", "end")
        self.table.config(state="disabled")
        self.canvas.delete("all")
        self.file_info.config(text="—")
        self.status.config(text="Данные очищены")

    def _load_demo(self):
        demo = """Месяц,Продажи,Затраты,Прибыль
Январь,45,25,20
Февраль,78,40,38
Март,62,35,27
Апрель,90,50,40
Май,54,30,24
Июнь,110,65,45
Июль,120,70,50
Август,95,55,40
Сентябрь,80,45,35
Октябрь,70,40,30
Ноябрь,60,35,25
Декабрь,130,75,55"""
        self._parse_csv(demo)
        self.file_info.config(text="📄 Демо-данные")

    def _set_color(self, idx):
        self.color_idx = idx
        self.redraw()

    def _on_topn(self, n):
        n = int(float(n))
        self.top_n.set(n)
        self.topn_lbl.config(text=f"{n} (все)" if n == 0 else str(n))
        self.redraw()

    def _prepare_data(self):
        x_col = self.x_var.get()
        y_col = self.y_var.get()
        if not x_col or not y_col:
            return []

        data = []
        for row in self.rows:
            label = str(row.get(x_col, ""))
            value = self._get_value(row, y_col)
            data.append((label, value))

        sm = self.sort_mode.get()
        if sm == "asc":
            data.sort(key=lambda x: x[1])
        elif sm == "desc":
            data.sort(key=lambda x: x[1], reverse=True)

        n = self.top_n.get()
        if n > 0:
            data = data[:n]

        return data

    def redraw(self):
        c = self.canvas
        c.delete("all")

        W = c.winfo_width()
        H = c.winfo_height()
        if W < 50 or H < 50:
            return

        if not self.headers or not self.rows:
            c.create_text(W // 2, H // 2,
                          text="Загрузите CSV или нажмите «Пример»",
                          font=("Segoe UI", 12), fill=MUTED)
            return

        data = self._prepare_data()
        if not data:
            return

        t = self.chart_type.get()
        color = CHART_COLORS[self.color_idx % len(CHART_COLORS)]

        if t == "bar":
            self._draw_bars(c, W, H, data, color, horizontal=False)
        elif t == "hbar":
            self._draw_bars(c, W, H, data, color, horizontal=True)
        elif t == "line":
            self._draw_line(c, W, H, data, color)
        elif t == "pie":
            self._draw_pie(c, W, H, data, donut=False)
        elif t == "donut":
            self._draw_pie(c, W, H, data, donut=True)
        elif t == "scatter":
            self._draw_scatter(c, W, H, data, color)
        elif t == "area":
            self._draw_area(c, W, H, data, color)

        self.status.config(
            text=f"Строк: {len(self.rows)} · Построено: {t}",
            fg=GREEN)

    def _draw_grid(self, c, x0, x1, y0, y1, max_v):
        for i in range(6):
            y = y0 + (y1 - y0) * i / 5
            c.create_line(x0, y, x1, y, fill=GRID)
            val = max_v * (5 - i) / 5
            c.create_text(x0 - 6, y, text=f"{val:.0f}",
                          anchor="e", font=("Segoe UI", 8), fill=MUTED)

    def _draw_axes(self, c, x0, x1, y0, y1, horizontal=False):
        if horizontal:
            c.create_line(x0, y1, x1 + 10, y1, fill=AXIS, width=1,
                          arrow="last", arrowshape=(8, 10, 3))
            c.create_line(x0, y0 - 10, x0, y1, fill=AXIS, width=1)
        else:
            c.create_line(x0, y0 - 10, x0, y1, fill=AXIS, width=1,
                          arrow="last", arrowshape=(8, 10, 3))
            c.create_line(x0, y1, x1 + 10, y1, fill=AXIS, width=1,
                          arrow="last", arrowshape=(8, 10, 3))

    def _draw_bars(self, c, W, H, data, color, horizontal=False):
        if horizontal:
            pad_l, pad_r, pad_t, pad_b = 130, 30, 30, 50
        else:
            pad_l, pad_r, pad_t, pad_b = 60, 30, 30, 60

        x0, x1 = pad_l, W - pad_r
        y0, y1 = pad_t, H - pad_b

        max_v = max(abs(v) for _, v in data) or 1
        n = len(data)

        if self.show_grid.get() and not horizontal:
            self._draw_grid(c, x0, x1, y0, y1, max_v)

        self._draw_axes(c, x0, x1, y0, y1, horizontal)

        if horizontal:
            bar_h = (y1 - y0) / n * 0.7
            gap = (y1 - y0) / n

            for i, (label, value) in enumerate(data):
                w = (x1 - x0) * abs(value) / max_v
                y = y0 + gap * i + (gap - bar_h) / 2

                c.create_rectangle(x0, y, x0 + w, y + bar_h,
                                   fill=color, outline="")

                if self.show_values.get():
                    c.create_text(x0 + w + 8, y + bar_h / 2,
                                  text=f"{value:.0f}",
                                  font=("Segoe UI", 9, "bold"),
                                  fill=color, anchor="w")

                c.create_text(x0 - 8, y + bar_h / 2,
                              text=label, anchor="e",
                              font=("Segoe UI", 9), fill=TEXT)
        else:
            bar_w = (x1 - x0) / n * 0.7
            gap = (x1 - x0) / n

            for i, (label, value) in enumerate(data):
                h = (y1 - y0) * abs(value) / max_v
                x = x0 + gap * i + (gap - bar_w) / 2
                y = y1 - h

                c.create_rectangle(x, y, x + bar_w, y1,
                                   fill=color, outline="")

                if self.show_values.get():
                    c.create_text(x + bar_w / 2, y - 8,
                                  text=f"{value:.0f}",
                                  font=("Segoe UI", 9, "bold"),
                                  fill=color)

                if len(label) > 5:
                    c.create_text(x + bar_w / 2, y1 + 10,
                                  text=label[:6],
                                  font=("Segoe UI", 8), fill=TEXT,
                                  angle=45)
                else:
                    c.create_text(x + bar_w / 2, y1 + 15,
                                  text=label,
                                  font=("Segoe UI", 9), fill=TEXT)

    def _draw_line(self, c, W, H, data, color):
        pad_l, pad_r, pad_t, pad_b = 60, 30, 30, 60
        x0, x1 = pad_l, W - pad_r
        y0, y1 = pad_t, H - pad_b

        max_v = max(abs(v) for _, v in data) or 1
        n = len(data)

        if self.show_grid.get():
            self._draw_grid(c, x0, x1, y0, y1, max_v)
        self._draw_axes(c, x0, x1, y0, y1)

        gap = (x1 - x0) / max(1, n - 1) if n > 1 else (x1 - x0)
        pts = []

        for i, (label, value) in enumerate(data):
            x = x0 + gap * i if n > 1 else (x0 + x1) / 2
            y = y1 - (y1 - y0) * value / max_v
            pts.extend([x, y])

            c.create_oval(x - 4, y - 4, x + 4, y + 4,
                          fill=color, outline="white", width=1)
            c.create_text(x, y1 + 15, text=label[:6],
                          font=("Segoe UI", 8), fill=TEXT)

            if self.show_values.get():
                c.create_text(x, y - 10, text=f"{value:.0f}",
                              font=("Segoe UI", 9, "bold"),
                              fill=color)

        if len(pts) >= 4:
            c.create_line(*pts, fill=color, width=2.5, smooth=True)

    def _draw_area(self, c, W, H, data, color):
        pad_l, pad_r, pad_t, pad_b = 60, 30, 30, 60
        x0, x1 = pad_l, W - pad_r
        y0, y1 = pad_t, H - pad_b

        max_v = max(abs(v) for _, v in data) or 1
        n = len(data)

        if self.show_grid.get():
            self._draw_grid(c, x0, x1, y0, y1, max_v)
        self._draw_axes(c, x0, x1, y0, y1)

        gap = (x1 - x0) / max(1, n - 1) if n > 1 else (x1 - x0)

        pts = [x0, y1]
        for i, (label, value) in enumerate(data):
            x = x0 + gap * i if n > 1 else (x0 + x1) / 2
            y = y1 - (y1 - y0) * value / max_v
            pts.extend([x, y])
        pts.extend([x1, y1])

        c.create_polygon(*pts, fill=color, outline="", stipple="gray50")

        line_pts = []
        for i, (label, value) in enumerate(data):
            x = x0 + gap * i if n > 1 else (x0 + x1) / 2
            y = y1 - (y1 - y0) * value / max_v
            line_pts.extend([x, y])
            c.create_text(x, y1 + 15, text=label[:6],
                          font=("Segoe UI", 8), fill=TEXT)

            if self.show_values.get():
                c.create_text(x, y - 10, text=f"{value:.0f}",
                              font=("Segoe UI", 9, "bold"),
                              fill=color)

        if len(line_pts) >= 4:
            c.create_line(*line_pts, fill=color, width=2.5, smooth=True)

    def _draw_pie(self, c, W, H, data, donut=False):
        if self.show_legend.get():
            pie_w = W - 220
        else:
            pie_w = W

        cx = pie_w // 2
        cy = H // 2
        r = min(pie_w, H) // 2 - 30

        if r < 20:
            return

        total = sum(abs(v) for _, v in data) or 1
        start = 90

        for i, (label, value) in enumerate(data):
            angle = 360 * abs(value) / total
            col = CHART_COLORS[(self.color_idx + i) % len(CHART_COLORS)]

            c.create_arc(cx - r, cy - r, cx + r, cy + r,
                         start=start, extent=-angle,
                         fill=col, outline="white", width=2)

            if angle > 15 and self.show_values.get():
                mid = math.radians(start - angle / 2)
                tx = cx + r * 0.65 * math.cos(mid)
                ty = cy - r * 0.65 * math.sin(mid)
                pct = 100 * abs(value) / total
                c.create_text(tx, ty, text=f"{pct:.0f}%",
                              font=("Segoe UI", 10, "bold"),
                              fill="white")

            start -= angle

        if donut:
            inner_r = r * 0.5
            c.create_oval(cx - inner_r, cy - inner_r,
                          cx + inner_r, cy + inner_r,
                          fill="white", outline="")
            c.create_text(cx, cy - 10, text="Всего",
                          font=("Segoe UI", 9), fill=MUTED)
            c.create_text(cx, cy + 10, text=f"{total:.0f}",
                          font=("Segoe UI", 18, "bold"), fill=TEXT)

        if self.show_legend.get():
            lx = pie_w + 20
            ly = 40
            for i, (label, value) in enumerate(data):
                col = CHART_COLORS[(self.color_idx + i) % len(CHART_COLORS)]
                c.create_rectangle(lx, ly, lx + 16, ly + 16,
                                   fill=col, outline="")
                c.create_text(lx + 24, ly + 8,
                              text=f"{label}: {value:.0f}",
                              anchor="w",
                              font=("Segoe UI", 9), fill=TEXT)
                ly += 24

    def _draw_scatter(self, c, W, H, data, color):
        pad_l, pad_r, pad_t, pad_b = 60, 30, 30, 60
        x0, x1 = pad_l, W - pad_r
        y0, y1 = pad_t, H - pad_b

        max_v = max(abs(v) for _, v in data) or 1
        n = len(data)

        if self.show_grid.get():
            self._draw_grid(c, x0, x1, y0, y1, max_v)
        self._draw_axes(c, x0, x1, y0, y1)

        gap = (x1 - x0) / max(1, n - 1) if n > 1 else (x1 - x0)

        for i, (label, value) in enumerate(data):
            x = x0 + gap * i if n > 1 else (x0 + x1) / 2
            y = y1 - (y1 - y0) * abs(value) / max_v

            r = 7
            c.create_oval(x - r, y - r, x + r, y + r,
                          fill=color, outline="white", width=2)

            if self.show_values.get():
                c.create_text(x, y - 14, text=f"{value:.0f}",
                              font=("Segoe UI", 9, "bold"),
                              fill=color)

            c.create_text(x, y1 + 15, text=label[:6],
                          font=("Segoe UI", 8), fill=TEXT)

    def export(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".ps",
            filetypes=[("PostScript", "*.ps"), ("PNG", "*.png")],
            initialfile=f"chart_{datetime.now().strftime('%H%M%S')}.ps")
        if not path:
            return

        try:
            if path.endswith(".png"):
                try:
                    from PIL import Image
                    ps_path = path.replace(".png", ".ps")
                    self.canvas.postscript(file=ps_path, colormode="color")
                    img = Image.open(ps_path)
                    img.save(path, "PNG")
                    self.status.config(text=f"Сохранено: {path}", fg=GREEN)
                except ImportError:
                    self.canvas.postscript(
                        file=path.replace(".png", ".ps"),
                        colormode="color")
                    self.status.config(
                        text="PIL не установлен. Сохранено как .ps",
                        fg=ORANGE)
            else:
                self.canvas.postscript(file=path, colormode="color")
                self.status.config(text=f"Сохранено: {path}", fg=GREEN)
        except Exception as e:
            self.status.config(text=f"Ошибка: {e}", fg=RED)


if __name__ == "__main__":
    root = tk.Tk()
    app = DataVizApp(root)
    root.mainloop()
