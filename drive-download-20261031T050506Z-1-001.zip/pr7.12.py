import tkinter as tk
import math


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"
RED = "#e53935"
RED_HOVER = "#c62828"


# ═══════════════════════════════════════════════════════════════════
# МАТЕМАТИКА
# ═══════════════════════════════════════════════════════════════════
def complex_sin(x, y):
    """
    sin(x + iy) = sin(x)cosh(y) + i·cos(x)sinh(y)
    Возвращает (re, im, abs).
    """
    try:
        re = math.sin(x) * math.cosh(y)
        im = math.cos(x) * math.sinh(y)
        # Ограничиваем, чтобы не вылететь за пределы
        if abs(re) > 10: re = math.copysign(10, re)
        if abs(im) > 10: im = math.copysign(10, im)
        return re, im, math.sqrt(re*re + im*im)
    except (OverflowError, ValueError):
        return 0, 0, 0


# ═══════════════════════════════════════════════════════════════════
# ЦВЕТОВАЯ КАРТА
# ═══════════════════════════════════════════════════════════════════
def value_to_color(v, vmin, vmax):
    """Значение → цвет (jet colormap: синий → голубой → зелёный → жёлтый → красный)."""
    if vmax - vmin < 0.01:
        t = 0.5
    else:
        t = (v - vmin) / (vmax - vmin)
    t = max(0.0, min(1.0, t))

    stops = [
        (0.0, (0.10, 0.10, 0.70)),
        (0.25, (0.10, 0.60, 0.95)),
        (0.5, (0.20, 0.85, 0.50)),
        (0.75, (0.95, 0.85, 0.20)),
        (1.0, (0.85, 0.15, 0.15)),
    ]

    for i in range(len(stops) - 1):
        if stops[i][0] <= t <= stops[i + 1][0]:
            local_t = (t - stops[i][0]) / (stops[i + 1][0] - stops[i][0])
            c1 = stops[i][1]
            c2 = stops[i + 1][1]
            r = int(255 * (c1[0] + (c2[0] - c1[0]) * local_t))
            g = int(255 * (c1[1] + (c2[1] - c1[1]) * local_t))
            b = int(255 * (c1[2] + (c2[2] - c1[2]) * local_t))
            return f"#{r:02x}{g:02x}{b:02x}"

    return "#888888"


# ═══════════════════════════════════════════════════════════════════
# 3D-ГРАФИК НА CANVAS
# ═══════════════════════════════════════════════════════════════════
class Plot3D:
    def __init__(self, canvas, cx, cy, size, title, func_type="re"):
        self.canvas = canvas
        self.cx = cx
        self.cy = cy
        self.size = size
        self.title = title
        self.func_type = func_type  # re / im / abs

        # Параметры
        self.x_min, self.x_max = -3.14, 3.14
        self.y_min, self.y_max = -1.5, 1.5
        self.grid_n = 20
        self.rotation = 0.0

        # Углы обзора
        self.angle_x = math.radians(60)
        self.angle_z = math.radians(30)

        self.show_color = True
        self.show_grid = True

    def project(self, x, y, z):
        """3D-координаты → 2D-экран."""
        # Нормализуем
        nx = (x - self.x_min) / (self.x_max - self.x_min) - 0.5
        ny = (y - self.y_min) / (self.y_max - self.y_min) - 0.5
        nz = z / 8  # масштаб по Z

        # Поворот вокруг вертикальной оси
        cos_rz = math.cos(self.angle_z + self.rotation)
        sin_rz = math.sin(self.angle_z + self.rotation)
        rx = nx * cos_rz - ny * sin_rz
        ry = nx * sin_rz + ny * cos_rz

        # Проекция на экран
        # Наклон
        cos_rx = math.cos(self.angle_x)
        sin_rx = math.sin(self.angle_x)

        sx = rx * self.size
        sy = (ry * cos_rx - nz * sin_rx) * self.size

        return self.cx + sx, self.cy + sy - nz * self.size * 0.5

    def draw(self):
        c = self.canvas
        c.delete(self.title)  # не удаляем — тег уникален

        # Заголовок
        c.create_text(self.cx, self.cy - self.size - 10,
                      text=self.title,
                      font=("Segoe UI", 11, "bold"),
                      fill=TEXT, tags=self.title)

        # Вычисляем функцию
        n = self.grid_n
        xs = [self.x_min + (self.x_max - self.x_min) * i / (n - 1)
              for i in range(n)]
        ys = [self.y_min + (self.y_max - self.y_min) * j / (n - 1)
              for j in range(n)]

        zs = []  # матрица значений
        for j in range(n):
            row = []
            for i in range(n):
                re, im, ab = complex_sin(xs[i], ys[j])
                if self.func_type == "re":
                    row.append(re)
                elif self.func_type == "im":
                    row.append(im)
                else:
                    row.append(ab)
            zs.append(row)

        zmin = min(min(row) for row in zs)
        zmax = max(max(row) for row in zs)

        # ─── Заливка граней ────────────────────────────────────
        # Идём сзади вперёд (по Y), чтобы перекрытие было правильным
        for j in range(n - 1):
            for i in range(n - 1):
                # Четыре угла
                z1 = zs[j][i]
                z2 = zs[j][i+1]
                z3 = zs[j+1][i+1]
                z4 = zs[j+1][i]

                # Проекция
                p1 = self.project(xs[i], ys[j], z1)
                p2 = self.project(xs[i+1], ys[j], z2)
                p3 = self.project(xs[i+1], ys[j+1], z3)
                p4 = self.project(xs[i], ys[j+1], z4)

                # Среднее Z для цвета
                z_avg = (z1 + z2 + z3 + z4) / 4

                if self.show_color:
                    color = value_to_color(z_avg, zmin, zmax)
                    c.create_polygon(
                        p1[0], p1[1], p2[0], p2[1],
                        p3[0], p3[1], p4[0], p4[1],
                        fill=color, outline=""
                    )
                else:
                    c.create_polygon(
                        p1[0], p1[1], p2[0], p2[1],
                        p3[0], p3[1], p4[0], p4[1],
                        fill="#e0e8ff", outline=""
                    )

        # ─── Линии сетки ───────────────────────────────────────
        if self.show_grid:
            for j in range(n):
                pts = []
                for i in range(n):
                    px, py = self.project(xs[i], ys[j], zs[j][i])
                    pts.extend([px, py])
                c.create_line(*pts, fill="#333333", width=1,
                              tags=self.title)

            for i in range(n):
                pts = []
                for j in range(n):
                    px, py = self.project(xs[i], ys[j], zs[j][i])
                    pts.extend([px, py])
                c.create_line(*pts, fill="#333333", width=1,
                              tags=self.title)

        # ─── Оси ───────────────────────────────────────────────
        # Ось X
        x_start = self.project(self.x_min, self.y_max, zmin)
        x_end = self.project(self.x_max, self.y_max, zmin)
        c.create_line(x_start[0], x_start[1],
                      x_end[0], x_end[1],
                      fill="#000", width=1, arrow="last",
                      tags=self.title)
        c.create_text(x_end[0], x_end[1] + 10,
                      text="X", font=("Segoe UI", 9, "bold"),
                      fill="#000", tags=self.title)

        # Ось Y
        y_start = self.project(self.x_min, self.y_max, zmin)
        y_end = self.project(self.x_min, self.y_min, zmin)
        c.create_line(y_start[0], y_start[1],
                      y_end[0], y_end[1],
                      fill="#000", width=1, arrow="last",
                      tags=self.title)
        c.create_text(y_end[0] - 15, y_end[1],
                      text="Y", font=("Segoe UI", 9, "bold"),
                      fill="#000", tags=self.title)

        # ─── Подписи осей ──────────────────────────────────────
        for x_val in [-3, -1.5, 0, 1.5, 3]:
            px, py = self.project(x_val, self.y_max, zmin)
            c.create_text(px, py + 12, text=f"{x_val:.1f}",
                          font=("Segoe UI", 7), fill=MUTED,
                          tags=self.title)

        for y_val in [-1.5, 0, 1.5]:
            px, py = self.project(self.x_min, y_val, zmin)
            c.create_text(px - 15, py, text=f"{y_val:.1f}",
                          font=("Segoe UI", 7), fill=MUTED,
                          tags=self.title)


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class ComplexSin3DApp:
    def __init__(self, root):
        self.root = root
        root.title("3D: sin(x + iy) в комплексной плоскости")
        root.geometry("1280x880")
        root.minsize(1180, 840)
        root.configure(bg=BG)
        root.resizable(False, False)

        self.rotating = False
        self.rotation_speed = 0.02

        self._build_ui()
        self._build_plots()
        self._animate()

    # ════════════════════════════════════════════════════════════
    # UI
    # ════════════════════════════════════════════════════════════
    def _build_ui(self):
        tk.Label(self.root, text="Функция синуса в комплексной плоскости",
                 font=("Segoe UI", 15, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(10, 2))

        tk.Label(self.root,
                 text="z = sin(x + iy) · Re · Im · |z|",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 8))

        # Canvas
        canvas_card = tk.Frame(self.root, bg=CARD,
                               highlightthickness=1,
                               highlightbackground=BORDER)
        canvas_card.pack(padx=20, pady=(0, 8), fill="both", expand=True)

        self.canvas = tk.Canvas(canvas_card, bg="white",
                                highlightthickness=0)
        self.canvas.pack(padx=10, pady=10, fill="both", expand=True)

        # Управление
        ctrl = tk.Frame(self.root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        ctrl.pack(padx=20, pady=(0, 16), fill="x")

        inner = tk.Frame(ctrl, bg=CARD)
        inner.pack(fill="x", padx=16, pady=10)

        # Плотность
        tk.Label(inner, text="Плотность сетки:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 6))

        self.density_lbl = tk.Label(inner, text="20",
                                    font=("Consolas", 12, "bold"),
                                    bg=CARD, fg=ACCENT, width=3)
        self.density_lbl.pack(side="left", padx=(0, 6))

        self.density_scale = tk.Scale(inner, from_=8, to=40, resolution=2,
                                      orient="horizontal",
                                      length=200, showvalue=False,
                                      bg=CARD, fg=TEXT, troughcolor="#ececf0",
                                      activebackground=ACCENT,
                                      highlightthickness=0, bd=0,
                                      sliderlength=16, width=8,
                                      command=self._on_density)
        self.density_scale.set(20)
        self.density_scale.pack(side="left", padx=(0, 20))

        # Чекбоксы
        self.cb_color = tk.BooleanVar(value=True)
        self.cb_grid = tk.BooleanVar(value=True)

        self._cb(inner, "Цветная карта", self.cb_color)
        self._cb(inner, "Сетка", self.cb_grid)

        # Кнопки
        self._btn(inner, "🔄 Вращать", GREEN, GREEN_HOVER,
                  self._toggle_rotation).pack(side="left", padx=(16, 6))
        self._btn(inner, "💾 Экспорт", PURPLE, PURPLE_HOVER,
                  self.export).pack(side="left", padx=6)

    def _cb(self, parent, text, var):
        cb = tk.Checkbutton(parent, text=text,
                            variable=var,
                            font=("Segoe UI", 10),
                            bg=CARD, fg=TEXT,
                            activebackground=CARD,
                            activeforeground=ACCENT,
                            selectcolor=CARD,
                            bd=0, highlightthickness=0,
                            cursor="hand2",
                            command=self.redraw)
        cb.pack(side="left", padx=6)

    def _btn(self, parent, text, bg, hover, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 10, "bold"),
                        bg=bg, fg="white",
                        activebackground=hover,
                        activeforeground="white",
                        bd=0, padx=12, pady=8, cursor="hand2",
                        command=command)

        def on_enter(e): btn.config(bg=hover)

        def on_leave(e): btn.config(bg=bg)

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        return btn

    def _on_density(self, v):
        self.density_lbl.config(text=str(int(float(v))))
        for p in self.plots:
            p.grid_n = int(float(v))
        self.redraw()

    def _toggle_rotation(self):
        self.rotating = not self.rotating

    # ════════════════════════════════════════════════════════════
    # ПЛОТЫ
    # ════════════════════════════════════════════════════════════
    def _build_plots(self):
        self.plots = []
        self.redraw()

    def redraw(self):
        W = self.canvas.winfo_width()
        H = self.canvas.winfo_height()
        if W < 100:
            return

        # Очищаем
        self.canvas.delete("all")
        self.plots = []

        # Три графика в ряд
        third = W // 3
        size = min(third * 0.4, H * 0.35)

        cy = H // 2

        titles = ["Re[sin(x+iy)]", "Im[sin(x+iy)]", "|sin(x+iy)|"]
        types = ["re", "im", "abs"]

        for i, (title, ftype) in enumerate(zip(titles, types)):
            cx = third * i + third // 2
            plot = Plot3D(self.canvas, cx, cy, size, title, ftype)
            plot.grid_n = int(self.density_scale.get())
            plot.show_color = self.cb_color.get()
            plot.show_grid = self.cb_grid.get()
            plot.rotation = self.rotation
            plot.draw()
            self.plots.append(plot)

    def _animate(self):
        if self.rotating:
            self.rotation += self.rotation_speed
            self.redraw()
        self.root.after(50, self._animate)

    def __init_rotation(self):
        self.rotation = 0.0

    # ════════════════════════════════════════════════════════════
    # ЭКСПОРТ
    # ════════════════════════════════════════════════════════════
    def export(self):
        from tkinter import filedialog
        from datetime import datetime
        path = filedialog.asksaveasfilename(
            defaultextension=".ps",
            filetypes=[("PostScript", "*.ps"), ("PNG", "*.png")],
            initialfile=f"3d_{datetime.now().strftime('%H%M%S')}.ps")
        if not path:
            return

        try:
            if path.endswith(".png"):
                try:
                    from PIL import Image
                    ps_path = path.replace(".png", ".ps")
                    self.canvas.postscript(file=ps_path, colormode="color")
                    img = Image.open(ps_path)
                    img.save(path, "PNG")
                except ImportError:
                    self.canvas.postscript(
                        file=path.replace(".png", ".ps"),
                        colormode="color")
            else:
                self.canvas.postscript(file=path, colormode="color")
        except Exception as e:
            from tkinter import messagebox
            messagebox.showerror("Ошибка", f"Не удалось сохранить: {e}")


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = ComplexSin3DApp(root)
    # Сохраняем rotation в атрибут
    app.rotation = 0.0
    root.mainloop()
