import tkinter as tk
import math


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

F_COLOR = "#0a84ff"        # f(x) — синий
DF_COLOR = "#e53935"       # f'(x) — красный
DDF_COLOR = "#30d158"      # f''(x) — зелёный
INT_COLOR = "#8e44ad"      # ∫f — фиолетовый

AXIS = "#000000"
GRID = "#ececf0"
ZERO = "#c0c0c0"
AREA = "#0a84ff33"         # полупрозрачная синяя область (эмуляция через точки)

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"
RED = "#e53935"
RED_HOVER = "#c62828"


# ═══════════════════════════════════════════════════════════════════
# ВЫЧИСЛЕНИЕ ФУНКЦИЙ
# ═══════════════════════════════════════════════════════════════════
def eval_func(expr, x):
    """Безопасно вычисляет функцию в точке x."""
    # Подменяем ^ на **
    expr = expr.replace("^", "**")

    # Разрешённые имена
    safe = {
        "x": x,
        "sin": math.sin,
        "cos": math.cos,
        "tan": math.tan,
        "sqrt": math.sqrt,
        "abs": abs,
        "exp": math.exp,
        "log": math.log,
        "pi": math.pi,
        "e": math.e,
    }

    try:
        return float(eval(expr, {"__builtins__": {}}, safe))
    except Exception:
        return 0.0


def derivative(expr, x, h=1e-5):
    """Численная производная."""
    return (eval_func(expr, x + h) - eval_func(expr, x - h)) / (2 * h)


def second_derivative(expr, x, h=1e-4):
    """Численная вторая производная."""
    return (eval_func(expr, x + h) - 2 * eval_func(expr, x) +
            eval_func(expr, x - h)) / (h * h)


def integral(expr, x0, x1, steps=200):
    """Численный интеграл методом трапеций."""
    if x0 == x1:
        return 0.0
    step = (x1 - x0) / steps
    total = 0.0
    for i in range(steps):
        a = x0 + i * step
        b = a + step
        total += (eval_func(expr, a) + eval_func(expr, b)) / 2 * step
    return total


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class CalculusApp:
    def __init__(self, root):
        self.root = root
        root.title("Calculus Grapher — производная и интеграл")
        root.geometry("1180x820")
        root.minsize(1080, 780)
        root.configure(bg=BG)
        root.resizable(False, False)

        self.expr = "sin(x)"
        self.xmin = -6.28
        self.xmax = 6.28
        self.mouse_x = None

        self.show_f = tk.BooleanVar(value=True)
        self.show_df = tk.BooleanVar(value=True)
        self.show_ddf = tk.BooleanVar(value=False)
        self.show_int = tk.BooleanVar(value=True)

        self._build_ui()
        self.redraw()

    # ════════════════════════════════════════════════════════════
    # UI
    # ════════════════════════════════════════════════════════════
    def _build_ui(self):
        tk.Label(self.root, text="Calculus Grapher",
                 font=("Segoe UI", 15, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(10, 2))

        tk.Label(self.root,
                 text="f(x) · f'(x) · f''(x) · ∫f(x)dx — в реальном времени",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 8))

        # ─── Ввод функции ──────────────────────────────────────
        input_card = tk.Frame(self.root, bg=CARD,
                              highlightthickness=1,
                              highlightbackground=BORDER)
        input_card.pack(padx=20, pady=(0, 8), fill="x")

        row = tk.Frame(input_card, bg=CARD)
        row.pack(fill="x", padx=14, pady=10)

        tk.Label(row, text="f(x) =",
                 font=("Consolas", 12, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 6))

        self.entry = tk.Entry(row, font=("Consolas", 12),
                              bg="#fafafa", fg=TEXT,
                              bd=1, relief="solid",
                              highlightthickness=1,
                              highlightbackground=BORDER,
                              highlightcolor=ACCENT,
                              width=30)
        self.entry.pack(side="left", padx=(0, 8), ipady=4)
        self.entry.insert(0, self.expr)

        self._btn(row, "✓ Построить", GREEN, GREEN_HOVER,
                  self.apply).pack(side="left", padx=2)

        # Пресеты
        presets = [
            ("sin(x)", "sin(x)"),
            ("cos(x)", "cos(x)"),
            ("x²", "x**2"),
            ("x³", "x**3"),
            ("|x|", "abs(x)"),
            ("eˣ", "exp(x)"),
            ("√x", "sqrt(abs(x))"),
            ("1/x", "1/x if x != 0 else 0"),
        ]

        for name, expr in presets:
            self._btn(row, name, ACCENT, ACCENT_HOVER,
                      lambda e=expr: self.set_preset(e)).pack(side="left", padx=2)

        # ─── Canvas ─────────────────────────────────────────────
        canvas_card = tk.Frame(self.root, bg=CARD,
                               highlightthickness=1,
                               highlightbackground=BORDER)
        canvas_card.pack(padx=20, pady=(0, 8), fill="both", expand=True)

        self.canvas = tk.Canvas(canvas_card,
                                bg="white",
                                highlightthickness=0)
        self.canvas.pack(padx=10, pady=10, fill="both", expand=True)

        self.canvas.bind("<Motion>", self.on_mouse)
        self.canvas.bind("<Leave>", self.on_leave)
        self.canvas.bind("<Configure>", lambda e: self.redraw())

        # ─── Легенда + чекбоксы ────────────────────────────────
        bottom = tk.Frame(self.root, bg=CARD,
                          highlightthickness=1,
                          highlightbackground=BORDER)
        bottom.pack(padx=20, pady=(0, 16), fill="x")

        inner = tk.Frame(bottom, bg=CARD)
        inner.pack(fill="x", padx=14, pady=10)

        self._cb(inner, "f(x)", F_COLOR, self.show_f)
        self._cb(inner, "f'(x)", DF_COLOR, self.show_df)
        self._cb(inner, "f''(x)", DDF_COLOR, self.show_ddf)
        self._cb(inner, "∫f(x)dx", INT_COLOR, self.show_int)

        # Информация о точке
        self.info = tk.Label(inner, text="",
                             font=("Consolas", 10),
                             bg=CARD, fg=TEXT, anchor="w")
        self.info.pack(side="right")

    def _cb(self, parent, text, color, var):
        cb = tk.Checkbutton(parent, text=text,
                            variable=var,
                            font=("Segoe UI", 10, "bold"),
                            bg=CARD, fg=color,
                            activebackground=CARD,
                            activeforeground=color,
                            selectcolor=CARD,
                            bd=0, highlightthickness=0,
                            cursor="hand2",
                            command=self.redraw)
        cb.pack(side="left", padx=8)
        return cb

    def _btn(self, parent, text, bg, hover, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 9, "bold"),
                        bg=bg, fg="white",
                        activebackground=hover,
                        activeforeground="white",
                        bd=0, padx=10, pady=6, cursor="hand2",
                        command=command)

        def on_enter(e): btn.config(bg=hover)

        def on_leave(e): btn.config(bg=bg)

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        return btn

    # ════════════════════════════════════════════════════════════
    # ОБРАБОТЧИКИ
    # ════════════════════════════════════════════════════════════
    def apply(self):
        expr = self.entry.get().strip()
        if not expr:
            return
        self.expr = expr
        self.redraw()

    def set_preset(self, expr):
        self.entry.delete(0, tk.END)
        self.entry.insert(0, expr)
        self.expr = expr
        self.redraw()

    def on_mouse(self, e):
        self.mouse_x = e.x
        self.redraw()

    def on_leave(self, e):
        self.mouse_x = None
        self.redraw()

    # ════════════════════════════════════════════════════════════
    # ОТРИСОВКА
    # ════════════════════════════════════════════════════════════
    def redraw(self):
        c = self.canvas
        c.delete("all")

        W = c.winfo_width()
        H = c.winfo_height()
        if W < 100:
            return

        pad = 50
        x0, x1 = pad, W - 30
        y0, y1 = 30, H - pad

        # ─── Вычисляем значения функций для масштаба ────────────
        # Собираем все значения в 200 точках
        n = 200
        xs = [self.xmin + (self.xmax - self.xmin) * i / n for i in range(n + 1)]
        f_vals = [eval_func(self.expr, x) for x in xs]
        df_vals = [derivative(self.expr, x) for x in xs]
        ddf_vals = [second_derivative(self.expr, x) for x in xs]

        # Интеграл накапливаем
        int_vals = [0.0]
        for i in range(1, len(xs)):
            step = xs[i] - xs[i - 1]
            int_vals.append(int_vals[-1] + (f_vals[i] + f_vals[i - 1]) / 2 * step)

        # Определяем y-диапазон
        all_vals = list(f_vals) + list(df_vals)
        if self.show_ddf.get():
            all_vals += ddf_vals
        if self.show_int.get():
            all_vals += int_vals

        finite = [v for v in all_vals if abs(v) < 1e6]
        if not finite:
            finite = [0]

        ymin = min(min(finite), 0) - 1
        ymax = max(max(finite), 0) + 1
        if ymax - ymin < 2:
            ymin -= 1
            ymax += 1

        def to_px(x):
            return x0 + (x - self.xmin) / (self.xmax - self.xmin) * (x1 - x0)

        def to_py(y):
            return y1 - (y - ymin) / (ymax - ymin) * (y1 - y0)

        # ─── Сетка ──────────────────────────────────────────────
        # Находим шаг сетки (1, 2, 5, 10, …)
        span = self.xmax - self.xmin
        x_step = 1
        while span / x_step > 20:
            x_step *= 2

        x = math.ceil(self.xmin / x_step) * x_step
        while x <= self.xmax:
            px = to_px(x)
            c.create_line(px, y0, px, y1, fill=GRID, width=1)
            x += x_step

        y_span = ymax - ymin
        y_step = 1
        while y_span / y_step > 15:
            y_step *= 2

        y = math.ceil(ymin / y_step) * y_step
        while y <= ymax:
            py = to_py(y)
            c.create_line(x0, py, x1, py, fill=GRID, width=1)
            y += y_step

        # ─── Оси ────────────────────────────────────────────────
        cy = to_py(0)
        c.create_line(x0 - 10, cy, x1 + 10, cy, fill=AXIS, width=1,
                      arrow="last", arrowshape=(8, 10, 3))
        cx = to_px(0) if self.xmin <= 0 <= self.xmax else x0
        c.create_line(cx, y1 + 10, cx, y0 - 10, fill=AXIS, width=1,
                      arrow="last", arrowshape=(8, 10, 3))

        # Подписи осей
        c.create_text(x1 + 15, cy + 12, text="x",
                      font=("Segoe UI", 10, "italic"), fill=TEXT)
        c.create_text(cx - 15, y0 - 15, text="y",
                      font=("Segoe UI", 10, "italic"), fill=TEXT)

        # ─── Площадь под f(x) ───────────────────────────────────
        if self.show_int.get() and self.mouse_x is not None:
            # От 0 до mouse_x
            m_x = self._px_to_val(self.mouse_x, x0, x1, W)
            # Строим область
            area_pts = []
            for i, x_val in enumerate(xs):
                if 0 <= x_val <= m_x or m_x <= x_val <= 0:
                    px = to_px(x_val)
                    py = to_py(f_vals[i])
                    area_pts.extend([px, py])

            if area_pts:
                # Замыкаем
                first_px = area_pts[0]
                last_px = area_pts[-2]
                # Рисуем полигон
                poly_pts = area_pts + [last_px, cy, first_px, cy]
                c.create_polygon(*poly_pts,
                                 fill="#0a84ff22", outline="",
                                 stipple="gray25")

        # ─── f(x) ───────────────────────────────────────────────
        if self.show_f.get():
            self._draw_curve(c, xs, f_vals, to_px, to_py, F_COLOR, 2.5)

        # ─── f'(x) ─────────────────────────────────────────────
        if self.show_df.get():
            self._draw_curve(c, xs, df_vals, to_px, to_py, DF_COLOR, 2)

        # ─── f''(x) ────────────────────────────────────────────
        if self.show_ddf.get():
            self._draw_curve(c, xs, ddf_vals, to_px, to_py, DDF_COLOR, 1.5,
                             dash=(6, 4))

        # ─── ∫f(x)dx ───────────────────────────────────────────
        if self.show_int.get():
            self._draw_curve(c, xs, int_vals, to_px, to_py, INT_COLOR, 2,
                             dash=(4, 3))

        # ─── Касательная в mouse_x ──────────────────────────────
        if self.mouse_x is not None and x0 <= self.mouse_x <= x1:
            m_x_val = self._px_to_val(self.mouse_x, x0, x1, W)
            f_val = eval_func(self.expr, m_x_val)
            df_val = derivative(self.expr, m_x_val)
            ddf_val = second_derivative(self.expr, m_x_val)
            int_val = integral(self.expr, 0, m_x_val)

            # Вертикальная линия
            px = to_px(m_x_val)
            c.create_line(px, y0, px, y1,
                          fill="#999999", width=1, dash=(2, 4))

            # Точка на f(x)
            py = to_py(f_val)
            c.create_oval(px - 6, py - 6, px + 6, py + 6,
                          fill=F_COLOR, outline="white", width=2)

            # Касательная (короткая линия)
            h = (self.xmax - self.xmin) / 20
            x1_t = m_x_val - h
            x2_t = m_x_val + h
            y1_t = f_val + df_val * (-h)
            y2_t = f_val + df_val * (h)
            c.create_line(to_px(x1_t), to_py(y1_t),
                          to_px(x2_t), to_py(y2_t),
                          fill=DF_COLOR, width=2, dash=(4, 3))

            # Информация
            self.info.config(
                text=f"x = {m_x_val:+.2f}  ·  "
                     f"f(x) = {f_val:+.3f}  ·  "
                     f"f'(x) = {df_val:+.3f}  ·  "
                     f"f''(x) = {ddf_val:+.3f}  ·  "
                     f"∫₀ˣ = {int_val:+.3f}")
        else:
            self.info.config(text="Двигайте мышь по графику")

    def _px_to_val(self, px, x0, x1, W):
        """Пиксель → значение X."""
        return self.xmin + (px - x0) / (x1 - x0) * (self.xmax - self.xmin)

    def _draw_curve(self, c, xs, ys, to_px, to_py, color, width,
                    dash=None):
        points = []
        for x, y in zip(xs, ys):
            if abs(y) > 1e6:
                continue
            points.extend([to_px(x), to_py(y)])
        if len(points) >= 4:
            c.create_line(*points, fill=color, width=width,
                          dash=dash, smooth=True)


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = CalculusApp(root)
    root.mainloop()
