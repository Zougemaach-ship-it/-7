import tkinter as tk
import math
import random


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f0f0f0"
CARD = "#ffffff"
BORDER = "#d0d0d0"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

POSITIVE = "#e53935"     # красный — плюс
NEGATIVE = "#1e88e5"     # синий — минус
FIELD_COLOR = "#333333"  # стрелки поля
GRID_COLOR = "#e0e0e0"

ACCENT = "#0a84ff"
ORANGE = "#ff9f0a"
GREEN = "#30d158"
RED = "#e53935"
PURPLE = "#8e44ad"


# ─── Физика ──────────────────────────────────────────────────────
K = 8.99e9      # постоянная Кулона, Н·м²/Кл²
NC = 1e-9       # 1 нКл = 10⁻⁹ Кл


# ═══════════════════════════════════════════════════════════════════
# ЗАРЯД
# ═══════════════════════════════════════════════════════════════════
class Charge:
    def __init__(self, x, y, q_nc):
        self.x = x
        self.y = y
        self.q = q_nc * NC     # заряд в кулонах
        self.sign = 1 if q_nc > 0 else -1


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class ChargesApp:
    def __init__(self, root):
        self.root = root
        root.title("Заряды и поля")
        root.geometry("1100x780")
        root.minsize(1000, 740)
        root.configure(bg=BG)
        root.resizable(False, False)

        # Физическое поле
        self.canvas_w = 700
        self.canvas_h = 700
        self.meters_per_pixel = 1.0 / 100   # 1 м = 100 px

        self.charges = []
        self.selected_charge = None
        self.drag_offset = (0, 0)

        self.show_field = True
        self.show_equipotential = True

        self.selected_sign = tk.IntVar(value=1)  # +1 / -1

        self._build_ui()

        # Стартовые заряды
        self.add_charge_at(250, 350, +1)
        self.add_charge_at(450, 350, -1)

        self.redraw()

    # ════════════════════════════════════════════════════════════
    # UI
    # ════════════════════════════════════════════════════════════
    def _build_ui(self):
        tk.Label(self.root, text="Заряды и поля",
                 font=("Segoe UI", 16, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(10, 4))

        tk.Label(self.root,
                 text="Клик — добавить заряд · Перетаскивание — переместить",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 8))

        main = tk.Frame(self.root, bg=BG)
        main.pack(fill="both", expand=True, padx=16, pady=(0, 16))

        # ─── Canvas ─────────────────────────────────────────────
        canvas_wrap = tk.Frame(main, bg=CARD,
                               highlightthickness=1,
                               highlightbackground=BORDER)
        canvas_wrap.pack(side="left", fill="both", expand=True,
                         padx=(0, 8))

        self.canvas = tk.Canvas(canvas_wrap,
                                width=self.canvas_w,
                                height=self.canvas_h,
                                bg="white",
                                highlightthickness=0)
        self.canvas.pack(padx=8, pady=8)

        # ─── Панель управления ──────────────────────────────────
        panel = tk.Frame(main, bg=BG)
        panel.pack(side="left", fill="y")

        # Заряды
        c1 = tk.Frame(panel, bg=CARD,
                      highlightthickness=1,
                      highlightbackground=BORDER)
        c1.pack(fill="x", pady=(0, 8))

        tk.Label(c1, text="ЗАРЯДЫ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=14, pady=(10, 4))

        pos_btn = tk.Button(c1, text="●  +1 нКл",
                            font=("Segoe UI", 11, "bold"),
                            bg=POSITIVE, fg="white",
                            activebackground="#c62828",
                            activeforeground="white",
                            bd=0, padx=16, pady=10,
                            cursor="hand2",
                            command=lambda: self.select_sign(+1))
        pos_btn.pack(fill="x", padx=14, pady=(0, 4))

        neg_btn = tk.Button(c1, text="●  −1 нКл",
                            font=("Segoe UI", 11, "bold"),
                            bg=NEGATIVE, fg="white",
                            activebackground="#1565c0",
                            activeforeground="white",
                            bd=0, padx=16, pady=10,
                            cursor="hand2",
                            command=lambda: self.select_sign(-1))
        neg_btn.pack(fill="x", padx=14, pady=(0, 12))

        # Настройки отображения
        c2 = tk.Frame(panel, bg=CARD,
                      highlightthickness=1,
                      highlightbackground=BORDER)
        c2.pack(fill="x", pady=(0, 8))

        tk.Label(c2, text="ОТОБРАЖЕНИЕ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=14, pady=(10, 4))

        self.field_var = tk.BooleanVar(value=True)
        self.equip_var = tk.BooleanVar(value=True)

        self._cb(c2, "Электрическое поле", self.field_var,
                 self.toggle_field)
        self._cb(c2, "Эквипотенциальные линии", self.equip_var,
                 self.toggle_equip)

        tk.Frame(c2, bg=CARD, height=6).pack()

        # Кнопки
        c3 = tk.Frame(panel, bg=CARD,
                      highlightthickness=1,
                      highlightbackground=BORDER)
        c3.pack(fill="x", pady=(0, 8))

        tk.Label(c3, text="ДЕЙСТВИЯ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=14, pady=(10, 4))

        self._btn(c3, "↻  Сброс", ACCENT, "#0066cc",
                  self.reset).pack(fill="x", padx=14, pady=2)
        self._btn(c3, "🗑  Очистить", RED, "#c62828",
                  self.clear_all).pack(fill="x", padx=14, pady=(2, 12))

        # Легенда
        c4 = tk.Frame(panel, bg=CARD,
                      highlightthickness=1,
                      highlightbackground=BORDER)
        c4.pack(fill="x", pady=(0, 8))

        tk.Label(c4, text="ДАТЧИК",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=14, pady=(10, 4))

        self.sensor_text = tk.Label(c4, text="Кликните на поле",
                                    font=("Consolas", 9),
                                    bg=CARD, fg=TEXT, justify="left",
                                    anchor="w", wraplength=240)
        self.sensor_text.pack(fill="x", padx=14, pady=(0, 12))

        # ─── Обработчики мыши ───────────────────────────────────
        self.canvas.bind("<Button-1>", self.on_click)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)

    def _cb(self, parent, text, var, command):
        cb = tk.Checkbutton(parent, text=text,
                            variable=var,
                            font=("Segoe UI", 10),
                            bg=CARD, fg=TEXT,
                            activebackground=CARD,
                            activeforeground=TEXT,
                            selectcolor=CARD,
                            anchor="w",
                            bd=0, highlightthickness=0,
                            cursor="hand2",
                            command=command)
        cb.pack(fill="x", padx=14, pady=2)
        return cb

    def _btn(self, parent, text, bg, hover, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 10, "bold"),
                        bg=bg, fg="white",
                        activebackground=hover,
                        activeforeground="white",
                        bd=0, padx=12, pady=8, cursor="hand2",
                        command=command)
        btn.bind("<Enter>", lambda e: btn.config(bg=hover))
        btn.bind("<Leave>", lambda e: btn.config(bg=bg))
        return btn

    # ════════════════════════════════════════════════════════════
    # ВЫБОР ЗАРЯДА
    # ════════════════════════════════════════════════════════════
    def select_sign(self, sign):
        self.selected_sign.set(sign)

    # ════════════════════════════════════════════════════════════
    # ФИЗИКА
    # ════════════════════════════════════════════════════════════
    def field_at(self, x, y):
        """Напряжённость E в точке (x,y) в пикселях."""
        ex = 0.0
        ey = 0.0

        for c in self.charges:
            dx = x - c.x
            dy = y - c.y
            r2 = dx * dx + dy * dy
            if r2 < 100:
                continue   # слишком близко
            r = math.sqrt(r2)
            # E = k·q / r²
            e = K * c.q / (r2 * self.meters_per_pixel ** 2)
            ex += e * (dx / r)
            ey += e * (dy / r)

        return ex, ey

    def potential_at(self, x, y):
        """Потенциал V в точке (x,y)."""
        v = 0.0
        for c in self.charges:
            dx = x - c.x
            dy = y - c.y
            r = math.sqrt(dx * dx + dy * dy)
            if r < 1:
                continue
            v += K * c.q / (r * self.meters_per_pixel)
        return v

    # ════════════════════════════════════════════════════════════
    # МЫШЬ
    # ════════════════════════════════════════════════════════════
    def on_click(self, e):
        # Ищем заряд под курсором
        for c in self.charges:
            if (e.x - c.x) ** 2 + (e.y - c.y) ** 2 < 20 ** 2:
                self.selected_charge = c
                self.drag_offset = (e.x - c.x, e.y - c.y)
                return

        # Нет заряда под курсором — создаём новый
        sign = self.selected_sign.get()
        self.add_charge_at(e.x, e.y, sign)

    def on_drag(self, e):
        if self.selected_charge is None:
            return
        self.selected_charge.x = e.x - self.drag_offset[0]
        self.selected_charge.y = e.y - self.drag_offset[1]
        self.redraw()

    def on_release(self, e):
        self.selected_charge = None
        self.redraw()

    # ════════════════════════════════════════════════════════════
    # ЗАРЯДЫ
    # ════════════════════════════════════════════════════════════
    def add_charge_at(self, x, y, sign):
        self.charges.append(Charge(x, y, sign))
        self.redraw()

    def clear_all(self):
        self.charges = []
        self.redraw()

    def reset(self):
        self.charges = []
        self.add_charge_at(250, 350, +1)
        self.add_charge_at(450, 350, -1)
        self.sensor_text.config(text="Кликните на поле")

    def toggle_field(self):
        self.show_field = self.field_var.get()
        self.redraw()

    def toggle_equip(self):
        self.show_equipotential = self.equip_var.get()
        self.redraw()

    # ════════════════════════════════════════════════════════════
    # ОТРИСОВКА
    # ════════════════════════════════════════════════════════════
    def redraw(self):
        c = self.canvas
        c.delete("all")

        W = self.canvas_w
        H = self.canvas_h

        # ─── Сетка ──────────────────────────────────────────────
        step = 100   # 1 м
        for x in range(0, W + 1, step):
            c.create_line(x, 0, x, H, fill=GRID_COLOR, width=1)
        for y in range(0, H + 1, step):
            c.create_line(0, y, W, y, fill=GRID_COLOR, width=1)

        # Подпись масштаба
        c.create_text(10, H - 10, text="1 м = 100 px",
                      font=("Segoe UI", 8), fill=MUTED, anchor="w")

        # ─── Эквипотенциальные линии ────────────────────────────
        if self.show_equipotential and len(self.charges) > 0:
            self._draw_equipotential()

        # ─── Поле ───────────────────────────────────────────────
        if self.show_field:
            self._draw_field()

        # ─── Заряды ─────────────────────────────────────────────
        for c_obj in self.charges:
            self._draw_charge(c_obj)

    def _draw_charge(self, ch):
        c = self.canvas
        x, y = ch.x, ch.y

        if ch.sign > 0:
            color = POSITIVE
            text = "+"
        else:
            color = NEGATIVE
            text = "−"

        # Обводка
        c.create_oval(x - 18, y - 18, x + 18, y + 18,
                      fill=color, outline="white", width=3)

        # Символ
        c.create_text(x, y, text=text,
                      font=("Segoe UI", 18, "bold"),
                      fill="white")

        # Подпись
        c.create_text(x, y + 28,
                      text=f"{ch.sign:+d} нКл",
                      font=("Segoe UI", 8),
                      fill=MUTED)

    def _draw_field(self):
        """Стрелки поля в точках сетки."""
        c = self.canvas
        step = 50

        for y in range(step // 2, self.canvas_h, step):
            for x in range(step // 2, self.canvas_w, step):
                # Пропускаем точки рядом с зарядами
                skip = False
                for ch in self.charges:
                    if (x - ch.x) ** 2 + (y - ch.y) ** 2 < 35 ** 2:
                        skip = True
                        break
                if skip:
                    continue

                ex, ey = self.field_at(x, y)
                mag = math.sqrt(ex * ex + ey * ey)
                if mag < 1e-6:
                    continue

                # Нормализуем
                nx = ex / mag
                ny = ey / mag

                # Длина стрелки — пропорциональна log(mag), чтобы не вылезать
                length = 18
                # Ограничиваем визуально
                l = min(length, 12 + 4 * math.log10(mag + 1))

                end_x = x + nx * l
                end_y = y + ny * l

                # Стрелка
                c.create_line(x, y, end_x, end_y,
                              fill=FIELD_COLOR, width=1,
                              arrow="last", arrowshape=(4, 5, 2))

    def _draw_equipotential(self):
        """Эквипотенциальные линии — уровни V."""
        c = self.canvas

        # Уровни: от -10 до +10 В с шагом 2
        levels = [-10, -8, -6, -4, -2, 2, 4, 6, 8, 10]
        step = 15   # шаг сетки для расчёта

        for level in levels:
            points = []
            for y in range(0, self.canvas_h, step):
                for x in range(0, self.canvas_w, step):
                    v = self.potential_at(x, y)
                    if abs(v - level) < 0.5:
                        points.append((x, y))

            # Рисуем точки как маленькие кружки
            for (px, py) in points:
                if level > 0:
                    color = POSITIVE
                else:
                    color = NEGATIVE
                c.create_oval(px - 2, py - 2, px + 2, py + 2,
                              fill=color, outline="")

    # ════════════════════════════════════════════════════════════
    # ДАТЧИК
    # ════════════════════════════════════════════════════════════
    def on_click_sensor(self, e):
        pass


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = ChargesApp(root)
    root.mainloop()
