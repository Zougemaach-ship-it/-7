import tkinter as tk
from tkinter import filedialog
import random
from datetime import datetime


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

OK = "#30d158"
WARN = "#ff9f0a"
ALARM = "#ff3b30"
ACCENT = "#0a84ff"

ACCENT_HOVER = "#0066cc"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
RED = "#e53935"
RED_HOVER = "#c62828"
PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class NetImageApp:
    def __init__(self, root):
        self.root = root
        root.title("Передача изображения через сеть с потерями")
        root.geometry("1280x900")
        root.minsize(1180, 850)
        root.configure(bg=BG)
        root.resizable(False, False)

        # Состояние
        self.original_pixels = []
        self.corrupted_pixels = []
        self.image_w = 300
        self.image_h = 300

        # Сеть
        self.transfer_running = False
        self.transfer_tick = 0

        # Метрики
        self.total_packets = 0
        self.packets_sent = 0
        self.packets_lost = 0
        self.packets_retransmitted = 0
        self.transfer_time = 0.0

        self._generate_image()
        self._build_ui()

    # ════════════════════════════════════════════════════════════
    # ГЕНЕРАЦИЯ ИСХОДНОГО ИЗОБРАЖЕНИЯ
    # ════════════════════════════════════════════════════════════
    def _generate_image(self):
        """Генерирует цветное изображение 300×300 — градиент + фигуры."""
        self.original_pixels = []
        for y in range(self.image_h):
            row = []
            for x in range(self.image_w):
                # Градиент
                r = int(255 * x / self.image_w)
                g = int(255 * y / self.image_h)
                b = int(255 * (1 - (x + y) / (2 * self.image_w)))

                # Круг в центре
                cx, cy = self.image_w // 2, self.image_h // 2
                dist = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
                if dist < 80:
                    r, g, b = 255, 200, 50

                # Квадрат в левом верхнем углу
                if 40 < x < 120 and 40 < y < 120:
                    r, g, b = 50, 150, 255

                # Квадрат в правом нижнем углу
                if 180 < x < 260 and 180 < y < 260:
                    r, g, b = 255, 80, 120

                row.append((r, g, b))
            self.original_pixels.append(row)

        self.corrupted_pixels = [[px for px in row]
                                 for row in self.original_pixels]

    # ════════════════════════════════════════════════════════════
    # UI
    # ════════════════════════════════════════════════════════════
    def _build_ui(self):
        # ─── Заголовок ─────────────────────────────────────────
        tk.Label(self.root,
                 text="Передача изображения через сеть с потерями",
                 font=("Segoe UI", 15, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(12, 2))

        tk.Label(self.root,
                 text="Искажение битов пикселей + симуляция потери пакетов",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 8))

        # ─── Основная область ──────────────────────────────────
        main = tk.Frame(self.root, bg=BG)
        main.pack(fill="both", expand=True, padx=20, pady=(0, 12))

        # ═══ Левая колонка — изображения ═══════════════════════
        left = tk.Frame(main, bg=BG)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))

        # Два изображения рядом
        imgs_row = tk.Frame(left, bg=BG)
        imgs_row.pack(fill="x", pady=(0, 8))

        # Оригинал
        orig_frame = tk.Frame(imgs_row, bg=CARD,
                              highlightthickness=1,
                              highlightbackground=BORDER)
        orig_frame.pack(side="left", fill="both", expand=True, padx=(0, 4))

        tk.Label(orig_frame, text="ОРИГИНАЛ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED).pack(pady=(8, 4))

        self.orig_canvas = tk.Canvas(orig_frame,
                                     width=self.image_w,
                                     height=self.image_h,
                                     bg="#fafafa",
                                     highlightthickness=0)
        self.orig_canvas.pack(padx=8, pady=(0, 8))

        self._draw_image(self.orig_canvas, self.original_pixels)

        # Искажённое
        cor_frame = tk.Frame(imgs_row, bg=CARD,
                             highlightthickness=1,
                             highlightbackground=BORDER)
        cor_frame.pack(side="left", fill="both", expand=True, padx=(4, 0))

        tk.Label(cor_frame, text="ИСКАЖЁННОЕ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=ALARM).pack(pady=(8, 4))

        self.cor_canvas = tk.Canvas(cor_frame,
                                    width=self.image_w,
                                    height=self.image_h,
                                    bg="#fafafa",
                                    highlightthickness=0)
        self.cor_canvas.pack(padx=8, pady=(0, 8))

        # ═══ Правая колонка — метрики и управление ═════════════
        right = tk.Frame(main, bg=BG)
        right.pack(side="left", fill="both", padx=(8, 0))

        # ─── Искажение битов ──────────────────────────────────
        bit_card = tk.Frame(right, bg=CARD,
                            highlightthickness=1,
                            highlightbackground=BORDER)
        bit_card.pack(fill="x", pady=(0, 8))

        tk.Label(bit_card, text="ИСКАЖЕНИЕ ПИКСЕЛЕЙ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=14, pady=(10, 4))

        bit_inner = tk.Frame(bit_card, bg=CARD)
        bit_inner.pack(fill="x", padx=14, pady=(0, 10))

        tk.Label(bit_inner, text="% ошибочных битов:",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=TEXT).pack(anchor="w")

        self.bit_lbl = tk.Label(bit_inner, text="0%",
                                font=("Consolas", 12, "bold"),
                                bg=CARD, fg=ALARM)
        self.bit_lbl.pack(anchor="e")

        self.bit_scale = tk.Scale(bit_inner, from_=0, to=30,
                                  resolution=0.5,
                                  orient="horizontal",
                                  length=220, showvalue=False,
                                  bg=CARD, fg=TEXT, troughcolor="#ececf0",
                                  activebackground=ALARM,
                                  highlightthickness=0, bd=0,
                                  sliderlength=16, width=8,
                                  command=self._on_bit_change)
        self.bit_scale.set(0)
        self.bit_scale.pack(fill="x", pady=(4, 0))

        self._btn(bit_inner, "🎯 Исказить изображение",
                  ORANGE, ORANGE_HOVER,
                  self.corrupt_image).pack(fill="x", pady=(8, 0))

        # ─── Параметры сети ───────────────────────────────────
        net_card = tk.Frame(right, bg=CARD,
                            highlightthickness=1,
                            highlightbackground=BORDER)
        net_card.pack(fill="x", pady=(0, 8))

        tk.Label(net_card, text="ПАРАМЕТРЫ СЕТИ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=14, pady=(10, 4))

        net_inner = tk.Frame(net_card, bg=CARD)
        net_inner.pack(fill="x", padx=14, pady=(0, 10))

        # Скорость
        tk.Label(net_inner, text="Скорость сети:",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=TEXT).pack(anchor="w")

        self.speed_lbl = tk.Label(net_inner, text="10 Мбит/с",
                                  font=("Consolas", 11, "bold"),
                                  bg=CARD, fg=ACCENT)
        self.speed_lbl.pack(anchor="e")

        self.speed_scale = tk.Scale(net_inner, from_=1, to=100,
                                    resolution=1,
                                    orient="horizontal",
                                    length=220, showvalue=False,
                                    bg=CARD, fg=TEXT, troughcolor="#ececf0",
                                    activebackground=ACCENT,
                                    highlightthickness=0, bd=0,
                                    sliderlength=16, width=8,
                                    command=lambda v: self.speed_lbl.config(
                                        text=f"{int(float(v))} Мбит/с"))
        self.speed_scale.set(10)
        self.speed_scale.pack(fill="x", pady=(4, 6))

        # Потери
        tk.Label(net_inner, text="% потери пакетов:",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=TEXT).pack(anchor="w")

        self.loss_lbl = tk.Label(net_inner, text="10%",
                                 font=("Consolas", 11, "bold"),
                                 bg=CARD, fg=WARN)
        self.loss_lbl.pack(anchor="e")

        self.loss_scale = tk.Scale(net_inner, from_=0, to=50,
                                   resolution=1,
                                   orient="horizontal",
                                   length=220, showvalue=False,
                                   bg=CARD, fg=TEXT, troughcolor="#ececf0",
                                   activebackground=WARN,
                                   highlightthickness=0, bd=0,
                                   sliderlength=16, width=8,
                                   command=lambda v: self.loss_lbl.config(
                                       text=f"{int(float(v))}%"))
        self.loss_scale.set(10)
        self.loss_scale.pack(fill="x", pady=(4, 0))

        # ─── Кнопки передачи ──────────────────────────────────
        self.btn_transfer = self._btn(
            net_card, "▶  Передать через сеть",
            GREEN, GREEN_HOVER, self.start_transfer)
        self.btn_transfer.pack(fill="x", padx=14, pady=(0, 12))

        # ─── Метрики передачи ─────────────────────────────────
        metrics_card = tk.Frame(right, bg=CARD,
                                highlightthickness=1,
                                highlightbackground=BORDER)
        metrics_card.pack(fill="both", expand=True, pady=(0, 8))

        tk.Label(metrics_card, text="МЕТРИКИ ПЕРЕДАЧИ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=14, pady=(10, 4))

        m_inner = tk.Frame(metrics_card, bg=CARD)
        m_inner.pack(fill="both", expand=True, padx=14, pady=(0, 10))

        self.m_total = self._metric(m_inner, "Всего пакетов", "0", MUTED)
        self.m_sent = self._metric(m_inner, "Отправлено", "0", ACCENT)
        self.m_lost = self._metric(m_inner, "Потеряно", "0", ALARM)
        self.m_retr = self._metric(m_inner, "Повторно передано", "0", WARN)
        self.m_time = self._metric(m_inner, "Время передачи", "0.0 с", PURPLE)
        self.m_eff = self._metric(m_inner, "Эффективность", "—", OK)

        # Прогресс-бар
        self.progress_bg = tk.Frame(m_inner, bg="#ececf0", height=10)
        self.progress_bg.pack(fill="x", pady=(8, 0))
        self.progress_bg.pack_propagate(False)
        self.progress_bar = tk.Frame(self.progress_bg, bg=ACCENT)
        self.progress_bar.place(x=0, y=0, relwidth=0, relheight=1)

        # ─── Сохранение ───────────────────────────────────────
        save_row = tk.Frame(right, bg=BG)
        save_row.pack(fill="x")

        self._btn(save_row, "💾 Сохранить искажённое",
                  PURPLE, PURPLE_HOVER,
                  self.save_image).pack(side="left", fill="x",
                                        expand=True, padx=(0, 4))
        self._btn(save_row, "↻ Сброс",
                  "#e5e5ea", "#d0d0d5",
                  self.reset_image).pack(side="left", fill="x",
                                         expand=True, padx=(4, 0))

        # ─── Статус ───────────────────────────────────────────
        self.status = tk.Label(self.root, text="Готово",
                               font=("Segoe UI", 9),
                               bg=BG, fg=MUTED)
        self.status.pack(side="bottom", pady=(0, 8))

    def _btn(self, parent, text, bg, hover, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 10, "bold"),
                        bg=bg, fg="#ffffff",
                        activebackground=hover,
                        activeforeground="#ffffff",
                        bd=0, padx=12, pady=8, cursor="hand2",
                        command=command)

        def on_enter(e): btn.config(bg=hover)

        def on_leave(e): btn.config(bg=bg)

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        return btn

    def _metric(self, parent, label, value, color):
        row = tk.Frame(parent, bg=CARD)
        row.pack(fill="x", pady=2)

        tk.Label(row, text=label,
                 font=("Segoe UI", 9),
                 bg=CARD, fg=MUTED).pack(side="left")

        lbl = tk.Label(row, text=value,
                       font=("Consolas", 11, "bold"),
                       bg=CARD, fg=color)
        lbl.pack(side="right")
        return lbl

    # ════════════════════════════════════════════════════════════
    # ОТРИСОВКА ИЗОБРАЖЕНИЯ
    # ════════════════════════════════════════════════════════════
    def _draw_image(self, canvas, pixels):
        canvas.delete("all")
        w = self.image_w
        h = self.image_h
        # Рисуем квадратиками 2×2 — быстрее, чем фото-в-фото
        for y in range(0, h, 2):
            for x in range(0, w, 2):
                r, g, b = pixels[y][x]
                color = f"#{r:02x}{g:02x}{b:02x}"
                canvas.create_rectangle(x, y, x + 2, y + 2,
                                        fill=color, outline="")

    # ════════════════════════════════════════════════════════════
    # ИСКАЖЕНИЕ
    # ════════════════════════════════════════════════════════════
    def _on_bit_change(self, v):
        self.bit_lbl.config(text=f"{float(v):.1f}%")

    def corrupt_image(self):
        """Искажает % бит в каждом байте пикселей."""
        pct = float(self.bit_scale.get()) / 100.0

        if pct == 0:
            self.corrupted_pixels = [[px for px in row]
                                     for row in self.original_pixels]
            self._draw_image(self.cor_canvas, self.corrupted_pixels)
            self.status.config(text="Искажений нет (0%)", fg=MUTED)
            return

        corrupted = []
        total_bits = 0
        flipped_bits = 0

        for y in range(self.image_h):
            row = []
            for x in range(self.image_w):
                r, g, b = self.original_pixels[y][x]
                # Переворачиваем биты в каждом байте
                r_new, f1 = self._corrupt_byte(r, pct)
                g_new, f2 = self._corrupt_byte(g, pct)
                b_new, f3 = self._corrupt_byte(b, pct)
                row.append((r_new, g_new, b_new))
                total_bits += 24
                flipped_bits += f1 + f2 + f3
            corrupted.append(row)

        self.corrupted_pixels = corrupted
        self._draw_image(self.cor_canvas, corrupted)

        real_pct = 100 * flipped_bits / total_bits if total_bits else 0
        self.status.config(
            text=f"Искажено: {flipped_bits} бит из {total_bits} "
                 f"({real_pct:.1f}%)",
            fg=ALARM)

    def _corrupt_byte(self, byte, pct):
        """Инвертирует биты с вероятностью pct. Возвращает (новый_байт, кол-во_флипов)."""
        flips = 0
        for bit in range(8):
            if random.random() < pct:
                byte ^= (1 << bit)
                flips += 1
        return byte, flips

    # ════════════════════════════════════════════════════════════
    # СЕТЬ
    # ════════════════════════════════════════════════════════════
    def start_transfer(self):
        if self.transfer_running:
            return

        # Считаем пакеты
        # Изображение 300×300×3 байта = 270000 байт
        image_bytes = self.image_w * self.image_h * 3
        packet_size = 1024
        self.total_packets = (image_bytes + packet_size - 1) // packet_size

        self.packets_sent = 0
        self.packets_lost = 0
        self.packets_retransmitted = 0
        self.transfer_time = 0.0
        self.transfer_tick = 0

        self.transfer_running = True
        self.btn_transfer.config(state="disabled",
                                 bg="#c0c0c5",
                                 text="⏳ Передача...")
        self.status.config(text="Передача через сеть...", fg=ACCENT)

        self._transfer_step()

    def _transfer_step(self):
        if not self.transfer_running:
            return

        self.transfer_tick += 1

        speed = float(self.speed_scale.get())        # Мбит/с
        loss = float(self.loss_scale.get()) / 100.0  # вероятность потери

        # Сколько пакетов отправим за тик
        # Эмуляция: 100 пакетов в секунду = ~10 Мбит/с
        packets_per_tick = max(1, int(speed / 10))

        for _ in range(packets_per_tick):
            if self.packets_sent + self.packets_lost >= self.total_packets:
                break

            # Потеря?
            if random.random() < loss:
                self.packets_lost += 1
            else:
                self.packets_sent += 1

        # Повторная передача потерянных (упрощённо: retry по таймауту)
        if self.transfer_tick % 5 == 0 and self.packets_lost > 0:
            retry_count = min(
                self.packets_lost,
                max(1, int(self.packets_lost * 0.3))
            )
            self.packets_lost -= retry_count
            self.packets_retransmitted += retry_count

        # Время
        self.transfer_time = self.transfer_tick * 0.1

        # Прогресс
        total = self.total_packets
        done = self.packets_sent
        progress = done / total if total > 0 else 0

        self.progress_bar.place(x=0, y=0,
                                relwidth=progress, relheight=1)

        # Метрики
        self.m_total.config(text=str(self.total_packets))
        self.m_sent.config(text=str(self.packets_sent))
        self.m_lost.config(text=str(self.packets_lost))
        self.m_retr.config(text=str(self.packets_retransmitted))
        self.m_time.config(text=f"{self.transfer_time:.1f} с")

        # Эффективность = полезные / (полезные + потери + повторы)
        if done > 0:
            eff = done / (done + self.packets_lost +
                          self.packets_retransmitted) * 100
        else:
            eff = 0
        self.m_eff.config(text=f"{eff:.1f}%")

        # Готово?
        if self.packets_sent >= self.total_packets:
            self._finish_transfer()
            return

        self.root.after(100, self._transfer_step)

    def _finish_transfer(self):
        self.transfer_running = False
        self.btn_transfer.config(state="normal",
                                 bg=GREEN,
                                 text="▶  Передать через сеть")

        eff = (self.packets_sent /
               (self.packets_sent + self.packets_lost +
                self.packets_retransmitted) * 100)
        self.m_eff.config(text=f"{eff:.1f}%",
                          fg=OK if eff > 70 else WARN if eff > 40 else ALARM)

        self.status.config(
            text=f"Передача завершена · {self.packets_sent} пакетов · "
                 f"{self.packets_lost} потеряно · "
                 f"{self.packets_retransmitted} повторов · "
                 f"эффективность {eff:.1f}%",
            fg=OK if eff > 70 else WARN)

    # ════════════════════════════════════════════════════════════
    # СОХРАНЕНИЕ
    # ════════════════════════════════════════════════════════════
    def save_image(self):
        """Сохраняет искажённое изображение в PNG через canvas."""
        path = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG", "*.png"), ("PostScript", "*.ps")],
            initialfile=f"corrupted_{datetime.now().strftime('%H%M%S')}.png")
        if not path:
            return

        if path.endswith(".png"):
            # Tkinter Canvas может сохранить только PS
            # Конвертируем PS → PNG через PIL, если установлен
            try:
                from PIL import Image
                ps_path = path.replace(".png", ".ps")
                self.cor_canvas.postscript(file=ps_path,
                                           colormode="color")
                img = Image.open(ps_path)
                img.save(path, "PNG")
                self.status.config(
                    text=f"Сохранено: {path}", fg=OK)
            except ImportError:
                # Если PIL нет — сохраняем PS
                self.cor_canvas.postscript(file=path.replace(".png", ".ps"),
                                           colormode="color")
                self.status.config(
                    text=f"PIL не установлен. Сохранено как .ps — "
                         f"откройте и экспортируйте в PNG вручную.",
                    fg=WARN)
            except Exception as e:
                self.status.config(text=f"Ошибка: {e}", fg=ALARM)
        else:
            self.cor_canvas.postscript(file=path, colormode="color")
            self.status.config(text=f"Сохранено: {path}", fg=OK)

    def reset_image(self):
        self.corrupted_pixels = [[px for px in row]
                                 for row in self.original_pixels]
        self._draw_image(self.cor_canvas, self.corrupted_pixels)
        self.bit_scale.set(0)
        self.status.config(text="Изображение сброшено", fg=MUTED)

        # Сброс метрик
        self.packets_sent = 0
        self.packets_lost = 0
        self.packets_retransmitted = 0
        self.transfer_time = 0
        self.progress_bar.place(x=0, y=0, relwidth=0, relheight=1)
        self.m_sent.config(text="0")
        self.m_lost.config(text="0")
        self.m_retr.config(text="0")
        self.m_time.config(text="0.0 с")
        self.m_eff.config(text="—")


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = NetImageApp(root)
    root.mainloop()
